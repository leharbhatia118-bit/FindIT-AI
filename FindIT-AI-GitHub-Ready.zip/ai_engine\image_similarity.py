"""
Visual Similarity Engine.
Supports CLIP embeddings when available, and provides a robust pure-Python
perceptual color-histogram feature vector and cosine similarity fallback.
"""

import math
import os
import logging
from typing import Tuple, Optional, List
from PIL import Image

logger = logging.getLogger(__name__)

def extract_pure_image_features(image_path: str) -> Optional[List[float]]:
    """
    Extracts a 24-bin normalized RGB color distribution vector
    using standard Pillow pixel data (8 bins per channel).
    Pure Python, zero native DLL dependencies.
    """
    try:
        with Image.open(image_path) as img:
            rgb_img = img.convert('RGB').resize((64, 64))
            pixels = list(rgb_img.getdata())
            
            # 8 bins per channel: [0..31], [32..63], ... [224..255]
            bins = [0] * 24
            for r, g, b in pixels:
                bins[r // 32] += 1
                bins[8 + (g // 32)] += 1
                bins[16 + (b // 32)] += 1

            # L2 normalize
            norm = math.sqrt(sum(b * b for b in bins))
            if norm > 0:
                return [round(b / norm, 5) for b in bins]
            return [0.0] * 24
    except Exception as e:
        logger.error(f"Failed to extract image features from {image_path}: {e}")
        return None

def extract_image_embedding(image_path: str) -> Tuple[Optional[List[float]], str]:
    if not os.path.exists(image_path):
        return None, "FILE_NOT_FOUND"

    # Attempt CLIP if available
    try:
        import torch
        import clip
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model, preprocess = clip.load("ViT-B/32", device=device)
        image = preprocess(Image.open(image_path)).unsqueeze(0).to(device)
        with torch.no_grad():
            features = model.encode_image(image)
            features /= features.norm(dim=-1, keepdim=True)
        return features.cpu().numpy()[0].tolist(), "CLIP_VIT_B32"
    except Exception:
        pass

    # Pure-Python perceptual feature fallback
    features = extract_pure_image_features(image_path)
    return features, "COLOR_HISTOGRAM_FALLBACK"

def compute_image_similarity(vec_a: Optional[List[float]], vec_b: Optional[List[float]]) -> Tuple[Optional[float], str]:
    if vec_a is None or vec_b is None:
        return None, "MISSING_IMAGE"

    if len(vec_a) != len(vec_b):
        return None, "INCOMPATIBLE_VECTORS"

    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a = math.sqrt(sum(a * a for a in vec_a))
    norm_b = math.sqrt(sum(b * b for b in vec_b))

    if norm_a == 0 or norm_b == 0:
        return 0.0, "ZERO_VECTOR"

    cos_sim = dot / (norm_a * norm_b)
    score = max(0.0, min(1.0, round(cos_sim, 4)))
    return score, "COSINE_SIMILARITY"
