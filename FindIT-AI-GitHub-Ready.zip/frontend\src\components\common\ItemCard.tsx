import React from 'react';
import { Link } from 'react-router-dom';
import {
  MapPin,
  Calendar,
  Sparkles,
  ShieldCheck,
  Tag,
  Laptop,
  Wallet,
  Key,
  CreditCard,
  BookOpen,
  Shirt,
  Watch,
  HelpCircle,
} from 'lucide-react';
import { ItemReport, ItemCategory } from '../../types';

interface ItemCardProps {
  item: ItemReport;
  onClaim?: (item: ItemReport) => void;
  showSimilarity?: number;
}

const getCategoryIcon = (category: ItemCategory) => {
  switch (category) {
    case 'ELECTRONICS':
      return <Laptop className="w-5 h-5" />;
    case 'WALLETS_BAGS':
      return <Wallet className="w-5 h-5" />;
    case 'KEYS':
      return <Key className="w-5 h-5" />;
    case 'CARDS_IDS':
      return <CreditCard className="w-5 h-5" />;
    case 'BOOKS_STATIONERY':
      return <BookOpen className="w-5 h-5" />;
    case 'CLOTHING':
      return <Shirt className="w-5 h-5" />;
    case 'JEWELRY_WATCHES':
      return <Watch className="w-5 h-5" />;
    default:
      return <HelpCircle className="w-5 h-5" />;
  }
};

export const ItemCard: React.FC<ItemCardProps> = ({ item, onClaim, showSimilarity }) => {
  const isLost = item.report_type === 'LOST';
  const hasImage = item.images && item.images.length > 0;
  const imageUrl = hasImage ? item.images[0].image : null;

  return (
    <div className="group bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 overflow-hidden shadow-subtle hover:shadow-card hover:-translate-y-1 transition-all duration-200 flex flex-col h-full">
      
      {/* Media or Category Header */}
      <div className="relative h-48 w-full bg-slate-100 dark:bg-slate-700/50 overflow-hidden flex items-center justify-center">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-emerald-900/10 via-forest-900/5 to-slate-200/50 dark:from-emerald-950/40 dark:to-slate-800 flex flex-col items-center justify-center text-forest-700 dark:text-emerald-400 gap-2">
            <div className="p-4 rounded-2xl bg-white/80 dark:bg-slate-800/80 shadow-sm">
              {getCategoryIcon(item.category)}
            </div>
            <span className="text-[11px] font-semibold tracking-wide uppercase opacity-75">
              {item.category.replace('_', ' ')}
            </span>
          </div>
        )}

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span
            className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider shadow-sm ${
              isLost
                ? 'bg-rose-500 text-white'
                : 'bg-emerald-600 text-white'
            }`}
          >
            {item.report_type}
          </span>

          {item.status === 'RECOVERED' && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white flex items-center gap-1 shadow-sm">
              <ShieldCheck className="w-3 h-3" /> Recovered
            </span>
          )}

          {item.status === 'POTENTIAL_MATCH' && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3" /> AI Matched
            </span>
          )}
        </div>

        {/* Match Percentage Pill if available */}
        {showSimilarity !== undefined && (
          <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs font-bold bg-forest-950/80 backdrop-blur-sm text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-emerald-400" />
            {Math.round(showSimilarity * 100)}% Match
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col">
        {/* Brand & Category row */}
        <div className="flex items-center gap-2 text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1.5">
          <span className="capitalize">{item.category.replace('_', ' ').toLowerCase()}</span>
          {item.brand && (
            <>
              <span>•</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">{item.brand}</span>
            </>
          )}
          {item.primary_color && (
            <>
              <span>•</span>
              <span>{item.primary_color}</span>
            </>
          )}
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-slate-900 dark:text-white line-clamp-1 group-hover:text-forest-700 dark:group-hover:text-emerald-400 transition-colors">
          {item.title}
        </h3>

        {/* Description snippet */}
        <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-1.5 mb-4 leading-relaxed">
          {item.description}
        </p>

        {/* Location & Date Footer */}
        <div className="mt-auto pt-3 border-t border-slate-100 dark:border-slate-700/60 space-y-1.5 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1.5 truncate">
            <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span className="truncate">
              {item.location_name || item.location_detail || 'Campus Grounds'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{new Date(item.incident_date).toLocaleDateString()}</span>
            </div>
            {item.creator_username && (
              <span className="text-[11px] text-slate-400">
                by @{item.creator_username}
              </span>
            )}
          </div>
        </div>

        {/* Action Button Row */}
        <div className="mt-4 pt-3 flex items-center gap-2">
          <Link
            to={`/items/${item.id}`}
            className="flex-1 py-2 px-3 text-center text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 transition-colors"
          >
            View Details
          </Link>
          {!isLost && item.status !== 'RECOVERED' && (
            <Link
              to={`/items/${item.id}?claim=true`}
              className="py-2 px-3 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-sm"
            >
              Claim Item
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};
