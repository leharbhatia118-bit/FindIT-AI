import datetime
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from apps.reports.models import Campus, ItemReport, ReportStatus
from apps.claims.models import Claim, Handover, ClaimStatus

User = get_user_model()

class ClaimsAndHandoverTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.finder = User.objects.create_user(
            username="finder", email="finder@univ.edu", password="Password123!", role="STUDENT"
        )
        self.claimant = User.objects.create_user(
            username="claimant", email="claimant@univ.edu", password="Password123!", role="STUDENT"
        )
        self.admin = User.objects.create_user(
            username="admin", email="admin@univ.edu", password="Password123!", role="ADMIN", is_staff=True
        )
        self.campus = Campus.objects.create(name="Campus A", code="CA", city="City A")
        self.found_item = ItemReport.objects.create(
            report_type="FOUND",
            title="Black Wallet",
            description="Found in lobby",
            category="WALLETS_BAGS",
            incident_date=datetime.date.today(),
            campus=self.campus,
            creator=self.finder,
            status=ReportStatus.OPEN
        )

    def test_claim_submission(self):
        self.client.force_authenticate(user=self.claimant)
        payload = {
            "item_report": self.found_item.id,
            "ownership_description": "I dropped it around 2pm while getting coffee.",
            "private_proof_details": "Has my gym card and student ID inside."
        }
        response = self.client.post('/api/claims/', payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Claim.objects.count(), 1)
        self.assertEqual(Claim.objects.first().status, ClaimStatus.PENDING)

    def test_cannot_claim_own_reported_item(self):
        self.client.force_authenticate(user=self.finder)
        payload = {
            "item_report": self.found_item.id,
            "ownership_description": "Trying to claim my own report.",
            "private_proof_details": "Details"
        }
        response = self.client.post('/api/claims/', payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_admin_review_and_handover_flow(self):
        # 1. Create claim
        claim = Claim.objects.create(
            item_report=self.found_item,
            claimant=self.claimant,
            ownership_description="Evidence",
            private_proof_details="Private details"
        )

        # 2. Admin reviews and approves
        self.client.force_authenticate(user=self.admin)
        review_resp = self.client.post(f'/api/claims/{claim.id}/review/', {
            "status": "APPROVED",
            "review_notes": "Evidence verified."
        })
        self.assertEqual(review_resp.status_code, status.HTTP_200_OK)
        claim.refresh_from_db()
        self.assertEqual(claim.status, ClaimStatus.APPROVED)
        
        # Verify handover code was generated
        self.assertTrue(hasattr(claim, 'handover'))
        handover = claim.handover
        self.assertFalse(handover.is_confirmed)
        self.assertEqual(len(handover.handover_code), 6)
        self.assertTrue(handover.recovery_receipt_number.startswith("REC-"))

        # 3. Confirm handover with wrong code fails
        fail_resp = self.client.post(f'/api/claims/{claim.id}/confirm-handover/', {
            "handover_code": "000000"
        })
        self.assertEqual(fail_resp.status_code, status.HTTP_400_BAD_REQUEST)

        # 4. Confirm handover with correct code succeeds
        success_resp = self.client.post(f'/api/claims/{claim.id}/confirm-handover/', {
            "handover_code": handover.handover_code,
            "notes": "Student ID card inspected at desk."
        })
        self.assertEqual(success_resp.status_code, status.HTTP_200_OK)

        # 5. Check item and claim marked recovered
        claim.refresh_from_db()
        self.found_item.refresh_from_db()
        self.assertEqual(claim.status, ClaimStatus.RECOVERED)
        self.assertEqual(self.found_item.status, ReportStatus.RECOVERED)
        handover.refresh_from_db()
        self.assertTrue(handover.is_confirmed)
