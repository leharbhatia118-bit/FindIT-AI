"""
Semantic and Lexical Text Similarity Engine.
Provides a pure-Python TF-IDF + Cosine Similarity and N-Gram matcher
with optional SentenceTransformers when C-extensions are permitted.
Zero blocked C-DLL dependency issues, 100% robust.
"""

import math
import re
from collections import Counter
from typing import Tuple, Dict, Any, List

def tokenize(text: str) -> List[str]:
    """Tokenize and normalize text into word stems/unigrams."""
    return re.findall(r'[a-z0-9]+', text.lower())

def extract_ngrams(tokens: List[str], n: int = 2) -> List[str]:
    """Generates word n-grams."""
    if len(tokens) < n:
        return []
    return [" ".join(tokens[i:i+n]) for i in range(len(tokens) - n + 1)]

class PureTfidfMatcher:
    """
    Robust pure-Python TF-IDF and Cosine Similarity matcher.
    Calculates sublinear term frequency and inverse document frequency.
    """
    def __init__(self, use_bigrams: bool = True):
        self.use_bigrams = use_bigrams

    def _get_features(self, text: str) -> Counter:
        tokens = tokenize(text)
        features = Counter(tokens)
        if self.use_bigrams and len(tokens) >= 2:
            features.update(extract_ngrams(tokens, 2))
        return features

    def compute_similarity(self, text_a: str, text_b: str) -> Tuple[float, List[str]]:
        features_a = self._get_features(text_a)
        features_b = self._get_features(text_b)

        if not features_a or not features_b:
            return 0.0, []

        all_terms = set(features_a.keys()).union(set(features_b.keys()))
        
        # In a 2-document corpus:
        # If term in both docs: DF=2. If in 1 doc: DF=1.
        # IDF formula: log(1 + 2 / (1 + DF)) + 1
        vec_a = {}
        vec_b = {}
        common_terms = []

        for term in all_terms:
            df = (1 if term in features_a else 0) + (1 if term in features_b else 0)
            idf = math.log(1.0 + 2.0 / (1.0 + df)) + 1.0

            tf_a = (1.0 + math.log(features_a[term])) if term in features_a else 0.0
            tf_b = (1.0 + math.log(features_b[term])) if term in features_b else 0.0

            vec_a[term] = tf_a * idf
            vec_b[term] = tf_b * idf

            if term in features_a and term in features_b:
                common_terms.append(term)

        # Dot product
        dot = sum(vec_a[term] * vec_b[term] for term in common_terms)
        norm_a = math.sqrt(sum(v ** 2 for v in vec_a.values()))
        norm_b = math.sqrt(sum(v ** 2 for v in vec_b.values()))

        if norm_a == 0 or norm_b == 0:
            return 0.0, []

        cos_sim = dot / (norm_a * norm_b)
        return max(0.0, min(1.0, cos_sim)), common_terms

_tfidf_matcher = PureTfidfMatcher(use_bigrams=True)

def compute_text_similarity(text_a: str, text_b: str) -> Tuple[float, str, Dict[str, Any]]:
    """
    Computes text similarity score between 0.0 and 1.0.
    Returns:
        (score: float, algorithm_used: str, details: dict)
    """
    if not text_a or not text_b:
        return 0.0, "EMPTY_TEXT", {"reason": "Missing text"}

    cleaned_a = text_a.strip().lower()
    cleaned_b = text_b.strip().lower()

    if cleaned_a == cleaned_b:
        return 1.0, "EXACT_MATCH", {"reason": "Exact match"}

    # Attempt neural SentenceTransformers if available and not blocked by policy
    try:
        from sentence_transformers import SentenceTransformer
        # Only load if import succeeds
        model = SentenceTransformer('all-MiniLM-L6-v2')
        embeddings = model.encode([cleaned_a, cleaned_b], normalize_embeddings=True)
        dot = float(sum(embeddings[0][i] * embeddings[1][i] for i in range(len(embeddings[0]))))
        score = max(0.0, min(1.0, dot))
        return score, "SENTENCE_TRANSFORMERS", {
            "model": "all-MiniLM-L6-v2",
            "cosine_sim": round(score, 4)
        }
    except Exception:
        pass

    # Pure Python TF-IDF fallback
    sim, common = _tfidf_matcher.compute_similarity(cleaned_a, cleaned_b)
    return round(sim, 4), "PURE_TFIDF_COSINE", {
        "model": "PureTfidf(Unigrams+Bigrams)",
        "cosine_sim": round(sim, 4),
        "matched_tokens": common[:6]
    }
