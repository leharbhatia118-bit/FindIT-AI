"""
Gemini AI Integration Service for FindIT AI.
Powered by the official google-genai SDK.

Features:
1. Multimodal Item Inspector: Generates category, color, brand, and description from uploaded item photos.
2. AI Match Synthesizer: Generates human-readable explanations of why two reports matched.
3. Ownership Cross-Examiner: Generates non-leading ownership verification challenge questions for security review.
4. Graceful Fallback: Seamlessly falls back to local algorithms if GEMINI_API_KEY is not configured or network fails.
"""

import os
import json
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class GeminiService:
    def __init__(self):
        self.api_key = os.getenv('GEMINI_API_KEY') or os.getenv('GOOGLE_API_KEY')
        self.client = None
        if self.api_key:
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                logger.warning(f"Could not initialize Google GenAI Client: {e}")

    def is_available(self) -> bool:
        return self.client is not None

    def analyze_item_image(self, image_path: str) -> Optional[Dict[str, Any]]:
        """
        Analyzes a photo of a lost/found item using Gemini 2.5 Flash.
        Extracts title, category, brand, primary_color, and key visual attributes.
        """
        if not self.is_available() or not os.path.exists(image_path):
            return None

        prompt = """
        Analyze this image of a lost or found item.
        Return ONLY a valid JSON object with the following schema:
        {
            "suggested_title": "Short concise name of item",
            "category": "ELECTRONICS" | "WALLETS_BAGS" | "KEYS" | "CARDS_IDS" | "BOOKS_STATIONERY" | "CLOTHING" | "JEWELRY_WATCHES" | "OTHER",
            "brand": "Brand name if visible or empty string",
            "primary_color": "main color name",
            "description": "2-sentence objective description of physical appearance",
            "identifying_features": ["list", "of", "distinctive", "visual", "cues"]
        }
        """

        try:
            with open(image_path, "rb") as f:
                image_bytes = f.read()

            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=[
                    prompt,
                    {"mime_type": "image/jpeg", "data": image_bytes}
                ]
            )

            text = response.text.strip()
            # Clean possible markdown fence
            if text.startswith("```json"):
                text = text[7:]
            if text.startswith("```"):
                text = text[3:]
            if text.endswith("```"):
                text = text[:-3]

            return json.loads(text.strip())
        except Exception as e:
            logger.error(f"Gemini image analysis failed: {e}")
            return None

    def explain_match(self, lost_item: Dict[str, Any], found_item: Dict[str, Any], score: float) -> str:
        """
        Synthesizes a clear, helpful AI explanation of why these two reports are likely matches.
        """
        if not self.is_available():
            return f"Matching based on high similarity ({int(score * 100)}%) across category '{lost_item.get('category')}', shared location '{lost_item.get('location_name')}', and incident date."

        prompt = f"""
        You are an AI Lost & Found matching assistant at a university.
        Explain why the following two reports are matched with a confidence score of {int(score * 100)}%:

        LOST ITEM:
        - Title: {lost_item.get('title')}
        - Category: {lost_item.get('category')}
        - Color/Brand: {lost_item.get('color')} / {lost_item.get('brand')}
        - Description: {lost_item.get('description')}
        - Lost Location: {lost_item.get('location_name')}
        - Date: {lost_item.get('date')}

        FOUND ITEM:
        - Title: {found_item.get('title')}
        - Category: {found_item.get('category')}
        - Color/Brand: {found_item.get('color')} / {found_item.get('brand')}
        - Description: {found_item.get('description')}
        - Found Location: {found_item.get('location_name')}
        - Date: {found_item.get('date')}

        Write a concise, professional 2-3 sentence explanation summarizing the strongest visual, semantic, and spatial overlaps.
        """

        try:
            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )
            return response.text.strip()
        except Exception as e:
            logger.error(f"Gemini match explanation failed: {e}")
            return f"High similarity ({int(score * 100)}%) detected across '{lost_item.get('category')}' item attributes, spatial location, and temporal proximity."

    def generate_verification_questions(self, found_item: Dict[str, Any]) -> List[str]:
        """
        Generates 2-3 non-leading verification questions that the true owner should know,
        without giving away the private details in the question.
        """
        if not self.is_available():
            return [
                "Describe any unique scratches, stickers, or distinctive marks not shown in photos.",
                "Specify any contents inside or personal identifying markers.",
                "Where and at what approximate hour did you last possess the item?"
            ]

        prompt = f"""
        You are a campus security officer verifying ownership of a found item:
        Item: {found_item.get('title')}
        Description: {found_item.get('description')}
        Category: {found_item.get('category')}

        Generate exactly 3 non-leading questions to ask a student claiming this item to prove ownership.
        Do NOT give away private clues or answer details in the questions.
        Return ONLY a JSON array of strings: ["question 1", "question 2", "question 3"]
        """

        try:
            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )
            text = response.text.strip()
            if text.startswith("```json"):
                text = text[7:]
            if text.startswith("```"):
                text = text[3:]
            if text.endswith("```"):
                text = text[:-3]
            return json.loads(text.strip())
        except Exception as e:
            logger.error(f"Gemini question generation failed: {e}")
            return [
                "Describe any unique markings, scratches, or wear patterns.",
                "Specify the exact brand/model/size and contents if applicable.",
                "Where specifically on campus do you believe you misplaced it?"
            ]

# Singleton instance
gemini_service = GeminiService()
