from rest_framework import generics, status, permissions, serializers
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db import transaction
from django.utils import timezone
from django.db.models import Q
from .models import Claim, Handover, ClaimStatus
from .serializers import (
    ClaimCreateSerializer,
    ClaimListDetailSerializer,
    ClaimReviewSerializer,
    HandoverVerificationSerializer,
    HandoverSerializer,
)
from apps.reports.models import ItemReport, ReportStatus
from apps.accounts.permissions import IsStaffOrAdminRole
from apps.accounts.models import AuditLog
from apps.notifications.services import NotificationService
from apps.notifications.models import NotificationType

class ClaimListCreateView(generics.ListCreateAPIView):
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ClaimCreateSerializer
        return ClaimListDetailSerializer

    def get_queryset(self):
        user = self.request.user
        qs = Claim.objects.select_related('item_report', 'claimant', 'reviewed_by').prefetch_related('handover').all()
        if not user.is_admin_or_staff():
            # Students see claims they submitted or claims submitted on items they found
            qs = qs.filter(Q(claimant=user) | Q(item_report__creator=user))

        status_param = self.request.query_params.get('status')
        if status_param:
            qs = qs.filter(status=status_param)

        return qs.order_by('-created_at')

    def perform_create(self, serializer):
        user = self.request.user
        item_report = serializer.validated_data['item_report']

        if item_report.creator_id == user.id:
            raise serializers.ValidationError("You cannot file an ownership claim on an item you reported yourself.")

        # Check for existing active claim by same user
        existing = Claim.objects.filter(item_report=item_report, claimant=user, status__in=['PENDING', 'UNDER_REVIEW', 'APPROVED']).exists()
        if existing:
            raise serializers.ValidationError("You already have an active claim in review for this item.")

        claim = serializer.save(claimant=user)

        # Notify item founder and admins
        NotificationService.send_notification(
            user=item_report.creator,
            title="New Ownership Claim Submitted",
            message=f"A student submitted a claim for the item you reported: '{item_report.title}'. Campus administrators will verify evidence.",
            notification_type=NotificationType.CLAIM_SUBMITTED,
            action_url=f"/claims/{claim.id}"
        )

        AuditLog.objects.create(
            user=user,
            action="CLAIM_SUBMITTED",
            resource_type="CLAIM",
            resource_id=str(claim.id),
            details={"item_title": item_report.title}
        )

class ClaimDetailView(generics.RetrieveAPIView):
    queryset = Claim.objects.select_related('item_report', 'claimant', 'reviewed_by').prefetch_related('handover').all()
    serializer_class = ClaimListDetailSerializer
    permission_classes = [permissions.IsAuthenticated]

class ClaimReviewView(APIView):
    permission_classes = [IsStaffOrAdminRole]

    def post(self, request, pk):
        try:
            claim = Claim.objects.select_related('item_report', 'claimant').get(pk=pk)
        except Claim.DoesNotExist:
            return Response({"error": "Claim not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = ClaimReviewSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        updated_claim = serializer.update(claim, serializer.validated_data)

        return Response(ClaimListDetailSerializer(updated_claim, context={'request': request}).data)

class HandoverConfirmView(APIView):
    """
    Confirms physical handover at Security / Admin desk.
    Requires valid, non-expired 6-digit code.
    Executes in an atomic transaction to prevent double-redemption.
    """
    permission_classes = [IsStaffOrAdminRole]

    def post(self, request, pk):
        try:
            claim = Claim.objects.select_related('item_report', 'claimant', 'handover').get(pk=pk)
        except Claim.DoesNotExist:
            return Response({"error": "Claim not found."}, status=status.HTTP_404_NOT_FOUND)

        if not hasattr(claim, 'handover'):
            return Response({"error": "No handover authorization found for this claim."}, status=status.HTTP_400_BAD_REQUEST)

        handover = claim.handover
        if handover.is_confirmed:
            return Response({"error": "This handover has already been confirmed."}, status=status.HTTP_400_BAD_REQUEST)

        if handover.is_expired():
            return Response({"error": "Handover OTP code has expired. A new review is required."}, status=status.HTTP_400_BAD_REQUEST)

        code_provided = request.data.get('handover_code', '').strip()
        if code_provided != handover.handover_code:
            return Response({"error": "Invalid handover code. Please check code with student."}, status=status.HTTP_400_BAD_REQUEST)

        # Atomic state transition
        with transaction.atomic():
            now = timezone.now()
            handover.is_confirmed = True
            handover.confirmed_by = request.user
            handover.confirmed_at = now
            handover.notes = request.data.get('notes', '')
            handover.save()

            claim.status = ClaimStatus.RECOVERED
            claim.save(update_fields=['status'])

            report = claim.item_report
            report.status = ReportStatus.RECOVERED
            report.save(update_fields=['status'])

            # Log audit
            AuditLog.objects.create(
                user=request.user,
                action="HANDOVER_CONFIRMED_RECOVERED",
                resource_type="HANDOVER",
                resource_id=str(handover.id),
                details={
                    "receipt": handover.recovery_receipt_number,
                    "claimant": claim.claimant.username,
                    "item_title": report.title
                }
            )

            # Notifications
            NotificationService.send_notification(
                user=claim.claimant,
                title="Item Recovered Successfully!",
                message=f"Your handover for '{report.title}' was confirmed at the desk. Receipt: {handover.recovery_receipt_number}.",
                notification_type=NotificationType.ITEM_RECOVERED,
                action_url=f"/claims/{claim.id}"
            )
            NotificationService.send_notification(
                user=report.creator,
                title="Item Handed Over to Owner",
                message=f"The item you found ('{report.title}') has been successfully recovered by its verified owner! Thank you for helping the campus community.",
                notification_type=NotificationType.ITEM_RECOVERED,
                action_url=f"/items/{report.id}"
            )

        return Response({
            "message": "Handover successfully confirmed and item marked as recovered.",
            "handover": HandoverSerializer(handover, context={'request': request}).data
        })

class GeminiQuestionsView(APIView):
    """
    Uses Gemini 2.5 Flash to generate dynamic ownership verification challenge questions.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, item_id):
        try:
            report = ItemReport.objects.get(id=item_id)
        except ItemReport.DoesNotExist:
            return Response({"error": "Item not found."}, status=status.HTTP_404_NOT_FOUND)

        from ai_engine.gemini_service import gemini_service
        item_dict = {
            'title': report.title,
            'description': report.description,
            'category': report.category,
        }
        questions = gemini_service.generate_verification_questions(item_dict)
        return Response({
            "item_id": item_id,
            "powered_by": "Google Gemini 2.5 Flash" if gemini_service.is_available() else "Local Rule Engine",
            "questions": questions
        })
