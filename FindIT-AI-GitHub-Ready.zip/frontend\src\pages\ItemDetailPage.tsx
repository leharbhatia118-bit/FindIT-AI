import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import {
  MapPin,
  Calendar,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  Lock,
  ArrowLeft,
  Share2,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Tag,
  Building,
} from 'lucide-react';
import { reportsApi, matchingApi } from '../services/api';
import { ItemReport, MatchSuggestion } from '../types';
import { useAuth } from '../context/AuthContext';
import { ClaimModal } from '../components/claims/ClaimModal';
import { ComparisonModal } from '../components/matches/ComparisonModal';

export const ItemDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, isAdmin } = useAuth();

  const [item, setItem] = useState<ItemReport | null>(null);
  const [matches, setMatches] = useState<MatchSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [matchingRunning, setMatchingRunning] = useState(false);
  const [selectedSuggestion, setSelectedSuggestion] = useState<MatchSuggestion | null>(null);

  // Modals
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [showAbuseModal, setShowAbuseModal] = useState(false);
  const [abuseReason, setAbuseReason] = useState('Suspicious information / Fake report');
  const [abuseDetails, setAbuseDetails] = useState('');
  const [abuseSuccess, setAbuseSuccess] = useState(false);

  const fetchItemData = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const data = await reportsApi.getItem(parseInt(id, 10));
      setItem(data);

      // Fetch matches for this item
      try {
        const matchData = await matchingApi.getSuggestions({ report_id: id });
        setMatches(matchData.results || []);
      } catch (e) {}
    } catch (err) {
      // not found
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItemData();
    if (searchParams.get('claim') === 'true') {
      setShowClaimModal(true);
    }
  }, [id, searchParams]);

  const handleTriggerMatching = async () => {
    if (!item) return;
    setMatchingRunning(true);
    try {
      await matchingApi.triggerMatching(item.id);
      await fetchItemData();
    } finally {
      setMatchingRunning(false);
    }
  };

  const handleReportAbuse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!item) return;
    try {
      await reportsApi.reportAbuse({
        reported_item: item.id,
        reason: abuseReason,
        details: abuseDetails,
      });
      setAbuseSuccess(true);
      setTimeout(() => {
        setShowAbuseModal(false);
        setAbuseSuccess(false);
      }, 1500);
    } catch (err) {}
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center animate-pulse">
        <div className="h-6 bg-slate-200 dark:bg-slate-700 w-1/4 mx-auto rounded mb-4"></div>
        <div className="h-64 bg-slate-200 dark:bg-slate-700 rounded-3xl w-full"></div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-800 dark:text-white">Report Not Found</h2>
        <p className="text-xs text-slate-500">The requested lost or found report does not exist or has been removed.</p>
        <button
          onClick={() => navigate('/browse')}
          className="px-4 py-2 rounded-xl bg-forest-800 text-white text-xs font-bold"
        >
          Return to Directory
        </button>
      </div>
    );
  }

  const isOwner = user?.id === item.creator;
  const isFound = item.report_type === 'FOUND';
  const hasImage = item.images && item.images.length > 0;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Back button */}
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to reports</span>
      </button>

      {/* Main Item Card */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-subtle overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 sm:p-10">
          
          {/* Image / Gallery */}
          <div className="space-y-4">
            <div className="h-72 sm:h-96 w-full rounded-2xl bg-slate-100 dark:bg-slate-700/50 overflow-hidden flex items-center justify-center relative border border-slate-200/60 dark:border-slate-700">
              {hasImage ? (
                <img
                  src={item.images[0].image}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center p-6 text-slate-400">
                  <Tag className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <span className="text-xs font-semibold uppercase tracking-wider">
                    No Image Attached
                  </span>
                  <p className="text-[11px] mt-1 text-slate-400">
                    AI matching utilizes semantic text & location taxonomy
                  </p>
                </div>
              )}

              {/* Status pill overlay */}
              <div className="absolute top-4 left-4 flex gap-2">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-extrabold uppercase shadow-sm ${
                    item.report_type === 'LOST'
                      ? 'bg-rose-500 text-white'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {item.report_type}
                </span>

                {item.status === 'RECOVERED' && (
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-600 text-white shadow-sm flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Recovered
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Details Column */}
          <div className="space-y-6 flex flex-col">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider mb-2">
                <span>{item.category.replace('_', ' ')}</span>
                {item.brand && <span>• {item.brand}</span>}
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white leading-tight">
                {item.title}
              </h1>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Public Description
              </h3>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {item.description}
              </p>
            </div>

            {/* Attributes Grid */}
            <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Date Reported</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {new Date(item.incident_date).toLocaleDateString()}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Approximate Time</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {item.incident_time_approx || 'Not specified'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Primary Color</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {item.primary_color || 'N/A'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Report Owner</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  @{item.creator_username || 'Student'}
                </span>
              </div>
            </div>

            {/* Location tag */}
            <div className="p-3.5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-300">
              <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-emerald-950 dark:text-emerald-300">
                  {item.campus_name || 'University Campus'}
                </span>
                <span>{item.location_name || item.location_detail || 'Campus Grounds'}</span>
              </div>
            </div>

            {/* Confidential Identifiers Section */}
            <div className="p-4 rounded-2xl bg-slate-100/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300">
                <Lock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Confidential Identifying Details</span>
              </div>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-mono text-[11px]">
                {item.private_identifiers || '[Protected]'}
              </p>
            </div>

            {/* Actions Bar */}
            <div className="mt-auto pt-4 flex flex-wrap items-center gap-3">
              {isFound && item.status !== 'RECOVERED' && !isOwner && (
                <button
                  onClick={() => setShowClaimModal(true)}
                  className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors shadow-md shadow-emerald-700/20 flex items-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Claim This Item</span>
                </button>
              )}

              <button
                onClick={handleTriggerMatching}
                disabled={matchingRunning}
                className="px-4 py-3 rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors flex items-center gap-2"
                title="Force AI Multi-Modal Engine to recalculate matches"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${matchingRunning ? 'animate-spin' : ''}`} />
                <span>{matchingRunning ? 'Analyzing...' : 'Run AI Match Engine'}</span>
              </button>

              <button
                onClick={() => setShowAbuseModal(true)}
                className="p-3 text-slate-400 hover:text-rose-600 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ml-auto"
                title="Report suspicious post"
              >
                <ShieldAlert className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AI Matches Section for this item */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Potential AI Matches ({matches.length})
              </h2>
              <p className="text-xs text-slate-500">
                Ranked by multi-modal cosine similarity and campus spatiotemporal distance
              </p>
            </div>
          </div>
        </div>

        {matches.length === 0 ? (
          <div className="p-8 rounded-2xl bg-white dark:bg-slate-800 border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-400">
            No matches currently above the 45% threshold. Click "Run AI Match Engine" to scan newly submitted reports.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {matches.map((m) => {
              const other = item.report_type === 'LOST' ? m.found_report_detail : m.lost_report_detail;
              return (
                <div
                  key={m.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-emerald-200/80 dark:border-emerald-900/50 shadow-subtle space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      {Math.round(m.overall_score * 100)}% Similarity
                    </span>
                    <span className="text-[11px] text-slate-400 font-medium">
                      Status: {m.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">
                    {other?.title || 'Matching Report'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                    {other?.description}
                  </p>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                    <button
                      onClick={() => setSelectedSuggestion(m)}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
                    >
                      Compare side-by-side →
                    </button>
                    {isFound && !isOwner && (
                      <button
                        onClick={() => setShowClaimModal(true)}
                        className="px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 text-white"
                      >
                        Claim Item
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Claim Modal */}
      {showClaimModal && (
        <ClaimModal
          item={item}
          onClose={() => setShowClaimModal(false)}
          onSuccess={() => {
            fetchItemData();
          }}
        />
      )}

      {/* Comparison Modal */}
      {selectedSuggestion && (
        <ComparisonModal
          suggestion={selectedSuggestion}
          onClose={() => setSelectedSuggestion(null)}
          onConfirmMatch={() => {}}
          onDismiss={() => {}}
          onInitiateClaim={(foundId) => {
            setSelectedSuggestion(null);
            setShowClaimModal(true);
          }}
        />
      )}

      {/* Abuse Report Modal */}
      {showAbuseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 max-w-md w-full space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              Report Suspicious Activity
            </h3>
            {abuseSuccess ? (
              <p className="text-xs text-emerald-600">Report filed for administrative review.</p>
            ) : (
              <form onSubmit={handleReportAbuse} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold mb-1">Reason</label>
                  <select
                    value={abuseReason}
                    onChange={(e) => setAbuseReason(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="Fake or Spam Report">Fake or Spam Report</option>
                    <option value="Offensive Content">Offensive Content</option>
                    <option value="Harassment or Impersonation">Harassment or Impersonation</option>
                    <option value="Other Policy Violation">Other Policy Violation</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1">Details (Optional)</label>
                  <textarea
                    value={abuseDetails}
                    onChange={(e) => setAbuseDetails(e.target.value)}
                    rows={3}
                    placeholder="Provide additional context..."
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  ></textarea>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAbuseModal(false)}
                    className="px-4 py-2 font-semibold text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 font-bold bg-rose-500 text-white rounded-xl"
                  >
                    Submit Report
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
