from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q
from .models import MatchSuggestion
from .serializers import MatchSuggestionSerializer
from .services import run_matching_for_report
from apps.reports.models import ItemReport

class MatchSuggestionListView(generics.ListAPIView):
    serializer_class = MatchSuggestionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        qs = MatchSuggestion.objects.select_related(
            'lost_report', 'found_report',
            'lost_report__campus', 'found_report__campus',
            'lost_report__creator', 'found_report__creator'
        ).prefetch_related(
            'lost_report__images', 'found_report__images'
        )

        # Admin can view all matches; students view matches involving their own reports
        if not user.is_admin_or_staff():
            qs = qs.filter(
                Q(lost_report__creator=user) | Q(found_report__creator=user)
            )

        report_id = self.request.query_params.get('report_id')
        if report_id:
            qs = qs.filter(Q(lost_report_id=report_id) | Q(found_report_id=report_id))

        match_status = self.request.query_params.get('status')
        if match_status:
            qs = qs.filter(status=match_status)

        return qs.order_by('-overall_score')

class MatchSuggestionDetailView(generics.RetrieveUpdateAPIView):
    queryset = MatchSuggestion.objects.select_related(
        'lost_report', 'found_report',
        'lost_report__campus', 'found_report__campus'
    ).prefetch_related(
        'lost_report__images', 'found_report__images'
    )
    serializer_class = MatchSuggestionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, *args, **kwargs):
        suggestion = self.get_object()
        user = request.user
        # Only involved user or admin can update match status
        if not (user.is_admin_or_staff() or suggestion.lost_report.creator_id == user.id or suggestion.found_report.creator_id == user.id):
            return Response({"error": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)

        new_status = request.data.get('status')
        if new_status in ['CONFIRMED_MATCH', 'DISMISSED']:
            suggestion.status = new_status
            suggestion.save(update_fields=['status'])
            return Response(MatchSuggestionSerializer(suggestion).data)
        return Response({"error": "Invalid status option."}, status=status.HTTP_400_BAD_REQUEST)

class TriggerReportMatchView(APIView):
    """
    Explicit endpoint to re-run AI matching on demand.
    Extremely valuable for judge demonstrations.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, report_id):
        try:
            report = ItemReport.objects.get(id=report_id)
        except ItemReport.DoesNotExist:
            return Response({"error": "Report not found."}, status=status.HTTP_404_NOT_FOUND)

        suggestions = run_matching_for_report(report)
        return Response({
            "message": f"AI matching engine completed. {len(suggestions)} potential match suggestion(s) evaluated/updated.",
            "suggestions_count": len(suggestions),
            "suggestions": MatchSuggestionSerializer(suggestions, many=True).data
        })
