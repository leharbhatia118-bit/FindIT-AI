"""
Configurable hyperparameters and weights for FindIT AI Matching Engine.
"""

DEFAULT_WEIGHTS = {
    'text': 0.40,
    'image': 0.30,
    'location': 0.20,
    'date': 0.10,
}

# Date decay parameter lambda in S_date = exp(-lambda * delta_days)
# lambda = 0.05 gives ~0.60 score after 10 days, ~0.36 after 20 days
DEFAULT_DATE_LAMBDA = 0.05

# Match threshold: below this, suggestion is not generated to prevent spam
SUGGESTION_THRESHOLD = 0.45

# Review recommendation thresholds
HIGH_CONFIDENCE_THRESHOLD = 0.75
MODERATE_CONFIDENCE_THRESHOLD = 0.55

# Maximum allowed distance in meters for full location score
CAMPUS_MAX_METERS = 800.0
