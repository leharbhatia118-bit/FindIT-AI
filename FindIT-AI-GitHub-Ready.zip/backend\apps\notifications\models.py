from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _

class NotificationType(models.TextChoices):
    MATCH_FOUND = 'MATCH_FOUND', _('Potential Match Found')
    CLAIM_SUBMITTED = 'CLAIM_SUBMITTED', _('New Claim Submitted')
    CLAIM_STATUS_UPDATE = 'CLAIM_STATUS_UPDATE', _('Claim Status Updated')
    HANDOVER_READY = 'HANDOVER_READY', _('Handover Code Ready')
    ITEM_RECOVERED = 'ITEM_RECOVERED', _('Item Successfully Recovered')
    SYSTEM = 'SYSTEM', _('System Alert')

class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=30, choices=NotificationType.choices, default=NotificationType.SYSTEM)
    is_read = models.BooleanField(default=False, db_index=True)
    action_url = models.CharField(max_length=255, blank=True, default='')
    email_sent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Notification to {self.user.username}: {self.title} ({'Read' if self.is_read else 'Unread'})"
