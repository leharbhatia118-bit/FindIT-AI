import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Sparkles,
  MapPin,
  Calendar,
  Lock,
  Upload,
  AlertCircle,
  Eye,
  CheckCircle2,
  Tag,
  Shield,
} from 'lucide-react';
import { reportsApi } from '../services/api';
import { Campus, CampusLocation, ItemCategory } from '../types';
import { useAuth } from '../context/AuthContext';

const reportSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters long'),
  description: z.string().min(10, 'Please provide more detail (at least 10 characters)'),
  category: z.string().min(1, 'Please select a category'),
  brand: z.string().optional(),
  primary_color: z.string().optional(),
  secondary_color: z.string().optional(),
  incident_date: z.string().min(1, 'Incident date is required'),
  incident_time_approx: z.string().optional(),
  campus: z.string().min(1, 'Please select your campus'),
  location: z.string().optional(),
  location_detail: z.string().optional(),
  private_identifiers: z.string().optional(),
});

type FormData = z.infer<typeof reportSchema>;

const CATEGORIES: { value: ItemCategory; label: string }[] = [
  { value: 'ELECTRONICS', label: 'Electronics & Gadgets' },
  { value: 'WALLETS_BAGS', label: 'Wallets, Purses & Bags' },
  { value: 'KEYS', label: 'Keys & Keychains' },
  { value: 'CARDS_IDS', label: 'ID Cards & Badges' },
  { value: 'BOOKS_STATIONERY', label: 'Books & Stationery' },
  { value: 'CLOTHING', label: 'Clothing & Accessories' },
  { value: 'JEWELRY_WATCHES', label: 'Jewelry & Watches' },
  { value: 'OTHER', label: 'Other Items' },
];

export const ReportLostPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const [campuses, setCampuses] = useState<Campus[]>([]);
  const [locations, setLocations] = useState<CampusLocation[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  useEffect(() => {
    reportsApi.getCampuses().then(setCampuses).catch(() => {});
    reportsApi.getLocations().then(setLocations).catch(() => {});
  }, []);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      incident_date: new Date().toISOString().split('T')[0],
      category: 'ELECTRONICS',
    },
  });

  const formValues = watch();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setFilePreview(URL.createObjectURL(file));
    }
  };

  const handleFinalSubmit = async (data: FormData) => {
    if (!isAuthenticated) {
      navigate('/login?redirect=/report-lost');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    try {
      const payload: any = {
        report_type: 'LOST',
        title: data.title,
        description: data.description,
        category: data.category,
        brand: data.brand || '',
        primary_color: data.primary_color || '',
        secondary_color: data.secondary_color || '',
        incident_date: data.incident_date,
        incident_time_approx: data.incident_time_approx || '',
        campus: parseInt(data.campus, 10),
        location: data.location ? parseInt(data.location, 10) : null,
        location_detail: data.location_detail || '',
        private_identifiers: data.private_identifiers || '',
      };

      const created = await reportsApi.createItem(payload);

      // Upload image if provided
      if (selectedFile) {
        const formData = new FormData();
        formData.append('image', selectedFile);
        await reportsApi.uploadImage(created.id, formData);
      }

      // Navigate to item page with match trigger
      navigate(`/items/${created.id}?created=true`);
    } catch (err: any) {
      setErrorMsg(err.response?.data?.message || 'Failed to submit lost report. Please check required fields.');
      setShowPreviewModal(false);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Title */}
      <div className="mb-8 text-center max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900 text-xs font-bold mb-3">
          <span>Official Lost Property Intake</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Report a Lost Belonging
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Provide accurate details. Our AI engine will immediately scan existing found items for candidate matches.
        </p>
      </div>

      {errorMsg && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Form */}
      <form
        onSubmit={handleSubmit(() => setShowPreviewModal(true))}
        className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 p-6 sm:p-10 shadow-subtle space-y-8"
      >
        {/* Section 1: Item Identity */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <Tag className="w-4 h-4 text-emerald-600" /> 1. Item Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Item Title *
              </label>
              <input
                type="text"
                {...register('title')}
                placeholder="e.g. Black Bellroy Leather Bifold Wallet with Red Stitching"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              {errors.title && <p className="text-xs text-rose-600 mt-1">{errors.title.message}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Category *
              </label>
              <select
                {...register('category')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Brand / Manufacturer (if known)
              </label>
              <input
                type="text"
                {...register('brand')}
                placeholder="e.g. Apple, Bellroy, Hydro Flask, Sony"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Primary Color
              </label>
              <input
                type="text"
                {...register('primary_color')}
                placeholder="e.g. Black, Matte Navy, Silver"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Secondary Color / Accent
              </label>
              <input
                type="text"
                {...register('secondary_color')}
                placeholder="e.g. Red Stitching, White Logo"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Detailed Public Description *
              </label>
              <textarea
                {...register('description')}
                rows={3}
                placeholder="Describe visible features, physical appearance, condition, and outer markings..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              ></textarea>
              {errors.description && <p className="text-xs text-rose-600 mt-1">{errors.description.message}</p>}
            </div>
          </div>
        </div>

        {/* Section 2: Location & Timing */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
          <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-600" /> 2. Location & Date Lost
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Campus *
              </label>
              <select
                {...register('campus')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="">Select Campus</option>
                {campuses.map((camp) => (
                  <option key={camp.id} value={camp.id}>
                    {camp.name}
                  </option>
                ))}
              </select>
              {errors.campus && <p className="text-xs text-rose-600 mt-1">{errors.campus.message}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Campus Building / Zone
              </label>
              <select
                {...register('location')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="">Select Building / Wing</option>
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Date Lost *
              </label>
              <input
                type="date"
                {...register('incident_date')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Approximate Time
              </label>
              <input
                type="text"
                {...register('incident_time_approx')}
                placeholder="e.g. Around 3:30 PM, after lab lecture"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Specific Location Details
              </label>
              <input
                type="text"
                {...register('location_detail')}
                placeholder="e.g. Left on table 14 near window row, second floor"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Photo Upload */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
          <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <Upload className="w-4 h-4 text-emerald-600" /> 3. Reference Photo (Optional)
          </h2>

          <div className="flex items-center gap-6">
            <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-6 text-center hover:border-emerald-500 transition-colors cursor-pointer w-full sm:w-1/2">
              <input
                type="file"
                accept="image/png, image/jpeg, image/webp"
                onChange={handleFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <Upload className="w-8 h-8 mx-auto text-slate-400 mb-2" />
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Upload item photo
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                JPG, PNG or WEBP up to 5MB
              </p>
            </div>

            {filePreview && (
              <div className="w-32 h-32 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 relative shrink-0">
                <img src={filePreview} alt="Preview" className="w-full h-full object-cover" />
              </div>
            )}
          </div>
        </div>

        {/* Section 4: Confidential Ownership Proof */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/50 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 dark:text-emerald-300">
              <Shield className="w-4 h-4 text-emerald-600" />
              <span>Confidential Identifying Details (Encrypted & Masked)</span>
            </div>
            <p className="text-[11px] text-emerald-800 dark:text-emerald-300 leading-relaxed">
              These details are NEVER shown on public cards or search results. When someone reports finding your item, administrators verify these exact answers before authorizing recovery.
            </p>
            <textarea
              {...register('private_identifiers')}
              rows={3}
              placeholder="e.g. 'Driver license ends in 9821; emergency folded $20 bill inside coin pocket; small red dot scratched on zipper.'"
              className="w-full px-3 py-2 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            ></textarea>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-6 py-3 rounded-xl text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white transition-colors shadow-md shadow-rose-500/20 flex items-center gap-2"
          >
            <Eye className="w-4 h-4" />
            <span>Review & Submit Lost Report</span>
          </button>
        </div>
      </form>

      {/* Confirmation / Preview Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Confirm Lost Item Submission
            </h3>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Title:</span>
                <span className="font-bold text-slate-900 dark:text-white">{formValues.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Category:</span>
                <span className="font-bold">{formValues.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date Lost:</span>
                <span className="font-bold">{formValues.incident_date}</span>
              </div>
              {formValues.brand && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Brand:</span>
                  <span className="font-bold">{formValues.brand}</span>
                </div>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Upon submission, FindIT AI will immediately execute real-time multi-modal candidate matching against all campus found items.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowPreviewModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300"
              >
                Back to Edit
              </button>
              <button
                type="button"
                onClick={() => handleFinalSubmit(formValues)}
                disabled={submitting}
                className="px-5 py-2.5 text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white rounded-xl shadow-sm disabled:opacity-50"
              >
                {submitting ? 'Submitting & Matching...' : 'Confirm Submission'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
