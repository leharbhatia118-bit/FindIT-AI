import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  PlusCircle,
  Package,
  ShieldCheck,
  Clock,
  ArrowRight,
  User as UserIcon,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { reportsApi, matchingApi, claimsApi } from '../services/api';
import { ItemReport, MatchSuggestion, Claim } from '../types';
import { ItemCard } from '../components/common/ItemCard';
import { CardSkeleton } from '../components/common/LoadingSkeleton';
import { EmptyState } from '../components/common/EmptyState';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState<'lost' | 'found' | 'matches' | 'claims'>('lost');
  const [lostItems, setLostItems] = useState<ItemReport[]>([]);
  const [foundItems, setFoundItems] = useState<ItemReport[]>([]);
  const [matches, setMatches] = useState<MatchSuggestion[]>([]);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      reportsApi.getMyReports('LOST'),
      reportsApi.getMyReports('FOUND'),
      matchingApi.getSuggestions(),
      claimsApi.getClaims(),
    ])
      .then(([lostRes, foundRes, matchRes, claimsRes]) => {
        setLostItems(lostRes.results || []);
        setFoundItems(foundRes.results || []);
        setMatches(matchRes.results || []);
        setClaims(claimsRes.results || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Student Profile Overview Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-forest-900 via-forest-950 to-slate-900 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center font-extrabold text-2xl text-emerald-300">
              {user?.first_name ? user.first_name[0] : 'S'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold">
                  Welcome back, {user?.first_name || user?.username}!
                </h1>
                {user?.is_verified && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> College Verified
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {user?.college_id ? `Roll / ID: ${user.college_id} • ` : ''}
                {user?.department || 'Metropolis University'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/report-lost"
              className="px-4 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
            >
              <span>Report Lost</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
            <Link
              to="/report-found"
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
            >
              <span>Report Found</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Quick KPI Counters */}
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-forest-800/80">
          <div
            onClick={() => setActiveTab('lost')}
            className="cursor-pointer p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <div className="text-2xl font-extrabold text-rose-400">{lostItems.length}</div>
            <div className="text-[11px] text-slate-400 font-medium mt-0.5">My Lost Reports</div>
          </div>

          <div
            onClick={() => setActiveTab('found')}
            className="cursor-pointer p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <div className="text-2xl font-extrabold text-emerald-400">{foundItems.length}</div>
            <div className="text-[11px] text-slate-400 font-medium mt-0.5">My Found Reports</div>
          </div>

          <div
            onClick={() => setActiveTab('matches')}
            className="cursor-pointer p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <div className="text-2xl font-extrabold text-amber-400">{matches.length}</div>
            <div className="text-[11px] text-slate-400 font-medium mt-0.5">AI Matches Found</div>
          </div>

          <div
            onClick={() => setActiveTab('claims')}
            className="cursor-pointer p-3 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <div className="text-2xl font-extrabold text-blue-400">{claims.length}</div>
            <div className="text-[11px] text-slate-400 font-medium mt-0.5">Active Claims</div>
          </div>
        </div>
      </div>

      {/* Segmented Navigation Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl max-w-xl">
        <button
          onClick={() => setActiveTab('lost')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'lost'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          My Lost Items ({lostItems.length})
        </button>
        <button
          onClick={() => setActiveTab('found')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'found'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          My Found Items ({foundItems.length})
        </button>
        <button
          onClick={() => setActiveTab('matches')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'matches'
              ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          AI Matches ({matches.length})
        </button>
        <button
          onClick={() => setActiveTab('claims')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'claims'
              ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          Claims ({claims.length})
        </button>
      </div>

      {/* Tab Contents */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : activeTab === 'lost' ? (
        lostItems.length === 0 ? (
          <EmptyState
            title="No Lost Items Reported"
            description="You haven't submitted any lost reports yet."
            actionText="Report a Lost Item"
            onAction={() => (window.location.href = '/report-lost')}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {lostItems.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )
      ) : activeTab === 'found' ? (
        foundItems.length === 0 ? (
          <EmptyState
            title="No Found Items Reported"
            description="Turn in found valuables to help campus peers recover their belongings."
            actionText="Report a Found Item"
            onAction={() => (window.location.href = '/report-found')}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {foundItems.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )
      ) : activeTab === 'matches' ? (
        matches.length === 0 ? (
          <EmptyState
            icon={Sparkles}
            title="No AI Matches Yet"
            description="When candidate matches for your items reach sufficient confidence, they will appear here."
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {matches.map((m) => (
              <div
                key={m.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-emerald-200 dark:border-emerald-900/60 shadow-subtle flex flex-col justify-between space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800">
                    {Math.round(m.overall_score * 100)}% Match
                  </span>
                  <span className="text-xs text-slate-400">{m.status}</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Lost: {m.lost_report_detail?.title} ↔ Found: {m.found_report_detail?.title}
                </h4>
                <Link
                  to="/matches"
                  className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline pt-2"
                >
                  View full comparison analysis →
                </Link>
              </div>
            ))}
          </div>
        )
      ) : (
        claims.length === 0 ? (
          <EmptyState
            icon={ShieldCheck}
            title="No Ownership Claims Filed"
            description="You currently have no claims in review or recovered."
          />
        ) : (
          <div className="space-y-4">
            {claims.map((c) => (
              <div
                key={c.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {c.item_report_detail?.title || `Claim on Item #${c.item_report}`}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Filed on {new Date(c.created_at).toLocaleDateString()} • Status: <span className="font-bold text-emerald-600">{c.status}</span>
                  </p>
                </div>
                <Link
                  to="/claims"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200"
                >
                  View Details & Handover Code
                </Link>
              </div>
            ))}
          </div>
        )
      )}

    </div>
  );
};
