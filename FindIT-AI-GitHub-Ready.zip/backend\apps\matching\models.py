from django.db import models
from django.utils.translation import gettext_lazy as _
from apps.reports.models import ItemReport

class MatchStatus(models.TextChoices):
    PENDING_REVIEW = 'PENDING_REVIEW', _('Pending Review')
    CONFIRMED_MATCH = 'CONFIRMED_MATCH', _('Confirmed Potential Match')
    DISMISSED = 'DISMISSED', _('Dismissed by Student or Admin')

class MatchAlgorithm(models.TextChoices):
    AI_EMBEDDINGS = 'AI_EMBEDDINGS', _('Neural Embeddings (SentenceTransformers + CLIP)')
    TFIDF_FALLBACK = 'TFIDF_FALLBACK', _('Lexical TF-IDF + Visual Histogram Fallback')
    HEURISTIC = 'HEURISTIC', _('Rule-Based Attribute Matching')

class MatchSuggestion(models.Model):
    lost_report = models.ForeignKey(
        ItemReport,
        on_delete=models.CASCADE,
        related_name='lost_match_suggestions',
        limit_choices_to={'report_type': 'LOST'}
    )
    found_report = models.ForeignKey(
        ItemReport,
        on_delete=models.CASCADE,
        related_name='found_match_suggestions',
        limit_choices_to={'report_type': 'FOUND'}
    )
    overall_score = models.FloatField(db_index=True, help_text="Configured multi-modal similarity score (0.0 to 1.0)")
    text_score = models.FloatField(default=0.0)
    image_score = models.FloatField(null=True, blank=True)
    location_score = models.FloatField(default=0.0)
    date_score = models.FloatField(default=0.0)
    
    weights_used = models.JSONField(default=dict, blank=True)
    algorithm_used = models.CharField(
        max_length=30,
        choices=MatchAlgorithm.choices,
        default=MatchAlgorithm.AI_EMBEDDINGS
    )
    explanation = models.JSONField(
        default=dict,
        help_text="Human-readable match explanation, strengths, and candidate comparison"
    )
    
    status = models.CharField(
        max_length=20,
        choices=MatchStatus.choices,
        default=MatchStatus.PENDING_REVIEW,
        db_index=True
    )
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-overall_score', '-created_at']
        unique_together = ('lost_report', 'found_report')

    def __str__(self):
        return f"Match #{self.id}: Lost #{self.lost_report_id} <-> Found #{self.found_report_id} ({self.overall_score*100:.1f}%)"
