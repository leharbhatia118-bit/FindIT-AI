import random
from datetime import timedelta
from rest_framework import serializers
from django.utils import timezone
from django.db import transaction
from .models import Claim, Handover, ClaimStatus
from apps.reports.serializers import ItemReportListSerializer
from apps.reports.models import ReportStatus
from apps.notifications.services import NotificationService
from apps.notifications.models import NotificationType
from apps.accounts.models import AuditLog

class HandoverSerializer(serializers.ModelSerializer):
    confirmed_by_username = serializers.CharField(source='confirmed_by.username', read_only=True)
    is_expired = serializers.BooleanField(read_only=True)

    class Meta:
        model = Handover
        fields = [
            'id', 'handover_code', 'code_expires_at', 'is_confirmed',
            'confirmed_by_username', 'confirmed_at',
            'recovery_receipt_number', 'notes', 'is_expired', 'created_at'
        ]
        read_only_fields = ['id', 'handover_code', 'code_expires_at', 'is_confirmed', 'confirmed_by_username', 'confirmed_at', 'recovery_receipt_number', 'created_at']

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        request = self.context.get('request')
        # If student and already confirmed, or if not authorized, hide handover_code
        if request and request.user.is_authenticated:
            # Student claimant can see their handover code to show security; once confirmed, masked
            if instance.is_confirmed:
                ret['handover_code'] = '***CONFIRMED***'
        return ret

class ClaimCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Claim
        fields = ['id', 'item_report', 'ownership_description', 'private_proof_details', 'proof_image']
        read_only_fields = ['id']

    def validate_item_report(self, value):
        if value.status in [ReportStatus.RECOVERED, ReportStatus.CLOSED, ReportStatus.ARCHIVED]:
            raise serializers.ValidationError("This item is no longer available for claiming.")
        return value

class ClaimListDetailSerializer(serializers.ModelSerializer):
    item_report_detail = ItemReportListSerializer(source='item_report', read_only=True)
    claimant_username = serializers.CharField(source='claimant.username', read_only=True)
    reviewer_username = serializers.CharField(source='reviewed_by.username', read_only=True)
    handover = HandoverSerializer(read_only=True)

    class Meta:
        model = Claim
        fields = [
            'id', 'item_report', 'item_report_detail', 'claimant', 'claimant_username',
            'ownership_description', 'private_proof_details', 'proof_image',
            'status', 'reviewed_by', 'reviewer_username', 'review_notes',
            'handover', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'claimant', 'created_at', 'updated_at']

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        request = self.context.get('request')
        is_owner_or_admin = False
        if request and request.user.is_authenticated:
            if request.user.id == instance.claimant_id or request.user.is_admin_or_staff():
                is_owner_or_admin = True

        # Never expose private answers to other students or public visitors
        if not is_owner_or_admin:
            ret['private_proof_details'] = "[Restricted - Visible to claimant and reviewers only]"
            ret['ownership_description'] = "[Restricted]"
        return ret

class ClaimReviewSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=[ClaimStatus.APPROVED, ClaimStatus.REJECTED, ClaimStatus.UNDER_REVIEW])
    review_notes = serializers.CharField(required=False, allow_blank=True, default='')

    def update(self, instance, validated_data):
        new_status = validated_data['status']
        instance.status = new_status
        instance.review_notes = validated_data.get('review_notes', '')
        instance.reviewed_by = self.context['request'].user
        instance.save()

        # If approved, generate Handover OTP and link record
        if new_status == ClaimStatus.APPROVED:
            # Expire in 48 hours
            code = f"{random.randint(100000, 999999)}"
            expires_at = timezone.now() + timedelta(hours=48)
            receipt = Handover.generate_receipt_number()
            
            Handover.objects.update_or_create(
                claim=instance,
                defaults={
                    'handover_code': code,
                    'code_expires_at': expires_at,
                    'recovery_receipt_number': receipt,
                    'is_confirmed': False,
                }
            )

            # Update item report status
            report = instance.item_report
            report.status = ReportStatus.CLAIM_PENDING
            report.save(update_fields=['status'])

            # Send notification
            NotificationService.send_notification(
                user=instance.claimant,
                title="Claim Approved! Handover Code Generated",
                message=f"Your claim for '{report.title}' has been approved. Your 6-digit pickup code is: {code} (expires in 48 hours). Please visit Campus Security with your College ID.",
                notification_type=NotificationType.HANDOVER_READY,
                action_url=f"/claims/{instance.id}"
            )
        elif new_status == ClaimStatus.REJECTED:
            NotificationService.send_notification(
                user=instance.claimant,
                title="Claim Update for Item",
                message=f"Your claim for '{instance.item_report.title}' was reviewed and could not be approved at this time: {instance.review_notes}",
                notification_type=NotificationType.CLAIM_STATUS_UPDATE,
                action_url=f"/claims/{instance.id}"
            )

        AuditLog.objects.create(
            user=self.context['request'].user,
            action=f"CLAIM_REVIEWED_{new_status}",
            resource_type="CLAIM",
            resource_id=str(instance.id),
            details={"status": new_status, "notes": instance.review_notes}
        )
        return instance

class HandoverVerificationSerializer(serializers.Serializer):
    handover_code = serializers.CharField(required=True, max_length=12)
    notes = serializers.CharField(required=False, allow_blank=True, default='')
