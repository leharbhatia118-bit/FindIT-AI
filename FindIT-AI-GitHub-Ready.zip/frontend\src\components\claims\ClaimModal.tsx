import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { X, ShieldCheck, Lock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { claimsApi } from '../../services/api';
import { ItemReport } from '../../types';

interface ClaimModalProps {
  item: ItemReport | null;
  onClose: () => void;
  onSuccess: () => void;
}

const claimSchema = z.object({
  ownership_description: z
    .string()
    .min(15, 'Please provide a detailed statement (minimum 15 characters)'),
  private_proof_details: z
    .string()
    .min(10, 'Please answer specific verification questions (minimum 10 characters)'),
});

type ClaimFormData = z.infer<typeof claimSchema>;

export const ClaimModal: React.FC<ClaimModalProps> = ({ item, onClose, onSuccess }) => {
  if (!item) return null;

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [geminiQuestions, setGeminiQuestions] = useState<string[]>([]);
  const [questionsSource, setQuestionsSource] = useState<string>('Google Gemini AI');

  React.useEffect(() => {
    if (item?.id) {
      claimsApi.getGeminiQuestions(item.id)
        .then((res) => {
          if (res.questions && res.questions.length > 0) {
            setGeminiQuestions(res.questions);
            setQuestionsSource(res.powered_by);
          }
        })
        .catch(() => {});
    }
  }, [item?.id]);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ClaimFormData>({
    resolver: zodResolver(claimSchema),
  });

  const onSubmit = async (data: ClaimFormData) => {
    setSubmitting(true);
    setErrorMsg(null);
    try {
      await claimsApi.createClaim({
        item_report: item.id,
        ownership_description: data.ownership_description,
        private_proof_details: data.private_proof_details,
      });
      setSuccess(true);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1800);
    } catch (err: any) {
      setErrorMsg(
        err.response?.data?.item_report?.[0] ||
        err.response?.data?.non_field_errors?.[0] ||
        'Failed to submit claim. You may already have a pending claim for this item.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-xl w-full overflow-hidden">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Submit Ownership Claim
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Claiming: <span className="font-semibold text-slate-800 dark:text-slate-200">{item.title}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {success ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Claim Filed Successfully!
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-sm mx-auto">
              Campus administration has been notified. Once approved, you will receive an in-app alert and a 6-digit physical pickup handover code.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-5">
            
            {/* Security Notice */}
            <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/50 flex items-start gap-3 text-xs text-emerald-900 dark:text-emerald-200">
              <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                Your verification answers are confidential and encrypted. They are reviewed only by authorized campus officers to prevent unauthorized claims.
              </span>
            </div>

            {errorMsg && (
              <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Field 1: Narrative */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Statement of Circumstance *
              </label>
              <textarea
                {...register('ownership_description')}
                rows={3}
                placeholder="Explain approximately when, where, and how you lost this item (e.g., 'I was studying on table 14 around 3 PM on Tuesday...')"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              ></textarea>
              {errors.ownership_description && (
                <p className="text-[11px] text-rose-600 mt-1">
                  {errors.ownership_description.message}
                </p>
              )}
            </div>

            {/* Field 2: Private identifiers */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Confidential Ownership Verification *
                </label>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-medium">
                  {questionsSource}
                </span>
              </div>

              {geminiQuestions.length > 0 && (
                <div className="mb-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                  <p className="font-semibold text-slate-700 dark:text-slate-200 text-[11px]">
                    Please answer the following verification questions:
                  </p>
                  <ul className="list-disc pl-4 space-y-1 text-[11px]">
                    {geminiQuestions.map((q, idx) => (
                      <li key={idx}>{q}</li>
                    ))}
                  </ul>
                </div>
              )}

              <textarea
                {...register('private_proof_details')}
                rows={3}
                placeholder="Answer the verification questions above or specify details NOT shown publicly (e.g. engravings, pouch contents, exact serial prefix, stickers)..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              ></textarea>
              {errors.private_proof_details && (
                <p className="text-[11px] text-rose-600 mt-1">
                  {errors.private_proof_details.message}
                </p>
              )}
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-md shadow-emerald-700/20 disabled:opacity-50"
              >
                {submitting ? 'Submitting Claim...' : 'Submit Claim for Review'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
