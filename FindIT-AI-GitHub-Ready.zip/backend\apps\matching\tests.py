import datetime
from django.test import TestCase
from django.contrib.auth import get_user_model
from apps.reports.models import Campus, CampusLocation, ItemReport
from ai_engine.matcher import AIMatchingEngine
from apps.matching.services import run_matching_for_report
from apps.matching.models import MatchSuggestion

User = get_user_model()

class AIMatchingEngineTests(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username="u1", email="u1@univ.edu", password="P1!", role="STUDENT")
        self.user2 = User.objects.create_user(username="u2", email="u2@univ.edu", password="P2!", role="STUDENT")
        self.campus = Campus.objects.create(name="Central Campus", code="CC", city="Metro")
        self.loc = CampusLocation.objects.create(campus=self.campus, name="Library 2nd Floor")

    def test_text_and_location_matching(self):
        today = datetime.date.today()
        lost = ItemReport.objects.create(
            report_type="LOST",
            title="Black Leather Bifold Wallet",
            description="Lost genuine leather black wallet with silver zipper",
            category="WALLETS_BAGS",
            brand="Fossil",
            primary_color="Black",
            incident_date=today,
            campus=self.campus,
            location=self.loc,
            creator=self.user1
        )
        found = ItemReport.objects.create(
            report_type="FOUND",
            title="Black Leather Wallet",
            description="Found black bifold wallet on study desk with silver zip",
            category="WALLETS_BAGS",
            brand="Fossil",
            primary_color="Black",
            incident_date=today,
            campus=self.campus,
            location=self.loc,
            creator=self.user2
        )

        engine = AIMatchingEngine()
        result = engine.compute_pair_score(lost, found)

        # High similarity expected on title, description, same building, same date
        self.assertGreater(result['overall_score'], 0.60)
        self.assertGreater(result['text_score'], 0.45)
        self.assertEqual(result['location_score'], 0.95)
        self.assertEqual(result['date_score'], 1.0)
        self.assertIn('explanation', result)
        self.assertTrue(len(result['explanation']['bullet_points']) > 0)

    def test_dynamic_weight_renormalization_without_images(self):
        today = datetime.date.today()
        lost = ItemReport.objects.create(
            report_type="LOST", title="Keys", description="Keys", category="KEYS",
            incident_date=today, campus=self.campus, creator=self.user1
        )
        found = ItemReport.objects.create(
            report_type="FOUND", title="Keys", description="Keys", category="KEYS",
            incident_date=today, campus=self.campus, creator=self.user2
        )

        engine = AIMatchingEngine()
        result = engine.compute_pair_score(lost, found)
        # Weights should sum to 1.0 even without images
        weights = result['weights_used']
        self.assertAlmostEqual(sum(weights.values()), 1.0, places=2)
        self.assertNotIn('image', weights)

    def test_service_generates_match_suggestion(self):
        today = datetime.date.today()
        lost = ItemReport.objects.create(
            report_type="LOST", title="Blue Umbrella", description="Compact rain umbrella",
            category="OTHER", incident_date=today, campus=self.campus, creator=self.user1
        )
        found = ItemReport.objects.create(
            report_type="FOUND", title="Blue Compact Umbrella", description="Dark blue umbrella left in lobby",
            category="OTHER", incident_date=today, campus=self.campus, creator=self.user2
        )

        suggestions = run_matching_for_report(lost)
        self.assertEqual(len(suggestions), 1)
        self.assertEqual(MatchSuggestion.objects.count(), 1)
        sugg = MatchSuggestion.objects.first()
        self.assertEqual(sugg.lost_report, lost)
        self.assertEqual(sugg.found_report, found)
