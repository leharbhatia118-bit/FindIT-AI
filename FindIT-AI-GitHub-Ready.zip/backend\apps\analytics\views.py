import statistics
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions
from django.db.models import Count, Q
from apps.reports.models import ItemReport, CampusLocation, ReportStatus, ItemCategory
from apps.matching.models import MatchSuggestion
from apps.claims.models import Claim, Handover, ClaimStatus
from apps.accounts.models import AuditLog, User
from apps.accounts.permissions import IsAdminRole

class AdminAnalyticsView(APIView):
    """
    Computes real, dynamic platform analytics directly from database tables.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        is_admin = request.user.is_authenticated and request.user.is_admin_or_staff()

        total_reports = ItemReport.objects.count()
        lost_count = ItemReport.objects.filter(report_type='LOST').count()
        found_count = ItemReport.objects.filter(report_type='FOUND').count()
        active_reports = ItemReport.objects.filter(status__in=[ReportStatus.OPEN, ReportStatus.POTENTIAL_MATCH]).count()
        
        potential_matches = MatchSuggestion.objects.count()
        pending_claims = Claim.objects.filter(status__in=[ClaimStatus.PENDING, ClaimStatus.UNDER_REVIEW]).count()
        confirmed_recoveries = Handover.objects.filter(is_confirmed=True).count()

        # Recovery rate calculation
        # Denominator: Total reports filed on the platform
        recovery_rate = (confirmed_recoveries / total_reports * 100.0) if total_reports > 0 else 0.0

        # Calculate median recovery time (hours) from report creation to handover confirmation
        confirmed_handovers = Handover.objects.filter(is_confirmed=True, confirmed_at__isnull=False).select_related('claim__item_report')
        durations_hours = []
        for h in confirmed_handovers:
            if h.confirmed_at and h.claim and h.claim.item_report:
                delta = h.confirmed_at - h.claim.item_report.created_at
                hours = delta.total_seconds() / 3600.0
                if hours >= 0:
                    durations_hours.append(hours)

        median_recovery_hours = round(statistics.median(durations_hours), 1) if durations_hours else None

        # Category Breakdown
        categories_data = []
        cat_counts = ItemReport.objects.values('category').annotate(count=Count('id')).order_by('-count')
        for item in cat_counts:
            cat_key = item['category']
            label = dict(ItemCategory.choices).get(cat_key, cat_key)
            categories_data.append({
                "category": cat_key,
                "label": str(label),
                "count": item['count'],
                "percentage": round((item['count'] / total_reports * 100.0), 1) if total_reports > 0 else 0
            })

        # Location Hotspots (top campus buildings/locations)
        location_counts = (
            ItemReport.objects.filter(location__isnull=False)
            .values('location__name', 'campus__name')
            .annotate(count=Count('id'))
            .order_by('-count')[:8]
        )
        location_hotspots = [
            {
                "location": item['location__name'],
                "campus": item['campus__name'],
                "count": item['count']
            }
            for item in location_counts
        ]

        # Recent Platform Activity
        recent_activity = []
        recent_audits = AuditLog.objects.select_related('user').all()[:10]
        for a in recent_audits:
            recent_activity.append({
                "id": a.id,
                "action": a.action,
                "username": a.user.username if a.user else "System",
                "resource_type": a.resource_type,
                "resource_id": a.resource_id,
                "timestamp": a.created_at.isoformat(),
            })

        return Response({
            "overview": {
                "total_reports": total_reports,
                "lost_reports": lost_count,
                "found_reports": found_count,
                "active_reports": active_reports,
                "potential_matches": potential_matches,
                "pending_claims": pending_claims,
                "confirmed_recoveries": confirmed_recoveries,
                "recovery_rate_percentage": round(recovery_rate, 1),
                "recovery_rate_definition": "Confirmed Recoveries / Total Reports Filed",
                "median_recovery_time_hours": median_recovery_hours,
                "total_students": User.objects.filter(role='STUDENT').count()
            },
            "category_distribution": categories_data,
            "location_hotspots": location_hotspots,
            "recent_activity": recent_activity
        })
