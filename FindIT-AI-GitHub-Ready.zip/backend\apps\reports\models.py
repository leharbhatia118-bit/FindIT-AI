from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _

class ReportType(models.TextChoices):
    LOST = 'LOST', _('Lost Item')
    FOUND = 'FOUND', _('Found Item')

class ItemCategory(models.TextChoices):
    ELECTRONICS = 'ELECTRONICS', _('Electronics & Gadgets')
    WALLETS_BAGS = 'WALLETS_BAGS', _('Wallets, Purses & Bags')
    KEYS = 'KEYS', _('Keys & Keychains')
    CARDS_IDS = 'CARDS_IDS', _('ID Cards & Documents')
    BOOKS_STATIONERY = 'BOOKS_STATIONERY', _('Books & Stationery')
    CLOTHING = 'CLOTHING', _('Clothing & Accessories')
    JEWELRY_WATCHES = 'JEWELRY_WATCHES', _('Jewelry & Watches')
    OTHER = 'OTHER', _('Other Items')

class ReportStatus(models.TextChoices):
    OPEN = 'OPEN', _('Open / Active')
    POTENTIAL_MATCH = 'POTENTIAL_MATCH', _('Potential Match Identified')
    CLAIM_PENDING = 'CLAIM_PENDING', _('Claim Pending Review')
    RECOVERED = 'RECOVERED', _('Successfully Recovered')
    ARCHIVED = 'ARCHIVED', _('Archived / Expired')
    CLOSED = 'CLOSED', _('Closed by User')

class Campus(models.Model):
    name = models.CharField(max_length=150, unique=True)
    code = models.CharField(max_length=20, unique=True)
    city = models.CharField(max_length=100)
    latitude = models.FloatField(default=12.9716, help_text="Center latitude")
    longitude = models.FloatField(default=77.5946, help_text="Center longitude")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.code})"

class CampusLocation(models.Model):
    campus = models.ForeignKey(Campus, on_delete=models.CASCADE, related_name='locations')
    name = models.CharField(max_length=150)
    building_code = models.CharField(max_length=30, blank=True)
    zone_or_floor = models.CharField(max_length=100, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    description = models.TextField(blank=True)

    class Meta:
        unique_together = ('campus', 'name')

    def __str__(self):
        return f"{self.name} - {self.campus.code}"

class ItemReport(models.Model):
    report_type = models.CharField(max_length=10, choices=ReportType.choices, db_index=True)
    title = models.CharField(max_length=200, db_index=True)
    description = models.TextField()
    category = models.CharField(max_length=30, choices=ItemCategory.choices, db_index=True)
    
    brand = models.CharField(max_length=100, blank=True, null=True)
    primary_color = models.CharField(max_length=50, blank=True, null=True)
    secondary_color = models.CharField(max_length=50, blank=True, null=True)
    
    incident_date = models.DateField(db_index=True)
    incident_time_approx = models.CharField(max_length=50, blank=True, default='')
    
    campus = models.ForeignKey(Campus, on_delete=models.CASCADE, related_name='reports')
    location = models.ForeignKey(CampusLocation, on_delete=models.SET_NULL, null=True, blank=True, related_name='reports')
    location_detail = models.CharField(max_length=255, blank=True, default='')
    
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    
    creator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reports')
    status = models.CharField(max_length=20, choices=ReportStatus.choices, default=ReportStatus.OPEN, db_index=True)
    
    # Sensitive field: NEVER exposed to public API responses
    private_identifiers = models.TextField(
        blank=True,
        default='',
        help_text="Private marks, serial number prefix, internal markings (visible only to reporter and admins)"
    )
    
    contact_preference = models.CharField(
        max_length=20,
        choices=[('IN_APP', 'In-App Only'), ('EMAIL', 'College Email')],
        default='IN_APP'
    )
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.report_type}] {self.title} ({self.get_status_display()})"

class ItemImage(models.Model):
    report = models.ForeignKey(ItemReport, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='reports/%Y/%m/')
    caption = models.CharField(max_length=200, blank=True, default='')
    # Cached feature vector or color histogram for fast AI similarity comparison
    feature_embedding = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for Report #{self.report_id}"

class AbuseReport(models.Model):
    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='abuse_reports_filed')
    reported_item = models.ForeignKey(ItemReport, on_delete=models.CASCADE, related_name='abuse_reports')
    reason = models.CharField(max_length=150)
    details = models.TextField(blank=True)
    status = models.CharField(
        max_length=20,
        choices=[('PENDING', 'Pending Review'), ('RESOLVED', 'Resolved'), ('DISMISSED', 'Dismissed')],
        default='PENDING',
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Abuse Report #{self.id} on Report #{self.reported_item_id} ({self.status})"
