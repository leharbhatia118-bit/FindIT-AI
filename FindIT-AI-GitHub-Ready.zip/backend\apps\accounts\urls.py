from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import (
    RegisterView,
    MeView,
    UpdateProfileView,
    ChangePasswordView,
    VerifyCollegeEmailView,
    UserListView,
    AuditLogListView,
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('me/', MeView.as_view(), name='user_me'),
    path('profile/', UpdateProfileView.as_view(), name='update_profile'),
    path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    path('verify-email/', VerifyCollegeEmailView.as_view(), name='verify_email'),
    path('users/', UserListView.as_view(), name='admin_user_list'),
    path('audit-logs/', AuditLogListView.as_view(), name='admin_audit_logs'),
]
