import axios from 'axios';
import {
  User,
  ItemReport,
  Campus,
  CampusLocation,
  MatchSuggestion,
  Claim,
  NotificationItem,
  AnalyticsData,
} from '../types';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request Interceptor: Attach JWT access token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response Interceptor: Handle 401 & Refresh Token
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      const refreshToken = localStorage.getItem('refresh_token');
      if (refreshToken) {
        try {
          const res = await axios.post('/api/auth/token/refresh/', {
            refresh: refreshToken,
          });
          const newAccess = res.data.access;
          localStorage.setItem('access_token', newAccess);
          originalRequest.headers.Authorization = `Bearer ${newAccess}`;
          return api(originalRequest);
        } catch (refreshErr) {
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
          localStorage.removeItem('user');
          window.dispatchEvent(new Event('auth:logout'));
        }
      }
    }
    return Promise.reject(error);
  }
);

// Auth Endpoints
export const authApi = {
  login: async (credentials: any) => {
    const res = await api.post('/auth/login/', credentials);
    return res.data;
  },
  register: async (userData: any) => {
    const res = await api.post('/auth/register/', userData);
    return res.data;
  },
  getMe: async (): Promise<User> => {
    const res = await api.get('/auth/me/');
    return res.data;
  },
  updateProfile: async (data: any) => {
    const res = await api.patch('/auth/profile/', data);
    return res.data;
  },
  changePassword: async (data: any) => {
    const res = await api.post('/auth/change-password/', data);
    return res.data;
  },
  verifyCollegeEmail: async (code: string) => {
    const res = await api.post('/auth/verify-email/', { code });
    return res.data;
  },
  getUsers: async () => {
    const res = await api.get('/auth/users/');
    return res.data;
  },
  getAuditLogs: async () => {
    const res = await api.get('/auth/audit-logs/');
    return res.data;
  },
};

// Reports Endpoints
export const reportsApi = {
  getCampuses: async (): Promise<Campus[]> => {
    const res = await api.get('/campuses/');
    return res.data.results || res.data;
  },
  getLocations: async (campusId?: number): Promise<CampusLocation[]> => {
    const params = campusId ? { campus: campusId } : {};
    const res = await api.get('/locations/', { params });
    return res.data.results || res.data;
  },
  getItems: async (params?: any): Promise<{ results: ItemReport[]; count: number }> => {
    const res = await api.get('/items/', { params });
    return res.data;
  },
  getItem: async (id: number): Promise<ItemReport> => {
    const res = await api.get(`/items/${id}/`);
    return res.data;
  },
  createItem: async (data: any): Promise<ItemReport> => {
    const res = await api.post('/items/', data);
    return res.data;
  },
  updateItem: async (id: number, data: any): Promise<ItemReport> => {
    const res = await api.patch(`/items/${id}/`, data);
    return res.data;
  },
  deleteItem: async (id: number) => {
    const res = await api.delete(`/items/${id}/`);
    return res.data;
  },
  uploadImage: async (reportId: number, formData: FormData) => {
    const res = await api.post(`/items/${reportId}/images/`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },
  getMyReports: async (reportType?: string): Promise<{ results: ItemReport[]; count: number }> => {
    const params = reportType ? { report_type: reportType } : {};
    const res = await api.get('/my-reports/', { params });
    return res.data;
  },
  reportAbuse: async (data: { reported_item: number; reason: string; details?: string }) => {
    const res = await api.post('/abuse-reports/', data);
    return res.data;
  },
  getAbuseReportsAdmin: async () => {
    const res = await api.get('/admin/abuse-reports/');
    return res.data;
  },
};

// AI Matching Endpoints
export const matchingApi = {
  getSuggestions: async (params?: any): Promise<{ results: MatchSuggestion[]; count: number }> => {
    const res = await api.get('/matching/suggestions/', { params });
    return res.data;
  },
  getSuggestion: async (id: number): Promise<MatchSuggestion> => {
    const res = await api.get(`/matching/suggestions/${id}/`);
    return res.data;
  },
  updateSuggestionStatus: async (id: number, status: 'CONFIRMED_MATCH' | 'DISMISSED') => {
    const res = await api.patch(`/matching/suggestions/${id}/`, { status });
    return res.data;
  },
  triggerMatching: async (reportId: number) => {
    const res = await api.post(`/matching/trigger/${reportId}/`);
    return res.data;
  },
};

// Claims Endpoints
export const claimsApi = {
  getClaims: async (params?: any): Promise<{ results: Claim[]; count: number }> => {
    const res = await api.get('/claims/', { params });
    return res.data;
  },
  getClaim: async (id: number): Promise<Claim> => {
    const res = await api.get(`/claims/${id}/`);
    return res.data;
  },
  createClaim: async (data: { item_report: number; ownership_description: string; private_proof_details: string }): Promise<Claim> => {
    const res = await api.post('/claims/', data);
    return res.data;
  },
  getGeminiQuestions: async (itemId: number): Promise<{ item_id: number; powered_by: string; questions: string[] }> => {
    const res = await api.get(`/items/${itemId}/gemini-questions/`);
    return res.data;
  },
  reviewClaim: async (claimId: number, reviewData: { status: string; review_notes?: string }): Promise<Claim> => {
    const res = await api.post(`/claims/${claimId}/review/`, reviewData);
    return res.data;
  },
  confirmHandover: async (claimId: number, data: { handover_code: string; notes?: string }) => {
    const res = await api.post(`/claims/${claimId}/confirm-handover/`, data);
    return res.data;
  },
};

// Notifications Endpoints
export const notificationsApi = {
  getNotifications: async (): Promise<{ results: NotificationItem[]; unread_count: number }> => {
    const res = await api.get('/notifications/');
    return res.data;
  },
  markRead: async (id: number) => {
    const res = await api.patch(`/notifications/${id}/read/`);
    return res.data;
  },
  markAllRead: async () => {
    const res = await api.post('/notifications/read-all/');
    return res.data;
  },
};

// Analytics Endpoints
export const analyticsApi = {
  getAdminAnalytics: async (): Promise<AnalyticsData> => {
    const res = await api.get('/admin/analytics/');
    return res.data;
  },
  getPublicStats: async (): Promise<AnalyticsData> => {
    const res = await api.get('/public/stats/');
    return res.data;
  },
};

export default api;
