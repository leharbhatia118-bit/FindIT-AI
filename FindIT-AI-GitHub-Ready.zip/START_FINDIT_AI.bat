@echo off
echo ========================================================
echo        Starting FindIT AI Full-Stack Platform
echo ========================================================
echo.

set PATH=C:\Users\lehar\AppData\Local\Programs\nodejs;%PATH%

echo [1/2] Launching Django Backend Server...
start "FindIT AI Backend" cmd /k "cd backend && ..\..\.gemini\antigravity\scratch\findit-ai\backend\venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000"

echo [2/2] Launching React Vite Frontend Server...
start "FindIT AI Frontend" cmd /k "cd frontend && npm run dev"

echo.
echo ========================================================
echo  Both servers starting!
echo  Open your browser at: http://localhost:5173
echo ========================================================
timeout /t 5
start http://localhost:5173
