from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from .serializers import (
    UserSerializer,
    RegisterSerializer,
    StudentProfileSerializer,
    ChangePasswordSerializer,
    AuditLogSerializer,
)
from .models import AuditLog, StudentProfile
from .permissions import IsAdminRole

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        # Generate JWT tokens immediately upon registration
        refresh = RefreshToken.for_user(user)

        # Log audit entry
        AuditLog.objects.create(
            user=user,
            action="USER_REGISTERED",
            resource_type="USER",
            resource_id=str(user.id),
            details={"username": user.username, "role": user.role}
        )

        return Response({
            "user": UserSerializer(user, context={'request': request}).data,
            "access": str(refresh.access_token),
            "refresh": str(refresh),
            "message": "Registration successful."
        }, status=status.HTTP_201_CREATED)

class MeView(generics.RetrieveUpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user

class UpdateProfileView(generics.UpdateAPIView):
    serializer_class = StudentProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        profile, _ = StudentProfile.objects.get_or_create(user=self.request.user)
        return profile

class ChangePasswordView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = request.user
        if not user.check_password(serializer.validated_data['old_password']):
            return Response({"old_password": ["Current password is incorrect."]}, status=status.HTTP_400_BAD_REQUEST)
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        AuditLog.objects.create(
            user=user,
            action="PASSWORD_CHANGED",
            resource_type="USER",
            resource_id=str(user.id)
        )
        return Response({"message": "Password changed successfully."})

class VerifyCollegeEmailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        code = request.data.get('code', '').strip()
        # Simulated OTP validation (accepts '123456' or auto-verifies .edu email)
        if code == '123456' or (user.email and (user.email.endswith('.edu') or user.email.endswith('.ac.in'))):
            user.is_verified = True
            user.save()
            AuditLog.objects.create(
                user=user,
                action="EMAIL_VERIFIED",
                resource_type="USER",
                resource_id=str(user.id)
            )
            return Response({"message": "College ID and email successfully verified.", "is_verified": True})
        return Response({"error": "Invalid verification code. Use demo code '123456'."}, status=status.HTTP_400_BAD_REQUEST)

class UserListView(generics.ListAPIView):
    queryset = User.objects.all().order_by('-created_at')
    serializer_class = UserSerializer
    permission_classes = [IsAdminRole]

class AuditLogListView(generics.ListAPIView):
    queryset = AuditLog.objects.all().order_by('-created_at')
    serializer_class = AuditLogSerializer
    permission_classes = [IsAdminRole]
