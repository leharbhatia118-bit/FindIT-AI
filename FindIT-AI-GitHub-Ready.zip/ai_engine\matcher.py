"""
Core AI Matching Engine for FindIT AI.
Implements multi-modal scoring pipeline, dynamic weight renormalization,
transparent fallback attribution, and explainable recommendations.
"""

import logging
from typing import Dict, Any, List, Optional
from .constants import (
    DEFAULT_WEIGHTS,
    DEFAULT_DATE_LAMBDA,
    SUGGESTION_THRESHOLD,
    HIGH_CONFIDENCE_THRESHOLD,
    MODERATE_CONFIDENCE_THRESHOLD,
)
from .text_similarity import compute_text_similarity
from .image_similarity import compute_image_similarity
from .geo_similarity import compute_location_similarity
from .date_similarity import compute_date_similarity

logger = logging.getLogger(__name__)

class AIMatchingEngine:
    def __init__(self, weights: Optional[Dict[str, float]] = None, date_lambda: float = DEFAULT_DATE_LAMBDA):
        self.weights = weights or dict(DEFAULT_WEIGHTS)
        self.date_lambda = date_lambda

    def filter_candidates(self, target_report, candidate_queryset):
        """
        Step 1: Candidate Filtering.
        - Lost matches Found, Found matches Lost
        - Only active reports (OPEN or POTENTIAL_MATCH)
        - Filter out incompatible categories
        - Prevent matching items submitted by the exact same user
        """
        opposing_type = 'FOUND' if target_report.report_type == 'LOST' else 'LOST'
        
        candidates = candidate_queryset.filter(
            report_type=opposing_type,
            status__in=['OPEN', 'POTENTIAL_MATCH']
        ).exclude(creator=target_report.creator)

        # Category compatibility
        if target_report.category != 'OTHER':
            candidates = candidates.filter(category__in=[target_report.category, 'OTHER'])

        return candidates

    def compute_pair_score(self, report_lost, report_found) -> Dict[str, Any]:
        """
        Computes the multi-modal match between a LOST report and a FOUND report.
        """
        # 1. Text Similarity
        text_lost = f"{report_lost.title} {report_lost.description} {report_lost.brand or ''} {report_lost.primary_color or ''}"
        text_found = f"{report_found.title} {report_found.description} {report_found.brand or ''} {report_found.primary_color or ''}"
        text_score, text_algo, text_details = compute_text_similarity(text_lost, text_found)

        # 2. Image Similarity
        image_score = None
        image_algo = "NO_IMAGE"
        # Find best image pair comparison if images exist
        img_lost = report_lost.images.first()
        img_found = report_found.images.first()

        if img_lost and img_found and img_lost.feature_embedding and img_found.feature_embedding:
            sim, algo = compute_image_similarity(img_lost.feature_embedding, img_found.feature_embedding)
            if sim is not None:
                image_score = sim
                image_algo = algo

        # 3. Location Similarity
        loc_score, loc_method, loc_details = compute_location_similarity(report_lost, report_found)

        # 4. Date Similarity
        date_score, date_details = compute_date_similarity(
            report_lost.incident_date,
            report_found.incident_date,
            self.date_lambda
        )

        # 5. Dynamic Weight Renormalization
        # Determine available modalities
        available_weights = {
            'text': self.weights['text'],
            'location': self.weights['location'],
            'date': self.weights['date'],
        }

        if image_score is not None:
            available_weights['image'] = self.weights['image']

        weight_sum = sum(available_weights.values())
        norm_weights = {k: v / weight_sum for k, v in available_weights.items()}

        # 6. Combined Weighted Score
        overall_score = (
            norm_weights['text'] * text_score +
            norm_weights['location'] * loc_score +
            norm_weights['date'] * date_score
        )

        if image_score is not None:
            overall_score += norm_weights['image'] * image_score

        overall_score = max(0.0, min(1.0, round(overall_score, 4)))

        # 7. Generate Explainability
        explanations = []
        if text_score >= 0.70:
            explanations.append(f"High text & description correlation ({round(text_score*100)}%)")
        elif text_score >= 0.45:
            explanations.append(f"Moderate keyword and semantic overlap ({round(text_score*100)}%)")

        if image_score is not None:
            if image_score >= 0.75:
                explanations.append(f"Strong visual feature resemblance ({round(image_score*100)}%)")
            elif image_score >= 0.50:
                explanations.append(f"Moderate color/appearance similarity ({round(image_score*100)}%)")

        if loc_score >= 0.80:
            explanations.append(f"Close physical proximity: {loc_method.replace('_', ' ').title()}")
        elif loc_score >= 0.40:
            explanations.append("Reported within the same campus zone")

        if date_score >= 0.80:
            explanations.append(f"Closely aligned dates (difference of {abs(date_details.get('delta_days', 0))} day(s))")

        if not explanations:
            explanations.append("Initial category and campus match under evaluation")

        # 8. Recommendation
        if overall_score >= HIGH_CONFIDENCE_THRESHOLD:
            recommendation = "HIGH_CONFIDENCE_MATCH"
        elif overall_score >= MODERATE_CONFIDENCE_THRESHOLD:
            recommendation = "RECOMMEND_ADMIN_OR_USER_REVIEW"
        else:
            recommendation = "LOW_PROBABILITY_SUGGESTION"

        # Determine primary algorithm label
        primary_algorithm = "AI_EMBEDDINGS" if text_algo == "SENTENCE_TRANSFORMERS" else "TFIDF_FALLBACK"

        return {
            "overall_score": overall_score,
            "text_score": round(text_score, 4),
            "image_score": round(image_score, 4) if image_score is not None else None,
            "location_score": round(loc_score, 4),
            "date_score": round(date_score, 4),
            "weights_used": {k: round(v, 4) for k, v in norm_weights.items()},
            "algorithm_used": primary_algorithm,
            "explanation": {
                "bullet_points": explanations,
                "recommendation": recommendation,
                "text_method": text_algo,
                "image_method": image_algo,
                "location_method": loc_method,
                "date_details": date_details,
            }
        }
