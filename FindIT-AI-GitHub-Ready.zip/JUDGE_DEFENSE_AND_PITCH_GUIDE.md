# FindIT AI — Hackathon Presentation & Judge Defense Guide 🏆

Use this guide to master your pitch, explain every technical layer, and counter any tough judge questions with confidence.

---

## 1. The 60-Second Winning Elevator Pitch

> *"Good morning/afternoon judges! Every day across colleges, hundreds of valuable items—wallets, IDs, AirPods, laptops—go missing. Right now, students rely on cluttered WhatsApp groups and notice boards where reports get lost in chat noise, false ownership claims are rampant, and recovery rates are dismal.*
>
> *We built **FindIT AI**, a production-grade, AI-powered lost-and-found platform engineered specifically for campuses. It doesn't just list items; it features a **multi-modal AI matching engine** that pairs lost and found reports using NLP semantic text similarity, visual color feature matching, campus spatial proximity, and temporal decay.*
> 
> *We integrated **Google Gemini 2.5 Flash** to provide explainable match summaries and generate non-leading ownership verification questions. Most importantly, we solved the fraud problem with **zero-knowledge privacy masking** and an expiring **6-digit cryptographic OTP handover workflow**."*

---

## 2. Technologies Used & Why You Chose Them

When judges ask *"What is your tech stack and why didn't you just use X?"*, here is your structured answer:

| Layer | Technology | Why You Chose It (Judge Response) |
|---|---|---|
| **Frontend UI** | **React 18 + Vite + TypeScript** | *"Vite provides instant HMR and lightweight bundle sizes. TypeScript enforces strict type safety across our data models (reports, claims, matches), preventing runtime bugs."* |
| **Styling & UX** | **Tailwind CSS + Lucide Icons + Recharts** | *"Clean startup-grade design tokens, accessible light/dark modes, and live SVG chart data visualization for the administrative dashboard."* |
| **Backend API** | **Python + Django 6.1 + Django REST Framework** | *"Django provides enterprise-grade ORM security against SQL injections, built-in migration versioning, and DRF offers structured REST endpoints with OpenAPI/Swagger auto-documentation."* |
| **Security & Auth** | **JWT (JSON Web Tokens) with Refresh Rotation** | *"Stateless, scalable authentication with auto-refresh interceptors in Axios. Role-based access controls for Students, Staff, and Administrators."* |
| **AI Matching Engine** | **Multi-Modal Algorithmic Pipeline (`ai_engine/`)** | *"Combines 4 independent scoring vectors: TF-IDF & N-gram cosine text similarity, 24-bin RGB color histograms, Haversine geospatial distance, and exponential time decay."* |
| **Generative AI** | **Google Gemini 2.5 Flash (`google-genai` SDK)** | *"Powers dynamic explainability: explains in plain English why two items matched, and acts as a cross-examiner generating ownership verification challenge questions."* |
| **Database** | **SQLite (Dev) / PostgreSQL (Dockerized Prod)** | *"Fully relational ACID-compliant schema with proper foreign keys, unique constraints, and database indexes."* |

---

## 3. How the AI Matching Engine Actually Works

Judges will ask: *"Is the AI matching real or just hardcoded fake numbers?"*

### Your Answer:
> *"The matching engine is 100% real mathematical computation. Every time a student reports a found item or lost item, our pipeline runs an automated 5-step multi-modal scoring pipeline:"*

$$\text{Final Score} = w_{\text{text}} S_{\text{text}} + w_{\text{img}} S_{\text{img}} + w_{\text{loc}} S_{\text{loc}} + w_{\text{date}} S_{\text{date}}$$

1. **Text Similarity ($S_{\text{text}}$, default weight 0.40):**
   - Tokenizes titles and descriptions into unigrams and bigrams.
   - Computes sublinear TF-IDF term weighting and calculates high-dimensional **Cosine Similarity**.
2. **Visual Feature Similarity ($S_{\text{img}}$, default weight 0.30):**
   - Extracts 24-bin normalized RGB color histogram vectors from uploaded photos and evaluates vector distance.
3. **Location Proximity ($S_{\text{loc}}$, default weight 0.20):**
   - Calculates real geographical distance using the **Haversine Great-Circle formula** between campus building GPS coordinates ($d = 2R \arcsin(\dots)$), decaying smoothly within campus boundaries.
4. **Temporal Decay ($S_{\text{date}}$, default weight 0.10):**
   - An exponential time decay function: $S_{\text{date}} = e^{-\lambda \cdot |\Delta\text{days}|}$ ($\lambda = 0.05$). Items lost and found on the same afternoon score near 1.0; items reported weeks apart naturally decay.
5. **Dynamic Weight Renormalization (Our Big Innovation):**
   - *"If a student reports an item without a photo or without exact coordinates, naive algorithms divide by zero or penalize the user with a 0%. Our engine dynamically renormalizes remaining weights: $\tilde{w}_i = \frac{w_i}{\sum_{k \in \text{available}} w_k}$ so scores remain mathematically accurate."*
6. **Gemini 2.5 Flash Synthesis:**
   - Gemini receives the attribute vectors of the candidate pair and outputs a concise human-readable explanation of why the match was flagged.

---

## 4. How the Security & Privacy Protection Works

Judges will ask: *"What stops someone from claiming an expensive item that isn't theirs?"*

### Your Answer:
> *"We solved campus item fraud using a 3-layer Zero-Knowledge verification model:"*

1. **Zero-Knowledge Privacy Masking:**
   - When reporting an item, sensitive identifiers (e.g. cash amount in wallet, laptop serial numbers, lockscreen wallpaper, engravings) are stored in encrypted `private_details`.
   - Our Django serializers **strip these fields** from all public browse, search, and detail API endpoints. A student browsing the site can never see them.
2. **Gemini Ownership Challenge Questions:**
   - When a claimant clicks "Claim Item", Gemini generates non-leading questions (e.g. *"Describe any unique scratches or stickers"* or *"Specify any interior pouch contents"*).
   - The claimant must submit their proof blind.
3. **Expiring 6-Digit OTP Handover:**
   - Once staff reviews and approves the claim, the system generates an expiring cryptographic 6-digit OTP for the verified owner.
   - The handover happens physically at the security desk where the officer enters the OTP into the system. The transaction is atomically marked `RECOVERED` and logged to an immutable audit trail.

---

## 5. Countering Tough Judge Questions (Q&A Cheat Sheet)

### Q1: *"Are the demo cases and matches real, or did you fake the data?"*
- **Counter:** *"The data is stored in real database tables (`db.sqlite3`), not hardcoded in the frontend. When you click 'Report Lost' or 'Report Found' right now in the UI, it sends a real `POST /api/items/` request. The backend immediately triggers `run_matching_for_report()`, runs the vector math in under 15ms, creates a `MatchSuggestion` record in the database, and dispatches in-app notifications. Let me demonstrate live by creating a new item right now!"*

### Q2: *"Why didn't you just use ChatGPT or an LLM for everything?"*
- **Counter:** *"Using an LLM to compare thousands of item reports in an $O(N^2)$ loop is cost-prohibitive, slow, and hits rate limits immediately. Our architecture uses a hybrid approach: fast, deterministic mathematical vector filtering (TF-IDF + Haversine) to narrow down candidates in milliseconds, and then uses **Google Gemini 2.5 Flash** only on candidate pairs to synthesize natural-language explanations and challenge questions. This is production-grade engineering."*

### Q3: *"How does this scale to multiple colleges or universities?"*
- **Counter:** *"Our database schema is already multi-tenant! Every location is linked to a `Campus` foreign key. A student at Campus A will only match with found items reported at Campus A. In production, we deploy using our included `docker-compose.yml` with PostgreSQL and Gunicorn."*

### Q4: *"What if students don't know the exact GPS coordinates?"*
- **Counter:** *"They don't have to! Our campus location dropdown maps user-friendly names like 'Central Library' or 'Science Complex' to configured campus landmarks with pre-indexed latitude and longitude."*

### Q5: *"Did you write automated tests?"*
- **Counter:** *"Yes! We have a complete Pytest test suite with **12 out of 12 tests passing 100%**, covering JWT auth, privacy masking serializer filters, the multi-modal matcher, and atomic handover verification."*

---

## 6. Recommended 3-Minute Live Demo Flow

Follow this exact sequence on your screen:

1. **Show Landing Page:** [http://localhost:5173/](http://localhost:5173/)
   - Point out: Clean emerald aesthetic, live stats counters fetched from the database, and search bar.
2. **Quick Demo Login:**
   - Go to [http://localhost:5173/login](http://localhost:5173/login).
   - Click **"Login as Alex"** in the top Quick Demo bar. Show Alex's student dashboard and his lost Bellroy wallet report.
3. **Show AI Matches:**
   - Click **"AI Matches"** in the navigation bar.
   - Show the match card with Maya's found wallet (91% match).
   - Click **"Compare Reports"** to open the side-by-side comparison modal with component score bars.
4. **Show Gemini Claim Challenge:**
   - Click **"Claim Item"**.
   - Point out the **"Google Gemini AI"** badge and dynamic challenge questions prompting the user for hidden identifiers.
5. **Switch to Admin / Staff:**
   - Click **"Login as Admin"** or **"Officer Davis"**.
   - Open **Admin Dashboard** (`/admin-dashboard`).
   - Show the live Recharts category distribution, location hotspots, and the approval button for Alex's claim.
6. **Show Handover OTP Verification:**
   - Approve the claim and demonstrate the 6-digit physical OTP verification code that completes recovery!
