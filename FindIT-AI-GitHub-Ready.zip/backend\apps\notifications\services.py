import logging
from django.core.mail import send_mail
from django.conf import settings
from .models import Notification, NotificationType

logger = logging.getLogger(__name__)

class NotificationService:
    @staticmethod
    def send_notification(user, title, message, notification_type=NotificationType.SYSTEM, action_url='', send_email_alert=True):
        """
        Creates an in-app notification and optionally dispatches an email if user has email alert enabled.
        """
        notification = Notification.objects.create(
            user=user,
            title=title,
            message=message,
            notification_type=notification_type,
            action_url=action_url,
            email_sent=False
        )

        # Check if user profile has email notifications enabled
        email_enabled = getattr(getattr(user, 'profile', None), 'email_notifications', True)

        if send_email_alert and email_enabled and user.email:
            try:
                send_mail(
                    subject=f"[FindIT AI] {title}",
                    message=f"Hello {user.first_name or user.username},\n\n{message}\n\nView details: {action_url}\n\nStay safe,\nFindIT AI Campus Team",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[user.email],
                    fail_silently=False,
                )
                notification.email_sent = True
                notification.save(update_fields=['email_sent'])
                logger.info(f"Dispatched email alert for notification #{notification.id} to {user.email}")
            except Exception as e:
                logger.warning(f"Email dispatch failed for notification #{notification.id}: {str(e)}")
                # We do NOT falsely claim email was sent; notification.email_sent remains False

        return notification
