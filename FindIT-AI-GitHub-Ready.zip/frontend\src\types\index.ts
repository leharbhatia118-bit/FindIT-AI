export type UserRole = 'STUDENT' | 'ADMIN' | 'STAFF';

export interface User {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  role: UserRole;
  college_id?: string;
  department?: string;
  phone_number?: string;
  is_verified: boolean;
  created_at: string;
  profile?: StudentProfile;
}

export interface StudentProfile {
  id: number;
  bio?: string;
  preferred_contact: 'IN_APP' | 'EMAIL' | 'PHONE';
  email_notifications: boolean;
  match_notifications: boolean;
  created_at: string;
  updated_at: string;
}

export interface Campus {
  id: number;
  name: string;
  code: string;
  city: string;
  latitude: number;
  longitude: number;
  locations?: CampusLocation[];
}

export interface CampusLocation {
  id: number;
  name: string;
  building_code?: string;
  zone_or_floor?: string;
  latitude?: number;
  longitude?: number;
  description?: string;
}

export type ReportType = 'LOST' | 'FOUND';

export type ItemCategory =
  | 'ELECTRONICS'
  | 'WALLETS_BAGS'
  | 'KEYS'
  | 'CARDS_IDS'
  | 'BOOKS_STATIONERY'
  | 'CLOTHING'
  | 'JEWELRY_WATCHES'
  | 'OTHER';

export type ReportStatus =
  | 'OPEN'
  | 'POTENTIAL_MATCH'
  | 'CLAIM_PENDING'
  | 'RECOVERED'
  | 'ARCHIVED'
  | 'CLOSED';

export interface ItemImage {
  id: number;
  report: number;
  image: string;
  caption?: string;
  created_at: string;
}

export interface ItemReport {
  id: number;
  report_type: ReportType;
  title: string;
  description: string;
  category: ItemCategory;
  brand?: string;
  primary_color?: string;
  secondary_color?: string;
  incident_date: string;
  incident_time_approx?: string;
  campus: number;
  campus_name?: string;
  location?: number;
  location_name?: string;
  location_detail?: string;
  latitude?: number;
  longitude?: number;
  creator?: number;
  creator_username?: string;
  status: ReportStatus;
  contact_preference?: string;
  private_identifiers?: string;
  claims_count?: number;
  images: ItemImage[];
  created_at: string;
  updated_at?: string;
}

export interface MatchExplanation {
  bullet_points: string[];
  recommendation: 'HIGH_CONFIDENCE_MATCH' | 'RECOMMEND_ADMIN_OR_USER_REVIEW' | 'LOW_PROBABILITY_SUGGESTION';
  text_method: string;
  image_method: string;
  location_method: string;
  date_details: {
    delta_days?: number;
    decay_lambda?: number;
    score?: number;
  };
}

export interface MatchSuggestion {
  id: number;
  lost_report: number;
  found_report: number;
  lost_report_detail?: ItemReport;
  found_report_detail?: ItemReport;
  overall_score: number;
  text_score: number;
  image_score?: number | null;
  location_score: number;
  date_score: number;
  weights_used: Record<string, number>;
  algorithm_used: string;
  explanation: MatchExplanation;
  status: 'PENDING_REVIEW' | 'CONFIRMED_MATCH' | 'DISMISSED';
  created_at: string;
  updated_at: string;
}

export type ClaimStatus =
  | 'PENDING'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'RECOVERED'
  | 'CANCELLED';

export interface Handover {
  id: number;
  handover_code: string;
  code_expires_at: string;
  is_confirmed: boolean;
  confirmed_by_username?: string;
  confirmed_at?: string;
  recovery_receipt_number: string;
  notes?: string;
  is_expired: boolean;
  created_at: string;
}

export interface Claim {
  id: number;
  item_report: number;
  item_report_detail?: ItemReport;
  claimant: number;
  claimant_username: string;
  ownership_description: string;
  private_proof_details: string;
  proof_image?: string;
  status: ClaimStatus;
  reviewed_by?: number;
  reviewer_username?: string;
  review_notes?: string;
  handover?: Handover;
  created_at: string;
  updated_at: string;
}

export interface NotificationItem {
  id: number;
  title: string;
  message: string;
  notification_type: 'MATCH_FOUND' | 'CLAIM_SUBMITTED' | 'CLAIM_STATUS_UPDATE' | 'HANDOVER_READY' | 'ITEM_RECOVERED' | 'SYSTEM';
  is_read: boolean;
  action_url?: string;
  email_sent: boolean;
  created_at: string;
}

export interface AnalyticsOverview {
  total_reports: number;
  lost_reports: number;
  found_reports: number;
  active_reports: number;
  potential_matches: number;
  pending_claims: number;
  confirmed_recoveries: number;
  recovery_rate_percentage: number;
  recovery_rate_definition: string;
  median_recovery_time_hours?: number;
  total_students: number;
}

export interface AnalyticsData {
  overview: AnalyticsOverview;
  category_distribution: {
    category: string;
    label: string;
    count: number;
    percentage: number;
  }[];
  location_hotspots: {
    location: string;
    campus: string;
    count: number;
  }[];
  recent_activity: {
    id: number;
    action: string;
    username: string;
    resource_type: string;
    resource_id?: string;
    timestamp: string;
  }[];
}
