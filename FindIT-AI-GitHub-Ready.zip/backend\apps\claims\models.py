import uuid
from datetime import timedelta
from django.db import models
from django.conf import settings
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from apps.reports.models import ItemReport

class ClaimStatus(models.TextChoices):
    PENDING = 'PENDING', _('Pending Verification')
    UNDER_REVIEW = 'UNDER_REVIEW', _('Under Administrative Review')
    APPROVED = 'APPROVED', _('Approved - Ready for Handover')
    REJECTED = 'REJECTED', _('Rejected')
    RECOVERED = 'RECOVERED', _('Successfully Handed Over & Recovered')
    CANCELLED = 'CANCELLED', _('Cancelled by Claimant')

class Claim(models.Model):
    item_report = models.ForeignKey(ItemReport, on_delete=models.CASCADE, related_name='claims')
    claimant = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='filed_claims')
    
    ownership_description = models.TextField(
        help_text="Detailed statement explaining when/where lost and why this belongs to claimant"
    )
    private_proof_details = models.TextField(
        help_text="Specific answers to private identifying features (wallpaper, engravings, inside pouch contents)"
    )
    proof_image = models.ImageField(upload_to='proofs/%Y/%m/', null=True, blank=True)
    
    status = models.CharField(
        max_length=20,
        choices=ClaimStatus.choices,
        default=ClaimStatus.PENDING,
        db_index=True
    )
    
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='claims_reviewed'
    )
    review_notes = models.TextField(blank=True, default='')
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Claim #{self.id} on Report #{self.item_report_id} by {self.claimant.username} ({self.status})"

class Handover(models.Model):
    claim = models.OneToOneField(Claim, on_delete=models.CASCADE, related_name='handover')
    handover_code = models.CharField(max_length=12, db_index=True, help_text="Expiring OTP token for physical handover")
    code_expires_at = models.DateTimeField()
    
    is_confirmed = models.BooleanField(default=False, db_index=True)
    confirmed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='confirmed_handovers'
    )
    confirmed_at = models.DateTimeField(null=True, blank=True)
    
    recovery_receipt_number = models.CharField(max_length=64, unique=True, db_index=True)
    notes = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    def is_expired(self):
        return timezone.now() > self.code_expires_at

    @classmethod
    def generate_receipt_number(cls):
        return f"REC-{timezone.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"

    def __str__(self):
        return f"Handover for Claim #{self.claim_id} [{self.recovery_receipt_number}]"
