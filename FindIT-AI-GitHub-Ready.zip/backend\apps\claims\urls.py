from django.urls import path
from .views import (
    ClaimListCreateView,
    ClaimDetailView,
    ClaimReviewView,
    HandoverConfirmView,
    GeminiQuestionsView,
)

urlpatterns = [
    path('claims/', ClaimListCreateView.as_view(), name='claim_list_create'),
    path('claims/<int:pk>/', ClaimDetailView.as_view(), name='claim_detail'),
    path('claims/<int:pk>/review/', ClaimReviewView.as_view(), name='claim_review'),
    path('claims/<int:pk>/confirm-handover/', HandoverConfirmView.as_view(), name='handover_confirm'),
    path('items/<int:item_id>/gemini-questions/', GeminiQuestionsView.as_view(), name='gemini_questions'),
]
