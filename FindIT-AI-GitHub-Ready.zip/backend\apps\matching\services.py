import logging
from django.db import transaction
from .models import MatchSuggestion, MatchStatus
from apps.reports.models import ItemReport, ReportStatus
from apps.notifications.services import NotificationService
from apps.notifications.models import NotificationType
from ai_engine.matcher import AIMatchingEngine
from ai_engine.constants import SUGGESTION_THRESHOLD

logger = logging.getLogger(__name__)

def run_matching_for_report(target_report):
    """
    Runs multi-modal AI matching for a newly created or updated ItemReport.
    Finds potential matches, saves MatchSuggestion records, and notifies users.
    """
    if target_report.status in ['RECOVERED', 'ARCHIVED', 'CLOSED']:
        return []

    engine = AIMatchingEngine()
    all_reports = ItemReport.objects.select_related('campus', 'location', 'creator').prefetch_related('images').all()
    candidates = engine.filter_candidates(target_report, all_reports)

    generated_suggestions = []

    for candidate in candidates:
        if target_report.report_type == 'LOST':
            lost_rep = target_report
            found_rep = candidate
        else:
            lost_rep = candidate
            found_rep = target_report

        # Compute multi-modal score
        result = engine.compute_pair_score(lost_rep, found_rep)
        score = result['overall_score']

        if score >= SUGGESTION_THRESHOLD:
            # Use Gemini to generate an advanced AI match synthesis if available
            try:
                from ai_engine.gemini_service import gemini_service
                if gemini_service.is_available():
                    lost_dict = {
                        'title': lost_rep.title,
                        'category': lost_rep.category,
                        'color': f"{lost_rep.primary_color} {lost_rep.secondary_color}".strip(),
                        'brand': lost_rep.brand,
                        'description': lost_rep.description,
                        'location_name': lost_rep.location.name if lost_rep.location else 'Campus',
                        'date': str(lost_rep.incident_date)
                    }
                    found_dict = {
                        'title': found_rep.title,
                        'category': found_rep.category,
                        'color': f"{found_rep.primary_color} {found_rep.secondary_color}".strip(),
                        'brand': found_rep.brand,
                        'description': found_rep.description,
                        'location_name': found_rep.location.name if found_rep.location else 'Campus',
                        'date': str(found_rep.incident_date)
                    }
                    gemini_exp = gemini_service.explain_match(lost_dict, found_dict, score)
                    if gemini_exp:
                        result['explanation'] = gemini_exp
                        result['algorithm_used'] = f"{result['algorithm_used']} + Gemini 2.5 Flash Synthesis"
            except Exception as e:
                logger.warning(f"Gemini explain match skipped: {e}")

            with transaction.atomic():
                suggestion, created = MatchSuggestion.objects.update_or_create(
                    lost_report=lost_rep,
                    found_report=found_rep,
                    defaults={
                        'overall_score': score,
                        'text_score': result['text_score'],
                        'image_score': result['image_score'],
                        'location_score': result['location_score'],
                        'date_score': result['date_score'],
                        'weights_used': result['weights_used'],
                        'algorithm_used': result['algorithm_used'],
                        'explanation': result['explanation'],
                    }
                )
                generated_suggestions.append(suggestion)

                # Update report statuses to POTENTIAL_MATCH if currently OPEN
                if lost_rep.status == ReportStatus.OPEN and score >= 0.55:
                    lost_rep.status = ReportStatus.POTENTIAL_MATCH
                    lost_rep.save(update_fields=['status'])

                if found_rep.status == ReportStatus.OPEN and score >= 0.55:
                    found_rep.status = ReportStatus.POTENTIAL_MATCH
                    found_rep.save(update_fields=['status'])

                # Dispatch notifications to both parties if this is a newly found strong match
                if created and score >= 0.50:
                    NotificationService.send_notification(
                        user=lost_rep.creator,
                        title=f"Potential AI Match Found for '{lost_rep.title}'",
                        message=f"FindIT AI detected a potential found item matching '{lost_rep.title}' with {int(score*100)}% estimated similarity.",
                        notification_type=NotificationType.MATCH_FOUND,
                        action_url=f"/matches/{suggestion.id}"
                    )
                    NotificationService.send_notification(
                        user=found_rep.creator,
                        title=f"Potential Owner Found for '{found_rep.title}'",
                        message=f"A student reported losing an item closely matching '{found_rep.title}' ({int(score*100)}% similarity).",
                        notification_type=NotificationType.MATCH_FOUND,
                        action_url=f"/matches/{suggestion.id}"
                    )

    return generated_suggestions
