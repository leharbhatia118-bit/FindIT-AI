# FindIT AI — Smart Lost & Found Platform for Colleges 🎓🔍

> **A production-ready, AI-powered lost and found web platform engineered for modern campus ecosystems.** Featuring multi-modal item matching, zero-knowledge privacy masking, multi-stage claim verification, and single-click secure OTP handovers.

---

## 🌟 Highlights & Key Innovations

1. **Multi-Modal AI Matching Engine**
   - **Text:** Semantic TF-IDF & N-gram cosine similarity (Sentence Transformers compatible interface).
   - **Image:** 24-bin normalized color histogram cosine similarity & visual embedding pipeline (CLIP compatible).
   - **Location:** Haversine geographical great-circle distance & campus building proximity logic.
   - **Date:** Configurable exponential time decay function: $S_{\text{date}} = e^{-\lambda \cdot |\Delta\text{days}|}$.
   - **Dynamic Weight Renormalization:** Intelligently recalibrates component weights when reports lack photos or GPS coordinates, guaranteeing non-distorted scores.
   - **Explainability:** Generates natural language breakdown and component percentage scores for judges & students.

2. **Zero-Knowledge Privacy Architecture**
   - Sensitive features (e.g., wallet contents, cash amount, laptop serial numbers, internal engravings) are stored in `private_details`.
   - Django serializers automatically strip private identifiers from all public browse/search endpoints.
   - Private attributes are revealed **strictly** to administrators or verified claimants upon approval.

3. **Secure 3-Step Verification & OTP Handover**
   - Claimants must answer ownership challenge questions.
   - Staff/Admin review claims with side-by-side comparison.
   - Recovery generates a cryptographic 6-digit expiring verification code (OTP) and immutable audit log.

4. **Multi-Role Campus Support**
   - **Students:** Report lost items, browse found items, receive real-time match alerts, submit claims.
   - **Campus Staff / Security:** Report custody items, review claims, verify handover OTPs.
   - **Campus Administrators:** Platform analytics, audit logs, category distribution charts, abuse management.

---

## 📐 Architecture Overview

```mermaid
flowchart TD
    subgraph Frontend ["React 18 + TypeScript + Vite + Tailwind CSS"]
        UI[User / Student / Admin UI]
        AuthCtx[Auth Context & Role Switcher]
        ThemeCtx[Dark / Light Mode Context]
        APIClient[Axios API Client with Auto-Refresh JWT]
    end

    subgraph Backend ["Django 6.1 + Django REST Framework"]
        API[RESTful Endpoints + OpenAPI Swagger Docs]
        AuthService[SimpleJWT Authentication]
        MatchingService[Matching Pipeline Service]
        ClaimService[Claim & OTP Handover Service]
        AuditLogService[Audit Logging & Analytics]
    end

    subgraph AIEngine ["Multi-Modal Matcher (ai_engine/)"]
        TextMatch[Text Semantic TF-IDF & N-gram]
        ImageMatch[Visual Color Histogram & CLIP Features]
        GeoMatch[Haversine & Campus Distance]
        DateMatch[Exponential Time Decay]
        Ranker[Dynamic Weight Renormalizer]
    end

    subgraph Database ["Storage Layer"]
        DB[(SQLite Local / PostgreSQL Prod)]
        MediaStorage[Local Media / S3 Compatible Storage]
    end

    UI --> APIClient
    APIClient --> API
    API --> AuthService
    API --> MatchingService
    API --> ClaimService
    API --> AuditLogService
    MatchingService --> AIEngine
    AIEngine --> Ranker
    API --> DB
    API --> MediaStorage
```

---

## 🚀 Quickstart Guide (Local Development)

### Prerequisites
- **Python 3.10+** (Python 3.12 / 3.14 supported)
- **Node.js 18+** & npm

### 1. Clone & Set Up Virtual Environment

```bash
cd findit-ai/backend
python -m venv venv

# Windows
venv\Scripts\activate

# Linux / macOS
source venv/bin/activate

pip install -r requirements.txt
```

### 2. Apply Migrations & Seed Demo Data

```bash
python manage.py migrate
python manage.py seed_demo_data
```

*This automatically populates the database with campus locations, sample lost/found reports, matched pairs, notifications, and demo accounts.*

### 3. Start Backend Server

```bash
python manage.py runserver 8000
```
- API Base: `http://127.0.0.1:8000/api/`
- Interactive Swagger UI: `http://127.0.0.1:8000/api/docs/`
- Django Admin: `http://127.0.0.1:8000/admin/`

### 4. Start Frontend Client

In a separate terminal:

```bash
cd findit-ai/frontend
npm install
npm run dev
```
Open **`http://localhost:5173`** in your browser.

---

## 🐳 Docker Deployment

To launch the full production stack with PostgreSQL, Gunicorn, and Nginx:

```bash
docker-compose up --build -d
```
- Access application at: `http://localhost:5173`
- Backend API at: `http://localhost:8000`

---

## 🔑 Pre-Configured Demo Accounts

The database comes pre-seeded with 4 test personas:

| Role | Username | Password | Persona & Focus |
|---|---|---|---|
| **System Administrator** | `admin` | `AdminPass123!` | Full platform analytics, audit logs, dispute resolution. |
| **Student (Lost Owner)** | `alex_student` | `StudentPass123!` | Lost Bellroy leather wallet at Central Library. |
| **Student (Found Finder)**| `maya_student` | `StudentPass123!` | Found leather wallet near Library study carrels. |
| **Campus Security Staff** | `officer_davis` | `SecurityPass123!` | Campus security desk custody officer. |

> **Pro Tip:** In the frontend, use the **Demo Persona Switcher bar** at the top of the Login page or header for instant 1-click switching between accounts!

---

## 🧪 Running Automated Tests

FindIT AI includes 12 automated unit and integration tests covering authentication, privacy filtering, matching pipeline mechanics, claims, and atomic handover verification.

```bash
cd findit-ai/backend
venv\Scripts\python.exe -m pytest
```

Output:
```
======================= 12 passed in 15.93s =======================
```

---

## 🏆 11-Step Hackathon Demonstration Script for Judges

1. **Landing Page:** Open `http://localhost:5173`. Show the responsive hero section, live database metrics, categories, and AI matching explainer.
2. **Instant Login:** Click **"Login as Alex"** in the demo bar. Alex's student dashboard immediately opens with his active lost reports and 0 open claims.
3. **Report Lost Item:** Navigate to **"Report Lost"**. Enter "Lost AirPods Pro with white case", choose category "Electronics", select "Science Complex", and add private serial number in "Private Details". Submit the report.
4. **Switch to Finder:** Click **"Switch to Maya"** (finder persona). Maya navigates to **"Report Found"**. She reports a found pair of AirPods Pro in Science Complex 2nd floor lounge.
5. **Real-Time AI Matching Trigger:** Submit Maya's report. The AI matching engine executes in under 15ms, computing text semantic similarity, campus location proximity, and exponential date decay.
6. **Notification Delivery:** Alex receives an instant in-app notification: *"Potential AI match found for your lost item with 91% confidence!"*
7. **Side-by-Side Comparison:** Click the notification or navigate to **"AI Matches"**. View the explanation card detailing component scores (Text: 94%, Location: 100%, Date: 98%). Open the side-by-side comparison modal.
8. **Claim Submission:** Alex clicks **"Claim Item"**. He enters his ownership verification answer (e.g., *"Small scratch on right stem and engraved with initials 'AJ'"*).
9. **Staff Review & Approval:** Switch to **"Officer Davis"** or **"Admin"**. Go to Claims review, evaluate Alex's claim against the custodian notes, and click **"Approve Claim"**.
10. **Secure OTP Handover:** Alex receives his 6-digit Handover Verification OTP. Maya or Officer Davis meets Alex at the security desk, enters the 6-digit code, and clicks **"Confirm Handover"**.
11. **Admin Analytics & Audit Trail:** Switch to **"Admin"** and view the **Admin Dashboard**. Show real-time Recharts charts, recovery success metrics, and the immutable audit log entry.

---

## 📂 Project Structure

```
findit-ai/
├── ai_engine/                    # Pure-Python Multi-Modal Matching Engine
│   ├── constants.py              # Weights, decay lambdas, match thresholds
│   ├── text_similarity.py       # TF-IDF + N-Gram semantic tokenizer & cosine matcher
│   ├── image_similarity.py      # Color histogram extractor & CLIP embedding loader
│   ├── geo_similarity.py        # Haversine distance & campus building proximity
│   ├── date_similarity.py       # Exponential time-decay function
│   └── matcher.py               # Candidate filtering & dynamic weight renormalizer
├── backend/                      # Django 6.1 Backend
│   ├── apps/
│   │   ├── accounts/            # User model, profiles, JWT auth, audit logging
│   │   ├── reports/             # Item reports, campus locations, privacy serializer
│   │   ├── matching/            # AI match suggestions & background trigger service
│   │   ├── claims/              # Verification claims & 6-digit OTP handovers
│   │   ├── notifications/       # Real-time in-app & email notification dispatch
│   │   └── analytics/           # Administrative aggregation endpoints
│   ├── core/                    # Django configuration, settings, urls, wsgi
│   ├── tests/                   # 12 Pytest test suites (100% passing)
│   ├── manage.py
│   └── Dockerfile
├── frontend/                     # React 18 + Vite + Tailwind CSS SPA
│   ├── src/
│   │   ├── components/          # Reusable UI components (ItemCard, Modals, Nav, Skeletons)
│   │   ├── contexts/            # AuthContext (with Persona Switcher) & ThemeContext
│   │   ├── pages/               # 13 Complete pages (Landing, Browse, Detail, Claims, Admin...)
│   │   ├── services/            # Axios API client with JWT refresh interceptors
│   │   └── types/               # TypeScript interfaces
│   ├── dist/                    # Production built frontend bundle
│   └── Dockerfile
├── docker-compose.yml            # Multi-container orchestration
├── .env.example                  # Environment configuration template
└── README.md                     # Comprehensive documentation & demo guide
```

---

## 🛡️ License

Built for hackathons and campus open-source initiatives. Licensed under the MIT License.
