from rest_framework import generics, status, permissions, filters
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django.db.models import Q
from .models import Campus, CampusLocation, ItemReport, ItemImage, AbuseReport
from .serializers import (
    CampusSerializer,
    CampusLocationSerializer,
    ItemReportListSerializer,
    ItemReportDetailSerializer,
    ItemReportCreateUpdateSerializer,
    ItemImageSerializer,
    AbuseReportSerializer,
)
from apps.accounts.permissions import IsOwnerOrAdmin, IsAdminRole
from apps.accounts.models import AuditLog
from ai_engine.image_similarity import extract_image_embedding
from apps.matching.services import run_matching_for_report

class CampusListView(generics.ListCreateAPIView):
    queryset = Campus.objects.all().order_by('name')
    serializer_class = CampusSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class CampusLocationListView(generics.ListCreateAPIView):
    serializer_class = CampusLocationSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        qs = CampusLocation.objects.all().order_by('name')
        campus_id = self.request.query_params.get('campus')
        if campus_id:
            qs = qs.filter(campus_id=campus_id)
        return qs

class ItemReportListCreateView(generics.ListCreateAPIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return ItemReportCreateUpdateSerializer
        return ItemReportListSerializer

    def get_queryset(self):
        qs = ItemReport.objects.select_related('campus', 'location', 'creator').prefetch_related('images').all()

        # Filters
        report_type = self.request.query_params.get('report_type')
        if report_type:
            qs = qs.filter(report_type=report_type.upper())

        category = self.request.query_params.get('category')
        if category:
            qs = qs.filter(category=category)

        campus_id = self.request.query_params.get('campus')
        if campus_id:
            qs = qs.filter(campus_id=campus_id)

        location_id = self.request.query_params.get('location')
        if location_id:
            qs = qs.filter(location_id=location_id)

        report_status = self.request.query_params.get('status')
        if report_status:
            qs = qs.filter(status=report_status)

        date_from = self.request.query_params.get('date_from')
        if date_from:
            qs = qs.filter(incident_date__gte=date_from)

        date_to = self.request.query_params.get('date_to')
        if date_to:
            qs = qs.filter(incident_date__lte=date_to)

        # Keyword search across title, description, brand, color
        search = self.request.query_params.get('search')
        if search:
            search = search.strip()
            qs = qs.filter(
                Q(title__icontains=search) |
                Q(description__icontains=search) |
                Q(brand__icontains=search) |
                Q(primary_color__icontains=search) |
                Q(location_detail__icontains=search)
            )

        ordering = self.request.query_params.get('ordering', '-created_at')
        return qs.order_by(ordering)

    def perform_create(self, serializer):
        report = serializer.save(creator=self.request.user)
        
        # Log audit entry
        AuditLog.objects.create(
            user=self.request.user,
            action=f"REPORT_CREATED_{report.report_type}",
            resource_type="ITEM_REPORT",
            resource_id=str(report.id),
            details={"title": report.title, "category": report.category}
        )

        # Automatically run matching pipeline
        run_matching_for_report(report)

class ItemReportDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = ItemReport.objects.select_related('campus', 'location', 'creator').prefetch_related('images').all()
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrAdmin]

    def get_serializer_class(self):
        if self.request.method in ['PUT', 'PATCH']:
            return ItemReportCreateUpdateSerializer
        return ItemReportDetailSerializer

    def perform_update(self, serializer):
        report = serializer.save()
        AuditLog.objects.create(
            user=self.request.user,
            action=f"REPORT_UPDATED_{report.report_type}",
            resource_type="ITEM_REPORT",
            resource_id=str(report.id),
            details={"status": report.status}
        )
        # Rerun matching when report details change
        run_matching_for_report(report)

class MyReportsView(generics.ListAPIView):
    serializer_class = ItemReportListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = ItemReport.objects.filter(creator=self.request.user).select_related('campus', 'location').prefetch_related('images')
        report_type = self.request.query_params.get('report_type')
        if report_type:
            qs = qs.filter(report_type=report_type.upper())
        return qs.order_by('-created_at')

class ItemImageUploadView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request, report_id):
        try:
            report = ItemReport.objects.get(id=report_id)
        except ItemReport.DoesNotExist:
            return Response({"error": "Report not found."}, status=status.HTTP_404_NOT_FOUND)

        if report.creator_id != request.user.id and not request.user.is_admin_or_staff():
            return Response({"error": "Permission denied."}, status=status.HTTP_403_FORBIDDEN)

        file_obj = request.FILES.get('image')
        if not file_obj:
            return Response({"error": "No image file provided."}, status=status.HTTP_400_BAD_REQUEST)

        # File validation
        if file_obj.size > 5 * 1024 * 1024:
            return Response({"error": "Image file too large. Max allowed size is 5MB."}, status=status.HTTP_400_BAD_REQUEST)

        valid_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg']
        if hasattr(file_obj, 'content_type') and file_obj.content_type not in valid_mimes:
            return Response({"error": "Unsupported image format. Please upload JPG, PNG, or WEBP."}, status=status.HTTP_400_BAD_REQUEST)

        item_image = ItemImage.objects.create(
            report=report,
            image=file_obj,
            caption=request.data.get('caption', '')
        )

        # Compute and cache image embedding vector
        try:
            vector, algo = extract_image_embedding(item_image.image.path)
            if vector is not None:
                item_image.feature_embedding = vector
                item_image.save(update_fields=['feature_embedding'])
        except Exception as e:
            pass

        # Trigger re-matching now that an image exists
        run_matching_for_report(report)

        return Response(ItemImageSerializer(item_image).data, status=status.HTTP_201_CREATED)

class AbuseReportCreateView(generics.CreateAPIView):
    serializer_class = AbuseReportSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(reporter=self.request.user)

class AbuseReportAdminListView(generics.ListAPIView):
    queryset = AbuseReport.objects.all().order_by('-created_at')
    serializer_class = AbuseReportSerializer
    permission_classes = [IsAdminRole]

class AbuseReportAdminUpdateView(generics.UpdateAPIView):
    queryset = AbuseReport.objects.all()
    serializer_class = AbuseReportSerializer
    permission_classes = [IsAdminRole]
