import datetime
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
from apps.accounts.models import StudentProfile, AuditLog
from apps.reports.models import Campus, CampusLocation, ItemReport, ReportType, ItemCategory, ReportStatus
from apps.claims.models import Claim, Handover, ClaimStatus
from apps.matching.services import run_matching_for_report
from apps.notifications.services import NotificationService
from apps.notifications.models import NotificationType

User = get_user_model()

class Command(BaseCommand):
    help = "Seeds database with realistic demo accounts, campus locations, item reports, AI matches, and claims."

    def handle(self, *args, **options):
        self.stdout.write("Seeding FindIT AI demo dataset...")

        # 1. Demo Users
        admin_user, _ = User.objects.get_or_create(
            username="admin",
            defaults={
                "email": "admin@findit.edu",
                "first_name": "Dr. Sarah",
                "last_name": "Mitchell",
                "role": "ADMIN",
                "college_id": "FAC-8810",
                "department": "Campus Administration & Security",
                "is_staff": True,
                "is_superuser": True,
                "is_verified": True,
            }
        )
        admin_user.set_password("AdminPass123!")
        admin_user.save()
        StudentProfile.objects.get_or_create(user=admin_user, defaults={"bio": "Chief Campus Officer"})

        student1, _ = User.objects.get_or_create(
            username="alex_student",
            defaults={
                "email": "alex@findit.edu",
                "first_name": "Alex",
                "last_name": "Rivera",
                "role": "STUDENT",
                "college_id": "CS2026-042",
                "department": "Computer Science",
                "phone_number": "+1-555-0192",
                "is_verified": True,
            }
        )
        student1.set_password("StudentPass123!")
        student1.save()
        StudentProfile.objects.get_or_create(user=student1, defaults={"bio": "Junior CS Major | Hackathon Enthusiast"})

        student2, _ = User.objects.get_or_create(
            username="maya_student",
            defaults={
                "email": "maya@findit.edu",
                "first_name": "Maya",
                "last_name": "Chen",
                "role": "STUDENT",
                "college_id": "EE2026-118",
                "department": "Electrical Engineering",
                "phone_number": "+1-555-0143",
                "is_verified": True,
            }
        )
        student2.set_password("StudentPass123!")
        student2.save()
        StudentProfile.objects.get_or_create(user=student2, defaults={"bio": "Sophomore Robotics Lead"})

        security_user, _ = User.objects.get_or_create(
            username="officer_davis",
            defaults={
                "email": "security@findit.edu",
                "first_name": "Marcus",
                "last_name": "Davis",
                "role": "STAFF",
                "college_id": "SEC-204",
                "department": "Campus Safety & Lost Desk",
                "phone_number": "+1-555-0100",
                "is_staff": True,
                "is_verified": True,
            }
        )
        security_user.set_password("SecurityPass123!")
        security_user.save()

        # 2. Campus & Campus Locations
        campus, _ = Campus.objects.get_or_create(
            code="MUC",
            defaults={
                "name": "Metropolis University Main Campus",
                "city": "Metropolis",
                "latitude": 37.7749,
                "longitude": -122.4194
            }
        )

        locations_meta = [
            ("Central Library - 2nd Floor Reading Room", "LIB-201", "2nd Floor", 37.7752, -122.4191, "Main quiet study desks and book stacks"),
            ("Engineering Block B - Robotics Lab 104", "ENG-B", "Ground Floor", 37.7745, -122.4188, "Electronics workbenches and hardware stations"),
            ("Student Center Cafeteria - North Wing", "SC-CAFE", "1st Floor", 37.7742, -122.4202, "Food court dining tables and lounge booths"),
            ("Sports Complex - Indoor Basketball Court", "GYM-A", "Ground Floor", 37.7758, -122.4210, "Locker rooms and spectator bleachers"),
            ("Science Quad - Outdoor Benches", "QUAD-1", "Outdoor", 37.7747, -122.4195, "Central green lawn seating"),
            ("Administration Hall - Main Information Desk", "ADM-01", "Ground Floor", 37.7738, -122.4190, "Security reception and lost-and-found hub"),
        ]

        loc_objs = {}
        for name, b_code, zone, lat, lng, desc in locations_meta:
            loc, _ = CampusLocation.objects.get_or_create(
                campus=campus,
                name=name,
                defaults={
                    "building_code": b_code,
                    "zone_or_floor": zone,
                    "latitude": lat,
                    "longitude": lng,
                    "description": desc
                }
            )
            loc_objs[name] = loc

        today = timezone.now().date()

        # 3. Pair 1: Black Wallet (Alex lost, Maya found)
        lost_wallet, _ = ItemReport.objects.get_or_create(
            title="Black Leather Bi-Fold Wallet with Red Stitching",
            creator=student1,
            defaults={
                "report_type": ReportType.LOST,
                "description": "Lost my genuine leather black wallet while studying for finals. Has distinctive red perimeter stitching and a small silver zipper on the coin compartment.",
                "category": ItemCategory.WALLETS_BAGS,
                "brand": "Bellroy",
                "primary_color": "Black",
                "secondary_color": "Red",
                "incident_date": today - datetime.timedelta(days=2),
                "incident_time_approx": "Around 3:30 PM",
                "campus": campus,
                "location": loc_objs["Central Library - 2nd Floor Reading Room"],
                "location_detail": "Left on desk #14 near the south windows",
                "latitude": 37.77522,
                "longitude": -122.41912,
                "private_identifiers": "Contains driver license ending in 9821, student gym keycard, and an emergency $20 bill folded in hidden slot.",
                "status": ReportStatus.OPEN
            }
        )

        found_wallet, _ = ItemReport.objects.get_or_create(
            title="Black Leather Wallet with Red Accent Seams",
            creator=student2,
            defaults={
                "report_type": ReportType.FOUND,
                "description": "Found a black leather bi-fold wallet left behind on a study desk on the second floor of the library. Turned into the 2nd floor desk monitor.",
                "category": ItemCategory.WALLETS_BAGS,
                "brand": "Bellroy",
                "primary_color": "Black",
                "secondary_color": "Red",
                "incident_date": today - datetime.timedelta(days=2),
                "incident_time_approx": "Found around 4:15 PM",
                "campus": campus,
                "location": loc_objs["Central Library - 2nd Floor Reading Room"],
                "location_detail": "Study table section near window row",
                "latitude": 37.77524,
                "longitude": -122.41910,
                "private_identifiers": "Contains student card and folded bill in interior pocket (matching claimant verification required).",
                "status": ReportStatus.OPEN
            }
        )

        # 4. Pair 2: AirPods Pro 2 in Matte Olive Case
        lost_airpods, _ = ItemReport.objects.get_or_create(
            title="Apple AirPods Pro 2 in Olive Green Protective Case",
            creator=student2,
            defaults={
                "report_type": ReportType.LOST,
                "description": "Lost wireless earphones in a distinctive matte olive silicone case with a small brass carabiner clip.",
                "category": ItemCategory.ELECTRONICS,
                "brand": "Apple",
                "primary_color": "Olive Green",
                "secondary_color": "White",
                "incident_date": today - datetime.timedelta(days=1),
                "incident_time_approx": "11:00 AM",
                "campus": campus,
                "location": loc_objs["Engineering Block B - Robotics Lab 104"],
                "location_detail": "Workstation bench #3",
                "latitude": 37.77451,
                "longitude": -122.41882,
                "private_identifiers": "Case has a small laser engraving: 'MC-2026' on the reverse lid.",
                "status": ReportStatus.OPEN
            }
        )

        found_airpods, _ = ItemReport.objects.get_or_create(
            title="AirPods Wireless Earphones in Green Silicone Cover",
            creator=security_user,
            defaults={
                "report_type": ReportType.FOUND,
                "description": "White wireless earbuds inside a protective olive silicone case found near robotics lab bench.",
                "category": ItemCategory.ELECTRONICS,
                "brand": "Apple",
                "primary_color": "Green",
                "incident_date": today - datetime.timedelta(days=1),
                "incident_time_approx": "Found by cleaning staff at 1:30 PM",
                "campus": campus,
                "location": loc_objs["Engineering Block B - Robotics Lab 104"],
                "location_detail": "Turned in to Engineering department office",
                "latitude": 37.77450,
                "longitude": -122.41885,
                "private_identifiers": "Custom initials engraved under silicone cover.",
                "status": ReportStatus.OPEN
            }
        )

        # 5. Additional Diverse Campus Reports for Search, Filter, and Analytics
        ItemReport.objects.get_or_create(
            title="Blue Hydro Flask 32oz Water Bottle with National Park Stickers",
            creator=student1,
            defaults={
                "report_type": ReportType.LOST,
                "description": "Cobalt blue insulated stainless steel bottle with Yosemite and Zion stickers and a dented bottom rim.",
                "category": ItemCategory.OTHER,
                "brand": "Hydro Flask",
                "primary_color": "Blue",
                "incident_date": today - datetime.timedelta(days=3),
                "campus": campus,
                "location": loc_objs["Student Center Cafeteria - North Wing"],
                "location_detail": "Booth near smoothie counter",
                "latitude": 37.7742,
                "longitude": -122.4202,
                "status": ReportStatus.OPEN
            }
        )

        ItemReport.objects.get_or_create(
            title="Set of 3 Keys on Silver Carabiner with NASA Lanyard",
            creator=student2,
            defaults={
                "report_type": ReportType.FOUND,
                "description": "Dorm room key, brass padlock key, and bike lock key on a dark blue NASA lanyard.",
                "category": ItemCategory.KEYS,
                "primary_color": "Silver",
                "secondary_color": "Blue",
                "incident_date": today - datetime.timedelta(days=4),
                "campus": campus,
                "location": loc_objs["Sports Complex - Indoor Basketball Court"],
                "location_detail": "Bleacher row 3",
                "latitude": 37.7758,
                "longitude": -122.4210,
                "private_identifiers": "Bike key has number stamped: 'K-442'.",
                "status": ReportStatus.OPEN
            }
        )

        ItemReport.objects.get_or_create(
            title="TI-84 Plus CE Graphing Calculator in Rose Gold",
            creator=student1,
            defaults={
                "report_type": ReportType.LOST,
                "description": "Texas Instruments color display graphing calculator. Essential for calculus midterm.",
                "category": ItemCategory.ELECTRONICS,
                "brand": "Texas Instruments",
                "primary_color": "Rose Gold",
                "incident_date": today - datetime.timedelta(days=5),
                "campus": campus,
                "location": loc_objs["Central Library - 2nd Floor Reading Room"],
                "latitude": 37.7752,
                "longitude": -122.4191,
                "private_identifiers": "Battery cover has silver marker writing 'Calculus IV'.",
                "status": ReportStatus.OPEN
            }
        )

        ItemReport.objects.get_or_create(
            title="Student ID Card - Engineering Department",
            creator=security_user,
            defaults={
                "report_type": ReportType.FOUND,
                "description": "Official campus smartcard badge turned in to security desk.",
                "category": ItemCategory.CARDS_IDS,
                "primary_color": "White",
                "incident_date": today - datetime.timedelta(days=2),
                "campus": campus,
                "location": loc_objs["Administration Hall - Main Information Desk"],
                "private_identifiers": "Student name and roll number recorded in security logbook.",
                "status": ReportStatus.OPEN
            }
        )

        # 6. Run AI Matching Engine for reports
        self.stdout.write("Running AI Matching Pipeline on seeded reports...")
        sugg_wallet = run_matching_for_report(lost_wallet)
        sugg_airpods = run_matching_for_report(lost_airpods)

        # 7. Seed Sample Handover & Completed Recovery for Demonstration Analytics
        # Create a historical recovered report
        hist_lost, _ = ItemReport.objects.get_or_create(
            title="Grey North Face Backpack with Laptop Sleeve",
            creator=student1,
            defaults={
                "report_type": ReportType.LOST,
                "description": "Charcoal grey daypack with padded straps.",
                "category": ItemCategory.WALLETS_BAGS,
                "brand": "The North Face",
                "primary_color": "Grey",
                "incident_date": today - datetime.timedelta(days=8),
                "campus": campus,
                "location": loc_objs["Student Center Cafeteria - North Wing"],
                "status": ReportStatus.RECOVERED
            }
        )

        hist_found, _ = ItemReport.objects.get_or_create(
            title="Charcoal The North Face Backpack",
            creator=student2,
            defaults={
                "report_type": ReportType.FOUND,
                "description": "Turned in to student center desk.",
                "category": ItemCategory.WALLETS_BAGS,
                "brand": "The North Face",
                "primary_color": "Grey",
                "incident_date": today - datetime.timedelta(days=8),
                "campus": campus,
                "location": loc_objs["Student Center Cafeteria - North Wing"],
                "status": ReportStatus.RECOVERED
            }
        )

        hist_claim, _ = Claim.objects.get_or_create(
            item_report=hist_found,
            claimant=student1,
            defaults={
                "ownership_description": "My backpack containing notebook and mouse pad.",
                "private_proof_details": "Front pouch has mechanical pencils and a black flash drive.",
                "status": ClaimStatus.RECOVERED,
                "reviewed_by": admin_user,
                "review_notes": "Claimant verified student ID and correctly identified inside pouch contents."
            }
        )

        Handover.objects.get_or_create(
            claim=hist_claim,
            defaults={
                "handover_code": "481902",
                "code_expires_at": timezone.now() + datetime.timedelta(days=1),
                "is_confirmed": True,
                "confirmed_by": admin_user,
                "confirmed_at": timezone.now() - datetime.timedelta(days=6),
                "recovery_receipt_number": "REC-20261004-98A1BC",
                "notes": "Handed over at Central Administration Desk upon ID check."
            }
        )

        # Audit logs for demo
        AuditLog.objects.create(
            user=admin_user,
            action="SYSTEM_DEMO_DATA_INITIALIZED",
            resource_type="SYSTEM",
            resource_id="1",
            details={"campuses": 1, "locations": len(locations_meta), "items_seeded": 8}
        )

        self.stdout.write(self.style.SUCCESS("FindIT AI demo dataset seeded successfully!"))
        self.stdout.write("  Admin user:     admin / AdminPass123!")
        self.stdout.write("  Student 1 user: alex_student / StudentPass123!")
        self.stdout.write("  Student 2 user: maya_student / StudentPass123!")
        self.stdout.write("  Security staff: officer_davis / SecurityPass123!")
