import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, Check, X, ShieldCheck, MapPin, Calendar, Filter } from 'lucide-react';
import { matchingApi } from '../services/api';
import { MatchSuggestion } from '../types';
import { ComparisonModal } from '../components/matches/ComparisonModal';
import { ClaimModal } from '../components/claims/ClaimModal';
import { EmptyState } from '../components/common/EmptyState';
import { CardSkeleton } from '../components/common/LoadingSkeleton';

export const MatchesPage: React.FC = () => {
  const [suggestions, setSuggestions] = useState<MatchSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');

  // Modals
  const [selectedSuggestion, setSelectedSuggestion] = useState<MatchSuggestion | null>(null);
  const [claimingReportId, setClaimingReportId] = useState<number | null>(null);

  const fetchMatches = () => {
    setLoading(true);
    const params = statusFilter ? { status: statusFilter } : {};
    matchingApi
      .getSuggestions(params)
      .then((data) => {
        setSuggestions(data.results || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchMatches();
  }, [statusFilter]);

  const handleConfirm = async (id: number) => {
    await matchingApi.updateSuggestionStatus(id, 'CONFIRMED_MATCH');
    fetchMatches();
  };

  const handleDismiss = async (id: number) => {
    await matchingApi.updateSuggestionStatus(id, 'DISMISSED');
    fetchMatches();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              AI Match Discovery Engine
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
              Active Pipeline
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ranked multi-modal correlation between student lost reports and turned-in found belongings
          </p>
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200"
          >
            <option value="">All Match Statuses</option>
            <option value="PENDING_REVIEW">Pending Review</option>
            <option value="CONFIRMED_MATCH">Confirmed Matches</option>
            <option value="DISMISSED">Dismissed</option>
          </select>
        </div>
      </div>

      {/* Grid of Match Cards */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : suggestions.length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title="No Match Suggestions"
          description="When students report lost items matching turned-in found items above the 45% threshold, they will automatically appear here."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {suggestions.map((m) => {
            const lost = m.lost_report_detail;
            const found = m.found_report_detail;
            const scorePercent = Math.round(m.overall_score * 100);

            return (
              <div
                key={m.id}
                className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 p-6 shadow-subtle hover:shadow-card transition-all space-y-5 flex flex-col justify-between"
              >
                {/* Header score & status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-forest-800 flex items-center justify-center text-white font-extrabold text-sm shadow-md">
                      {scorePercent}%
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-800 dark:text-white block">
                        Estimated Similarity
                      </span>
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                        {m.algorithm_used.replace('_', ' ')}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      m.status === 'CONFIRMED_MATCH'
                        ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                        : m.status === 'DISMISSED'
                        ? 'bg-slate-100 text-slate-500'
                        : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                    }`}
                  >
                    {m.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Items Comparison Snippet */}
                <div className="grid grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="space-y-1">
                    <span className="text-[10px] font-extrabold text-rose-500 uppercase tracking-wider block">
                      Lost Item
                    </span>
                    <h4 className="font-bold text-slate-900 dark:text-white line-clamp-1">
                      {lost?.title || `Report #${m.lost_report}`}
                    </h4>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {lost?.location_name || 'Campus'}
                    </span>
                  </div>

                  <div className="space-y-1 border-l border-slate-200 dark:border-slate-800 pl-3">
                    <span className="text-[10px] font-extrabold text-emerald-600 uppercase tracking-wider block">
                      Found Item
                    </span>
                    <h4 className="font-bold text-slate-900 dark:text-white line-clamp-1">
                      {found?.title || `Report #${m.found_report}`}
                    </h4>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {found?.location_name || 'Campus'}
                    </span>
                  </div>
                </div>

                {/* Component Progress Mini-bars */}
                <div className="grid grid-cols-4 gap-2 text-[10px] font-medium text-slate-500 dark:text-slate-400">
                  <div>
                    <span className="block truncate">Text: {Math.round(m.text_score * 100)}%</span>
                    <div className="w-full h-1 bg-slate-100 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: `${m.text_score * 100}%` }}></div>
                    </div>
                  </div>
                  <div>
                    <span className="block truncate">Loc: {Math.round(m.location_score * 100)}%</span>
                    <div className="w-full h-1 bg-slate-100 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-blue-500" style={{ width: `${m.location_score * 100}%` }}></div>
                    </div>
                  </div>
                  <div>
                    <span className="block truncate">Date: {Math.round(m.date_score * 100)}%</span>
                    <div className="w-full h-1 bg-slate-100 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-amber-500" style={{ width: `${m.date_score * 100}%` }}></div>
                    </div>
                  </div>
                  <div>
                    <span className="block truncate">Img: {m.image_score != null ? `${Math.round(m.image_score * 100)}%` : 'Auto'}</span>
                    <div className="w-full h-1 bg-slate-100 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-purple-500" style={{ width: `${(m.image_score ?? 0.5) * 100}%` }}></div>
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="pt-2 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setSelectedSuggestion(m)}
                    className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    <span>Full Breakdown & Compare</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center gap-1.5">
                    {m.status !== 'DISMISSED' && (
                      <button
                        onClick={() => handleDismiss(m.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                        title="Dismiss suggestion"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                    {m.status !== 'CONFIRMED_MATCH' && (
                      <button
                        onClick={() => handleConfirm(m.id)}
                        className="px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100"
                      >
                        Confirm Match
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Comparison Modal */}
      {selectedSuggestion && (
        <ComparisonModal
          suggestion={selectedSuggestion}
          onClose={() => setSelectedSuggestion(null)}
          onConfirmMatch={(id) => {
            handleConfirm(id);
            setSelectedSuggestion(null);
          }}
          onDismiss={(id) => {
            handleDismiss(id);
            setSelectedSuggestion(null);
          }}
          onInitiateClaim={(foundId) => {
            setSelectedSuggestion(null);
            setClaimingReportId(foundId);
          }}
        />
      )}

      {/* Claim Modal if triggered */}
      {claimingReportId && (
        <ClaimModal
          item={suggestions.find((s) => s.found_report === claimingReportId)?.found_report_detail || null}
          onClose={() => setClaimingReportId(null)}
          onSuccess={() => {
            setClaimingReportId(null);
            fetchMatches();
          }}
        />
      )}

    </div>
  );
};
