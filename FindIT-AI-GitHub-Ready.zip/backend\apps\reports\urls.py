from django.urls import path
from .views import (
    CampusListView,
    CampusLocationListView,
    ItemReportListCreateView,
    ItemReportDetailView,
    MyReportsView,
    ItemImageUploadView,
    AbuseReportCreateView,
    AbuseReportAdminListView,
    AbuseReportAdminUpdateView,
)

urlpatterns = [
    path('campuses/', CampusListView.as_view(), name='campus_list'),
    path('locations/', CampusLocationListView.as_view(), name='location_list'),
    path('items/', ItemReportListCreateView.as_view(), name='item_list_create'),
    path('items/<int:pk>/', ItemReportDetailView.as_view(), name='item_detail'),
    path('items/<int:report_id>/images/', ItemImageUploadView.as_view(), name='item_image_upload'),
    path('my-reports/', MyReportsView.as_view(), name='my_reports'),
    path('abuse-reports/', AbuseReportCreateView.as_view(), name='abuse_report_create'),
    path('admin/abuse-reports/', AbuseReportAdminListView.as_view(), name='admin_abuse_reports'),
    path('admin/abuse-reports/<int:pk>/', AbuseReportAdminUpdateView.as_view(), name='admin_abuse_report_update'),
]
