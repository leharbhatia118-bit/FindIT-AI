"""
Temporal Proximity Engine.
Computes time-decay score between lost incident date and found incident date.
"""

import math
from datetime import date
from .constants import DEFAULT_DATE_LAMBDA

def compute_date_similarity(lost_date: date, found_date: date, decay_lambda: float = DEFAULT_DATE_LAMBDA):
    """
    Computes temporal similarity score between 0.0 and 1.0.
    Returns:
        (score: float, details: dict)
    """
    if not lost_date or not found_date:
        return 0.50, {"reason": "Missing date information"}

    delta = (found_date - lost_date).days

    # Ideally: found_date >= lost_date
    if delta < 0:
        # Found item dated earlier than lost report date:
        # allow small reporting ambiguity up to 2 days, then penalize
        abs_delta = abs(delta)
        score = math.exp(-decay_lambda * (abs_delta * 1.5))
    else:
        # Normal sequence: found on or after item was lost
        score = math.exp(-decay_lambda * delta)

    score = max(0.05, min(1.0, score))
    return round(score, 4), {
        "delta_days": delta,
        "decay_lambda": decay_lambda,
        "score": round(score, 4)
    }
