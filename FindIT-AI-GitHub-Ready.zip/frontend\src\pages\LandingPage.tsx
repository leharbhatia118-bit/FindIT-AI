import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search,
  Sparkles,
  ShieldCheck,
  MapPin,
  Clock,
  ArrowRight,
  CheckCircle2,
  FileText,
  KeyRound,
  Users,
  Compass,
  Laptop,
  HelpCircle,
  ChevronDown,
} from 'lucide-react';
import { reportsApi, analyticsApi } from '../services/api';
import { ItemReport, AnalyticsData } from '../types';
import { ItemCard } from '../components/common/ItemCard';
import { CardSkeleton } from '../components/common/LoadingSkeleton';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [recentItems, setRecentItems] = useState<ItemReport[]>([]);
  const [stats, setStats] = useState<AnalyticsData | null>(null);
  const [loadingItems, setLoadingItems] = useState(true);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  useEffect(() => {
    // Fetch recent items
    reportsApi
      .getItems({ ordering: '-created_at' })
      .then((data) => {
        setRecentItems((data.results || []).slice(0, 4));
      })
      .catch(() => {})
      .finally(() => setLoadingItems(false));

    // Fetch live statistics
    analyticsApi
      .getPublicStats()
      .then((data) => setStats(data))
      .catch(() => {});
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/browse?search=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate('/browse');
    }
  };

  const faqs = [
    {
      q: 'How does the FindIT AI matching engine work?',
      a: 'When you submit a report, our multi-modal AI engine automatically evaluates semantic description similarity, visual color & feature vectors, campus GPS/building distance, and incident date proximity to calculate a calibrated similarity score.',
    },
    {
      q: 'Are my private identifying features visible to everyone?',
      a: 'No. Confidential identifiers (e.g. engravings, wallpaper descriptions, private receipts) are strictly masked and encrypted. They are only visible to you and verified campus security administrators reviewing ownership claims.',
    },
    {
      q: 'What is the physical handover OTP code?',
      a: 'When an administrator reviews and approves your ownership claim, FindIT AI issues a secure, time-limited 6-digit cryptographic handover token. You present this code at the campus safety desk alongside your College ID card to reclaim your item.',
    },
    {
      q: 'Can FindIT AI be used across multiple campus buildings?',
      a: 'Yes. FindIT AI is architected with a hierarchical Campus and CampusLocation model, supporting GPS Haversine distance, specific building wings, floors, and outdoor zones.',
    },
  ];

  return (
    <div className="space-y-20 pb-20">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-gradient-to-b from-forest-50/70 via-white to-transparent dark:from-slate-900 dark:via-slate-900 dark:to-slate-950">
        <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-15 pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          
          {/* Top Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100/80 dark:bg-emerald-950/70 border border-emerald-300 dark:border-emerald-800 text-xs font-bold text-forest-900 dark:text-emerald-300 mb-8 shadow-sm">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>FindIT AI 2.0 • Smart Collegiate Recovery Platform</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-forest-950 dark:text-white max-w-4xl mx-auto leading-tight sm:leading-none">
            Lost Something?{' '}
            <span className="text-emerald-600 dark:text-emerald-400 underline decoration-emerald-300 dark:decoration-emerald-700 decoration-wavy">
              Let AI Find It.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Stop searching chaotic WhatsApp groups and paper bulletin boards. Report lost items or turn in found valuables with smart multi-modal AI matching and verified campus desk pickup.
          </p>

          {/* Search Bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="mt-10 max-w-2xl mx-auto relative flex items-center shadow-lg rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-1.5 focus-within:ring-2 focus-within:ring-emerald-500 transition-all"
          >
            <Search className="w-5 h-5 text-slate-400 ml-3.5 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by item title, brand, color, or location (e.g. 'black leather wallet', 'AirPods')..."
              className="w-full px-3.5 py-3 text-xs sm:text-sm bg-transparent text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              className="px-5 py-3 rounded-xl bg-forest-800 hover:bg-forest-900 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold transition-colors shrink-0 shadow-sm"
            >
              Search
            </button>
          </form>

          {/* Hero Call to Action Buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/report-lost"
              className="px-6 py-3.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-sm shadow-md shadow-rose-500/20 transition-all flex items-center gap-2 hover:-translate-y-0.5"
            >
              <span>Report Lost Item</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              to="/report-found"
              className="px-6 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 hover:-translate-y-0.5"
            >
              <span>Report Found Item</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Quick Stats Strip */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
              <div className="text-2xl sm:text-3xl font-extrabold text-forest-900 dark:text-emerald-400">
                {stats?.overview.total_reports || '12+'}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                Total Campus Reports
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                {stats?.overview.potential_matches || '6+'}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                AI Match Suggestions
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-600 dark:text-blue-400">
                {stats?.overview.confirmed_recoveries || '3+'}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                Verified Recoveries
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
              <div className="text-2xl sm:text-3xl font-extrabold text-forest-700 dark:text-emerald-300">
                {stats?.overview.recovery_rate_percentage || 25.0}%
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                Platform Recovery Rate
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">
            Streamlined Process
          </h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-2">
            How FindIT AI Recovers Belongings
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-forest-100 dark:bg-emerald-950/60 text-forest-800 dark:text-emerald-300 font-extrabold flex items-center justify-center text-sm">
              01
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">1. File Report</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Submit description, category, campus building, and confidential identifying features.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-forest-100 dark:bg-emerald-950/60 text-forest-800 dark:text-emerald-300 font-extrabold flex items-center justify-center text-sm">
              02
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">2. AI Matches</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Multi-modal engine compares semantics, visual features, campus distance, and date decay.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-forest-100 dark:bg-emerald-950/60 text-forest-800 dark:text-emerald-300 font-extrabold flex items-center justify-center text-sm">
              03
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">3. Claim Verification</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Submit ownership answers to private identifying questions. Campus security reviews evidence.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold flex items-center justify-center text-sm">
              04
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">4. Secure Handover</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Receive a 6-digit expiring handover OTP code. Reclaim your item and receive an official receipt.
            </p>
          </div>
        </div>
      </section>

      {/* Recently Reported Items */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              Recently Reported Items
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Live updates across all campus buildings and zones
            </p>
          </div>
          <Link
            to="/browse"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
          >
            <span>Browse all items</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loadingItems ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <CardSkeleton />
            <CardSkeleton />
            <CardSkeleton />
            <CardSkeleton />
          </div>
        ) : recentItems.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-xs">
            No active reports yet. Be the first to file one!
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentItems.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </section>

      {/* AI Matching Architecture Spotlight */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-forest-950 text-white p-8 sm:p-12 border border-forest-900 shadow-2xl overflow-hidden relative">
          <div className="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/60 text-emerald-300 text-xs font-bold border border-emerald-700/60">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Proprietary Multi-Modal Pipeline</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                Not Random Percentages. Real Mathematical Similarity.
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                FindIT AI computes transparent component similarity scores across semantic text, visual features, campus geographical proximity, and time-decay:
              </p>
              
              <div className="p-4 rounded-2xl bg-forest-900/60 border border-forest-800 text-xs font-mono text-emerald-300 space-y-1">
                <div>Score = 0.40·S(text) + 0.30·S(image) + 0.20·S(location) + 0.10·S(date)</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  * Dynamically renormalizes weights when photos or GPS coordinates are omitted.
                </div>
              </div>

              <div className="pt-2">
                <Link
                  to="/matches"
                  className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold inline-flex items-center gap-2 transition-colors"
                >
                  <span>Explore AI Matches Page</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-forest-900/40 border border-forest-800/80 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Semantic & Lexical Text Embeddings</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    SentenceTransformers with pure-Python TF-IDF & Cosine N-Gram fallback for keywords and descriptions.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-forest-900/40 border border-forest-800/80 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Visual Appearance & Color Histograms</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    CLIP visual embeddings with perceptual RGB color distributions cached directly on report models.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-forest-900/40 border border-forest-800/80 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white">Campus Haversine & Building Graph</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Calculates geographical meter distances and campus landmark building proximity without fake GPS coordinates.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Common questions regarding reporting, claiming, and verification
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 overflow-hidden"
            >
              <button
                onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                className="w-full py-4 px-5 text-left text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center justify-between"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform ${
                    activeFaq === i ? 'rotate-180 text-emerald-600' : ''
                  }`}
                />
              </button>
              {activeFaq === i && (
                <div className="px-5 pb-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-700/50 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
