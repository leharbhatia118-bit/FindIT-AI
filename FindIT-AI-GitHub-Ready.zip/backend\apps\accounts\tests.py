from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

User = get_user_model()

class AuthAndAccountsTests(TestCase):
    def setUp(self):
        self.client = APIClient()

    def test_student_registration(self):
        payload = {
            "username": "new_student",
            "email": "student@college.edu",
            "password": "SecurePassword123!",
            "password2": "SecurePassword123!",
            "first_name": "Jordan",
            "last_name": "Smith",
            "role": "STUDENT",
            "college_id": "CS-9901",
            "department": "Informatics"
        }
        response = self.client.post('/api/auth/register/', payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)
        self.assertEqual(response.data['user']['username'], 'new_student')
        self.assertTrue(response.data['user']['is_verified'])

    def test_login_and_jwt_tokens(self):
        user = User.objects.create_user(
            username="testuser",
            email="test@univ.edu",
            password="TestPassword123!",
            role="STUDENT"
        )
        response = self.client.post('/api/auth/login/', {
            "username": "testuser",
            "password": "TestPassword123!"
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)

    def test_me_endpoint_requires_auth(self):
        response = self.client.get('/api/auth/me/')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
