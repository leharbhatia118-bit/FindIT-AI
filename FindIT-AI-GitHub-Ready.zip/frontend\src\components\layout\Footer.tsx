import React from 'react';
import { Sparkles, Shield, Heart, MapPin, Mail, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-forest-950 text-slate-300 pt-16 pb-12 border-t border-forest-900/60 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-forest-900">
          
          {/* Brand Col */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-white">
                <Sparkles className="w-4 h-4 text-emerald-100" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                FindIT<span className="text-emerald-400"> AI</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Intelligent multi-modal Lost & Found platform for university campuses. Replacing scattered chat messages with verifiable recoveries.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium">
              <Shield className="w-4 h-4" />
              <span>Campus Security Integrated</span>
            </div>
          </div>

          {/* Quick Nav */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Explore
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <Link to="/browse" className="hover:text-emerald-400 transition-colors">
                  Browse Active Reports
                </Link>
              </li>
              <li>
                <Link to="/matches" className="hover:text-emerald-400 transition-colors">
                  AI Match Engine
                </Link>
              </li>
              <li>
                <Link to="/report-lost" className="hover:text-emerald-400 transition-colors">
                  Report a Lost Item
                </Link>
              </li>
              <li>
                <Link to="/report-found" className="hover:text-emerald-400 transition-colors">
                  Turn In a Found Item
                </Link>
              </li>
            </ul>
          </div>

          {/* Verification & Security */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Verification & Safety
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>Two-Factor Ownership Verification</li>
              <li>Cryptographic 6-Digit Handover OTP</li>
              <li>Masked Private Identifiers</li>
              <li>Official Audit Logging</li>
              <li>Campus Police / Admin Dashboard</li>
            </ul>
          </div>

          {/* Hackathon Info */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Hackathon Demonstration
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Built for collegiate hackathon exhibition. Production-ready Django REST backend + React/TypeScript client.
            </p>
            <div className="p-3 rounded-lg bg-forest-900/60 border border-forest-800 text-[11px] text-emerald-300">
              Demo Credentials:
              <br />Admin: <code className="text-white">admin / AdminPass123!</code>
              <br />Student: <code className="text-white">alex_student / StudentPass123!</code>
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <div>
            © {new Date().getFullYear()} FindIT AI Systems. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1 text-slate-400">
              Crafted with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> for campus safety
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
