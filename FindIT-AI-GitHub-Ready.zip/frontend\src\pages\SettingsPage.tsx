import React, { useState } from 'react';
import {
  User as UserIcon,
  ShieldCheck,
  Bell,
  Lock,
  CheckCircle2,
  AlertCircle,
  KeyRound,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { authApi } from '../services/api';

export const SettingsPage: React.FC = () => {
  const { user, refreshUser } = useAuth();

  const [verifyCode, setVerifyCode] = useState('');
  const [verifyMsg, setVerifyMsg] = useState<{ success: boolean; text: string } | null>(null);

  // Bio & preferences
  const [bio, setBio] = useState(user?.profile?.bio || '');
  const [emailNotifs, setEmailNotifs] = useState(user?.profile?.email_notifications ?? true);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  // Password
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passMsg, setPassMsg] = useState<{ success: boolean; text: string } | null>(null);

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifyMsg(null);
    try {
      await authApi.verifyCollegeEmail(verifyCode);
      setVerifyMsg({ success: true, text: 'College email & ID verified successfully!' });
      refreshUser();
    } catch (err: any) {
      setVerifyMsg({ success: false, text: err.response?.data?.error || 'Invalid code.' });
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMsg(null);
    try {
      await authApi.updateProfile({
        bio,
        email_notifications: emailNotifs,
      });
      setProfileMsg('Preferences updated successfully.');
      refreshUser();
    } catch (err) {}
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);
    try {
      await authApi.changePassword({
        old_password: oldPassword,
        new_password: newPassword,
      });
      setPassMsg({ success: true, text: 'Password updated successfully.' });
      setOldPassword('');
      setNewPassword('');
    } catch (err: any) {
      setPassMsg({ success: false, text: err.response?.data?.old_password?.[0] || 'Failed to change password.' });
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      <div className="pb-6 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Account & Security Settings
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Manage your student profile, college email verification, and recovery alert preferences
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Profile Card */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
              <UserIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Profile Information</h2>
              <p className="text-xs text-slate-400">@{user?.username} ({user?.role})</p>
            </div>
          </div>

          <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                disabled
                value={`${user?.first_name || ''} ${user?.last_name || ''}`}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">College Email</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Bio / Major</label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={2}
                placeholder="Add major or student interests..."
                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
              ></textarea>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Email Notification Alerts
              </span>
              <input
                type="checkbox"
                checked={emailNotifs}
                onChange={(e) => setEmailNotifs(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded"
              />
            </div>

            {profileMsg && <p className="text-emerald-600 font-semibold">{profileMsg}</p>}

            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold shadow-sm"
            >
              Save Profile
            </button>
          </form>
        </div>

        {/* Verification Card */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">College ID Verification</h2>
              <p className="text-xs text-slate-400">
                Status: {user?.is_verified ? 'Verified Active' : 'Unverified'}
              </p>
            </div>
          </div>

          {user?.is_verified ? (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Your collegiate affiliation is fully verified. You have full access to claim reports.</span>
            </div>
          ) : (
            <form onSubmit={handleVerifyEmail} className="space-y-4 text-xs">
              <p className="text-slate-500">
                Enter your 6-digit verification code sent to your student email. (Demo code: <code className="font-bold">123456</code>).
              </p>
              <input
                type="text"
                value={verifyCode}
                onChange={(e) => setVerifyCode(e.target.value)}
                placeholder="Enter 123456"
                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono"
              />
              {verifyMsg && (
                <p className={verifyMsg.success ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                  {verifyMsg.text}
                </p>
              )}
              <button
                type="submit"
                className="px-4 py-2 bg-forest-800 text-white rounded-xl font-bold shadow-sm"
              >
                Verify College Affiliation
              </button>
            </form>
          )}

          {/* Password Section */}
          <div className="pt-6 border-t border-slate-100 dark:border-slate-700 space-y-3 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-emerald-600" /> Change Password
            </h3>
            <form onSubmit={handleChangePassword} className="space-y-3">
              <input
                type="password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                placeholder="Current password"
                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password (min 8 chars)"
                className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              {passMsg && (
                <p className={passMsg.success ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                  {passMsg.text}
                </p>
              )}
              <button
                type="submit"
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl font-bold"
              >
                Update Password
              </button>
            </form>
          </div>
        </div>

      </div>

    </div>
  );
};
