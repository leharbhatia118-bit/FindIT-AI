from rest_framework import serializers
from .models import MatchSuggestion
from apps.reports.serializers import ItemReportListSerializer

class MatchSuggestionSerializer(serializers.ModelSerializer):
    lost_report_detail = ItemReportListSerializer(source='lost_report', read_only=True)
    found_report_detail = ItemReportListSerializer(source='found_report', read_only=True)

    class Meta:
        model = MatchSuggestion
        fields = [
            'id', 'lost_report', 'found_report',
            'lost_report_detail', 'found_report_detail',
            'overall_score', 'text_score', 'image_score', 'location_score', 'date_score',
            'weights_used', 'algorithm_used', 'explanation', 'status',
            'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'overall_score', 'text_score', 'image_score', 'location_score', 'date_score',
            'weights_used', 'algorithm_used', 'explanation', 'created_at', 'updated_at'
        ]
