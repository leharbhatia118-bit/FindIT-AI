import React from 'react';
import { X, Sparkles, MapPin, Calendar, Check, AlertCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { MatchSuggestion } from '../../types';

interface ComparisonModalProps {
  suggestion: MatchSuggestion | null;
  onClose: () => void;
  onConfirmMatch: (id: number) => void;
  onDismiss: (id: number) => void;
  onInitiateClaim: (foundReportId: number) => void;
}

export const ComparisonModal: React.FC<ComparisonModalProps> = ({
  suggestion,
  onClose,
  onConfirmMatch,
  onDismiss,
  onInitiateClaim,
}) => {
  if (!suggestion) return null;

  const lost = suggestion.lost_report_detail;
  const found = suggestion.found_report_detail;
  const scorePercent = Math.round(suggestion.overall_score * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-forest-800 flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  AI Match Analysis
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  {scorePercent}% Overall Similarity
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Multi-modal breakdown comparing lost report #{suggestion.lost_report} against found report #{suggestion.found_report}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Side by Side Comparison Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Lost Report Card */}
            <div className="p-5 rounded-2xl bg-rose-50/40 dark:bg-rose-950/20 border border-rose-200/80 dark:border-rose-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-rose-500 text-white">
                  Lost Item
                </span>
                <span className="text-[11px] text-slate-400">#{lost?.id}</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {lost?.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {lost?.description}
              </p>
              <div className="space-y-1.5 text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-rose-100 dark:border-rose-900/30">
                <div className="flex justify-between">
                  <span>Category:</span>
                  <span className="font-semibold text-slate-700 dark:text-slate-300">{lost?.category}</span>
                </div>
                {lost?.brand && (
                  <div className="flex justify-between">
                    <span>Brand:</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">{lost?.brand}</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-rose-500" />
                  <span>{lost?.location_name || lost?.location_detail || 'Campus'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{lost?.incident_date}</span>
                </div>
              </div>
            </div>

            {/* Found Report Card */}
            <div className="p-5 rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-900/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-600 text-white">
                  Found Item
                </span>
                <span className="text-[11px] text-slate-400">#{found?.id}</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {found?.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {found?.description}
              </p>
              <div className="space-y-1.5 text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-emerald-100 dark:border-emerald-900/30">
                <div className="flex justify-between">
                  <span>Category:</span>
                  <span className="font-semibold text-slate-700 dark:text-slate-300">{found?.category}</span>
                </div>
                {found?.brand && (
                  <div className="flex justify-between">
                    <span>Brand:</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">{found?.brand}</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{found?.location_name || found?.location_detail || 'Campus'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{found?.incident_date}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Component Similarity Meters */}
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-4">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
              Similarity Components Breakdown
            </h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Text similarity */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 dark:text-slate-300">Semantic & Lexical Text</span>
                  <span className="text-emerald-600 font-bold">{Math.round(suggestion.text_score * 100)}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all"
                    style={{ width: `${Math.round(suggestion.text_score * 100)}%` }}
                  ></div>
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Method: {suggestion.explanation?.text_method || 'Pure TF-IDF Cosine'}
                </span>
              </div>

              {/* Location similarity */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 dark:text-slate-300">Campus Location Proximity</span>
                  <span className="text-emerald-600 font-bold">{Math.round(suggestion.location_score * 100)}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full transition-all"
                    style={{ width: `${Math.round(suggestion.location_score * 100)}%` }}
                  ></div>
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Method: {suggestion.explanation?.location_method || 'Same Campus Building'}
                </span>
              </div>

              {/* Date similarity */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 dark:text-slate-300">Temporal Proximity</span>
                  <span className="text-emerald-600 font-bold">{Math.round(suggestion.date_score * 100)}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full transition-all"
                    style={{ width: `${Math.round(suggestion.date_score * 100)}%` }}
                  ></div>
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  Exponential time-decay function
                </span>
              </div>

              {/* Visual similarity */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 dark:text-slate-300">Visual Image Appearance</span>
                  <span className="text-emerald-600 font-bold">
                    {suggestion.image_score != null ? `${Math.round(suggestion.image_score * 100)}%` : 'No Image (Renormalized)'}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full bg-purple-500 rounded-full transition-all"
                    style={{ width: `${suggestion.image_score != null ? Math.round(suggestion.image_score * 100) : 0}%` }}
                  ></div>
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5 block">
                  {suggestion.image_score != null ? 'Color & Perceptual Features' : 'Weights dynamically renormalized across available factors'}
                </span>
              </div>
            </div>
          </div>

          {/* AI Explanation Bullet Points */}
          <div className="p-4 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30">
            <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-300 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-600" /> Why FindIT AI Matched These Reports:
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
              {suggestion.explanation?.bullet_points?.map((bullet, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-emerald-500 font-bold mt-0.5">•</span>
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onDismiss(suggestion.id)}
              className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
            >
              Dismiss Suggestion
            </button>
            <button
              onClick={() => onConfirmMatch(suggestion.id)}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 transition-colors"
            >
              Mark as Confirmed
            </button>
          </div>

          {found && (
            <button
              onClick={() => {
                onClose();
                onInitiateClaim(found.id);
              }}
              className="px-5 py-2.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-md shadow-emerald-700/20 flex items-center gap-2"
            >
              <span>Submit Ownership Claim</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
