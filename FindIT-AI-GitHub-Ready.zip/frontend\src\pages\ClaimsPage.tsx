import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Clock,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  FileText,
  Printer,
  MapPin,
  Calendar,
  Lock,
} from 'lucide-react';
import { claimsApi } from '../services/api';
import { Claim } from '../types';
import { EmptyState } from '../components/common/EmptyState';
import { CardSkeleton } from '../components/common/LoadingSkeleton';

export const ClaimsPage: React.FC = () => {
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('');

  const fetchClaims = () => {
    setLoading(true);
    const params = filterStatus ? { status: filterStatus } : {};
    claimsApi
      .getClaims(params)
      .then((data) => setClaims(data.results || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchClaims();
  }, [filterStatus]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Approved - Pickup Ready
          </span>
        );
      case 'RECOVERED':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Handover Complete
          </span>
        );
      case 'REJECTED':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5" /> Claim Rejected
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" /> Under Admin Review
          </span>
        );
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Ownership Claims & Verification Desk
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Track verification progress, review handover OTP codes, and print recovery receipts
          </p>
        </div>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200"
        >
          <option value="">All Claims</option>
          <option value="PENDING">Pending Review</option>
          <option value="APPROVED">Approved (Pickup Ready)</option>
          <option value="RECOVERED">Recovered & Closed</option>
          <option value="REJECTED">Rejected</option>
        </select>
      </div>

      {loading ? (
        <div className="space-y-4">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : claims.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No Ownership Claims Found"
          description="When you file a claim on a found item, you can track administrative verification and your handover code here."
        />
      ) : (
        <div className="space-y-6">
          {claims.map((c) => {
            const handover = c.handover;
            const isApproved = c.status === 'APPROVED';
            const isRecovered = c.status === 'RECOVERED';

            return (
              <div
                key={c.id}
                className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 p-6 sm:p-8 shadow-subtle space-y-6"
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-700/60">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Claim #{c.id} • Filed on {new Date(c.created_at).toLocaleDateString()}
                    </span>
                    <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                      {c.item_report_detail?.title || `Item #${c.item_report}`}
                    </h2>
                  </div>
                  <div>{getStatusBadge(c.status)}</div>
                </div>

                {/* Approved Handover OTP Box */}
                {isApproved && handover && (
                  <div className="p-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-forest-800 text-white shadow-xl space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <KeyRound className="w-5 h-5 text-emerald-200" />
                        <span className="text-xs font-bold uppercase tracking-wider text-emerald-100">
                          Physical Pickup Verification Token
                        </span>
                      </div>
                      <span className="text-[11px] text-emerald-200 font-medium">
                        Expires in 48 Hours
                      </span>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-2">
                      <div>
                        <div className="text-3xl sm:text-4xl font-mono font-extrabold tracking-widest text-white">
                          {handover.handover_code}
                        </div>
                        <p className="text-xs text-emerald-100 mt-1">
                          Present this 6-digit code at the Administration Desk along with your College ID.
                        </p>
                      </div>

                      <div className="p-3 bg-white/10 rounded-xl backdrop-blur-sm text-xs font-mono text-center sm:text-right shrink-0">
                        <span className="block text-emerald-200 text-[10px]">Reference Receipt ID:</span>
                        <span className="font-bold">{handover.recovery_receipt_number}</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Recovered Receipt Certificate */}
                {isRecovered && handover && (
                  <div className="p-5 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-blue-900 dark:text-blue-300">
                        <ShieldCheck className="w-4 h-4 text-blue-600" />
                        <span>Official Recovery Certificate</span>
                      </div>
                      <button
                        onClick={() => window.print()}
                        className="text-xs font-bold text-blue-700 dark:text-blue-400 hover:underline flex items-center gap-1"
                      >
                        <Printer className="w-3.5 h-3.5" /> Print Receipt
                      </button>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Receipt Number</span>
                        <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                          {handover.recovery_receipt_number}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Confirmed At</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {handover.confirmed_at ? new Date(handover.confirmed_at).toLocaleDateString() : 'Confirmed'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Verified By Officer</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          @{handover.confirmed_by_username || 'Campus Security'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Recovery Status</span>
                        <span className="font-bold text-emerald-600">Verified & Complete</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Claimant Statements Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-wider text-[10px]">
                      Circumstance Statement
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                      {c.ownership_description}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 space-y-1">
                    <span className="font-bold text-slate-400 uppercase tracking-wider text-[10px] flex items-center gap-1">
                      <Lock className="w-3 h-3 text-emerald-600" /> Confidential Ownership Proof
                    </span>
                    <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-mono">
                      {c.private_proof_details}
                    </p>
                  </div>
                </div>

                {/* Review Notes from Admin */}
                {c.review_notes && (
                  <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-900 text-xs text-slate-600 dark:text-slate-400">
                    <span className="font-bold text-slate-800 dark:text-slate-200">Officer Review Note: </span>
                    {c.review_notes}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
