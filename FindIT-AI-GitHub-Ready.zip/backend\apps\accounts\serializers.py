from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from .models import StudentProfile, AuditLog, UserRole

User = get_user_model()

class StudentProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentProfile
        fields = ['id', 'bio', 'preferred_contact', 'email_notifications', 'match_notifications', 'created_at', 'updated_at']

class UserSerializer(serializers.ModelSerializer):
    profile = StudentProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name',
            'role', 'college_id', 'department', 'phone_number',
            'is_verified', 'created_at', 'profile'
        ]
        read_only_fields = ['id', 'created_at']

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        request = self.context.get('request')
        # Mask phone number if viewing another user's profile and not admin
        if request and request.user.is_authenticated:
            if request.user.id != instance.id and not request.user.is_admin_or_staff():
                if ret.get('phone_number'):
                    phone = ret['phone_number']
                    ret['phone_number'] = phone[:3] + '***' + phone[-2:] if len(phone) >= 5 else '***'
        return ret

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password2 = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'password', 'password2',
            'first_name', 'last_name', 'role', 'college_id', 'department', 'phone_number'
        ]
        extra_kwargs = {
            'email': {'required': True},
            'first_name': {'required': True},
        }

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Passwords do not match."})
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2', None)
        password = validated_data.pop('password')
        role = validated_data.pop('role', UserRole.STUDENT)
        user = User.objects.create(
            role=role,
            **validated_data
        )
        user.set_password(password)
        # Mock auto-verify if domain is .edu or .ac.in
        if user.email and (user.email.endswith('.edu') or user.email.endswith('.ac.in')):
            user.is_verified = True
        user.save()
        StudentProfile.objects.create(user=user)
        return user

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, validators=[validate_password])

class AuditLogSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model = AuditLog
        fields = ['id', 'username', 'action', 'resource_type', 'resource_id', 'ip_address', 'details', 'created_at']
