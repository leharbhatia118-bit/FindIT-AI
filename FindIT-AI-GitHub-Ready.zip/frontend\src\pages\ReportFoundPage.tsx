import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Sparkles,
  MapPin,
  Calendar,
  Lock,
  Upload,
  AlertCircle,
  CheckCircle2,
  Tag,
  ShieldCheck,
  EyeOff,
} from 'lucide-react';
import { reportsApi } from '../services/api';
import { Campus, CampusLocation, ItemCategory } from '../types';
import { useAuth } from '../context/AuthContext';

const foundSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters long'),
  description: z.string().min(10, 'Please provide more detail (at least 10 characters)'),
  category: z.string().min(1, 'Please select a category'),
  brand: z.string().optional(),
  primary_color: z.string().optional(),
  secondary_color: z.string().optional(),
  incident_date: z.string().min(1, 'Date found is required'),
  incident_time_approx: z.string().optional(),
  campus: z.string().min(1, 'Please select your campus'),
  location: z.string().optional(),
  location_detail: z.string().optional(),
  private_identifiers: z.string().optional(),
});

type FormData = z.infer<typeof foundSchema>;

const CATEGORIES: { value: ItemCategory; label: string }[] = [
  { value: 'ELECTRONICS', label: 'Electronics & Gadgets' },
  { value: 'WALLETS_BAGS', label: 'Wallets, Purses & Bags' },
  { value: 'KEYS', label: 'Keys & Keychains' },
  { value: 'CARDS_IDS', label: 'ID Cards & Badges' },
  { value: 'BOOKS_STATIONERY', label: 'Books & Stationery' },
  { value: 'CLOTHING', label: 'Clothing & Accessories' },
  { value: 'JEWELRY_WATCHES', label: 'Jewelry & Watches' },
  { value: 'OTHER', label: 'Other Items' },
];

export const ReportFoundPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const [campuses, setCampuses] = useState<Campus[]>([]);
  const [locations, setLocations] = useState<CampusLocation[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    reportsApi.getCampuses().then(setCampuses).catch(() => {});
    reportsApi.getLocations().then(setLocations).catch(() => {});
  }, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(foundSchema),
    defaultValues: {
      incident_date: new Date().toISOString().split('T')[0],
      category: 'WALLETS_BAGS',
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setFilePreview(URL.createObjectURL(file));
    }
  };

  const onSubmit = async (data: FormData) => {
    if (!isAuthenticated) {
      navigate('/login?redirect=/report-found');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    try {
      const payload: any = {
        report_type: 'FOUND',
        title: data.title,
        description: data.description,
        category: data.category,
        brand: data.brand || '',
        primary_color: data.primary_color || '',
        secondary_color: data.secondary_color || '',
        incident_date: data.incident_date,
        incident_time_approx: data.incident_time_approx || '',
        campus: parseInt(data.campus, 10),
        location: data.location ? parseInt(data.location, 10) : null,
        location_detail: data.location_detail || '',
        private_identifiers: data.private_identifiers || '',
      };

      const created = await reportsApi.createItem(payload);

      if (selectedFile) {
        const formData = new FormData();
        formData.append('image', selectedFile);
        await reportsApi.uploadImage(created.id, formData);
      }

      navigate(`/items/${created.id}?created=true`);
    } catch (err: any) {
      setErrorMsg(err.response?.data?.message || 'Failed to submit found report. Please check fields.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Title */}
      <div className="mb-8 text-center max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-bold mb-3">
          <span>Campus Good Samaritan Intake</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Turn In a Found Valuables Report
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Thank you for helping keep campus honest. FindIT AI will automatically notify students who reported losing matching items.
        </p>
      </div>

      {/* Safety Banner */}
      <div className="mb-6 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/40 flex items-start gap-3 text-xs text-amber-900 dark:text-amber-200">
        <EyeOff className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Protect Ownership Verification: </span>
          Do not publicly reveal private details (such as engraved initials, wallpaper photos, or student roll numbers). Keep those in the Confidential Verification Notes below so only the rightful owner can verify themselves!
        </div>
      </div>

      {errorMsg && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Form */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 p-6 sm:p-10 shadow-subtle space-y-8"
      >
        {/* Section 1 */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <Tag className="w-4 h-4 text-emerald-600" /> 1. Found Item Overview
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Item Title *
              </label>
              <input
                type="text"
                {...register('title')}
                placeholder="e.g. Black Leather Wallet with Red Accent Seams"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              {errors.title && <p className="text-xs text-rose-600 mt-1">{errors.title.message}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Category *
              </label>
              <select
                {...register('category')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Brand / Logo (if visible)
              </label>
              <input
                type="text"
                {...register('brand')}
                placeholder="e.g. Bellroy, Apple, Hydro Flask"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Primary Color
              </label>
              <input
                type="text"
                {...register('primary_color')}
                placeholder="e.g. Black, White, Navy"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Secondary Color / Accent
              </label>
              <input
                type="text"
                {...register('secondary_color')}
                placeholder="e.g. Red, Silver, Gold"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Public Safe Description *
              </label>
              <textarea
                {...register('description')}
                rows={3}
                placeholder="Describe visible exterior features without giving away secret interior contents..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              ></textarea>
              {errors.description && <p className="text-xs text-rose-600 mt-1">{errors.description.message}</p>}
            </div>
          </div>
        </div>

        {/* Section 2 */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
          <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-600" /> 2. Location & Date Found
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Campus *
              </label>
              <select
                {...register('campus')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="">Select Campus</option>
                {campuses.map((camp) => (
                  <option key={camp.id} value={camp.id}>
                    {camp.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Building / Zone Found
              </label>
              <select
                {...register('location')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="">Select Campus Location</option>
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Date Found *
              </label>
              <input
                type="date"
                {...register('incident_date')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Approximate Time
              </label>
              <input
                type="text"
                {...register('incident_time_approx')}
                placeholder="e.g. Found around 4:15 PM"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Current Storage / Turn-In Spot
              </label>
              <input
                type="text"
                {...register('location_detail')}
                placeholder="e.g. Turned into Central Library 2nd floor front desk monitor"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Photo Upload */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
          <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <Upload className="w-4 h-4 text-emerald-600" /> 3. Found Item Photo
          </h2>

          <div className="flex items-center gap-6">
            <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-6 text-center hover:border-emerald-500 transition-colors cursor-pointer w-full sm:w-1/2">
              <input
                type="file"
                accept="image/png, image/jpeg, image/webp"
                onChange={handleFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <Upload className="w-8 h-8 mx-auto text-slate-400 mb-2" />
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Upload found item photo
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Enables AI visual similarity matching
              </p>
            </div>

            {filePreview && (
              <div className="w-32 h-32 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 relative shrink-0">
                <img src={filePreview} alt="Preview" className="w-full h-full object-cover" />
              </div>
            )}
          </div>
        </div>

        {/* Section 4: Secret Verification Notes */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/50 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 dark:text-emerald-300">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Admin Verification Key (Hidden from Public)</span>
            </div>
            <p className="text-[11px] text-emerald-800 dark:text-emerald-300 leading-relaxed">
              Note any secret interior contents (cards, money, IDs, keychain shapes) that only the true owner would know. Campus security will use this to verify claimant questions!
            </p>
            <textarea
              {...register('private_identifiers')}
              rows={3}
              placeholder="e.g. 'Contains student card for CS major and a folded $20 bill in internal slot.'"
              className="w-full px-3 py-2 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            ></textarea>
          </div>
        </div>

        {/* Submit */}
        <div className="pt-4 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-3 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-md shadow-emerald-700/20 flex items-center gap-2 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            <span>{submitting ? 'Registering & Matching...' : 'Submit Found Report'}</span>
          </button>
        </div>
      </form>

    </div>
  );
};
