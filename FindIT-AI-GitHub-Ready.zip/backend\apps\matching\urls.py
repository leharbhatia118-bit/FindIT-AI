from django.urls import path
from .views import (
    MatchSuggestionListView,
    MatchSuggestionDetailView,
    TriggerReportMatchView,
)

urlpatterns = [
    path('suggestions/', MatchSuggestionListView.as_view(), name='match_suggestions_list'),
    path('suggestions/<int:pk>/', MatchSuggestionDetailView.as_view(), name='match_suggestion_detail'),
    path('trigger/<int:report_id>/', TriggerReportMatchView.as_view(), name='trigger_matching'),
]
