import datetime
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from apps.reports.models import Campus, CampusLocation, ItemReport

User = get_user_model()

class ItemReportTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.owner = User.objects.create_user(
            username="reporter1", email="rep1@univ.edu", password="Password123!", role="STUDENT"
        )
        self.viewer = User.objects.create_user(
            username="viewer1", email="view1@univ.edu", password="Password123!", role="STUDENT"
        )
        self.admin = User.objects.create_user(
            username="admin1", email="adm1@univ.edu", password="Password123!", role="ADMIN", is_staff=True
        )

        self.campus = Campus.objects.create(name="Tech Campus", code="TC", city="Tech City")
        self.location = CampusLocation.objects.create(campus=self.campus, name="Library 1st Floor")

    def test_create_lost_report(self):
        self.client.force_authenticate(user=self.owner)
        payload = {
            "report_type": "LOST",
            "title": "Navy Blue Backpack with Laptop",
            "description": "Lost near study desks on 1st floor",
            "category": "WALLETS_BAGS",
            "brand": "Jansport",
            "primary_color": "Blue",
            "incident_date": str(datetime.date.today()),
            "campus": self.campus.id,
            "location": self.location.id,
            "private_identifiers": "Secret sticker inside back compartment: #9871"
        }
        response = self.client.post('/api/items/', payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['title'], "Navy Blue Backpack with Laptop")

    def test_privacy_masking_on_private_identifiers(self):
        report = ItemReport.objects.create(
            report_type="FOUND",
            title="Keys on Ring",
            description="Found in grass",
            category="KEYS",
            incident_date=datetime.date.today(),
            campus=self.campus,
            creator=self.owner,
            private_identifiers="Engraved with initials: 'A.R.'"
        )

        # Viewer (non-owner, non-admin) accessing detail
        self.client.force_authenticate(user=self.viewer)
        response = self.client.get(f'/api/items/{report.id}/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("Protected", response.data['private_identifiers'])
        self.assertNotIn("A.R.", response.data['private_identifiers'])

        # Owner accessing detail
        self.client.force_authenticate(user=self.owner)
        owner_resp = self.client.get(f'/api/items/{report.id}/')
        self.assertIn("A.R.", owner_resp.data['private_identifiers'])

        # Admin accessing detail
        self.client.force_authenticate(user=self.admin)
        admin_resp = self.client.get(f'/api/items/{report.id}/')
        self.assertIn("A.R.", admin_resp.data['private_identifiers'])

    def test_filter_by_category_and_search(self):
        ItemReport.objects.create(
            report_type="LOST", title="Silver MacBook Air M2", description="Left in lab",
            category="ELECTRONICS", incident_date=datetime.date.today(), campus=self.campus, creator=self.owner
        )
        ItemReport.objects.create(
            report_type="LOST", title="Calculus Textbook 8th Ed", description="Math book",
            category="BOOKS_STATIONERY", incident_date=datetime.date.today(), campus=self.campus, creator=self.owner
        )

        response = self.client.get('/api/items/?category=ELECTRONICS')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Should only find the MacBook
        results = response.data.get('results', response.data)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['title'], "Silver MacBook Air M2")
