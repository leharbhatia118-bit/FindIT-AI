import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Sparkles, Lock, User, AlertCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const LoginPage: React.FC = () => {
  const { login, quickDemoLogin } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const redirectUrl = searchParams.get('redirect') || '/dashboard';

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);
    try {
      await login({ username, password });
      navigate(redirectUrl);
    } catch (err: any) {
      setErrorMsg(err.response?.data?.detail || 'Invalid username or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemo = async (role: 'admin' | 'alex' | 'maya' | 'security') => {
    setLoading(true);
    try {
      await quickDemoLogin(role);
      navigate(role === 'admin' || role === 'security' ? '/admin' : '/dashboard');
    } catch (err) {
      setErrorMsg('Failed to sign in as demo persona.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-forest-800 flex items-center justify-center text-white mx-auto shadow-md">
            <Sparkles className="w-6 h-6 text-emerald-300" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">
            Log in to FindIT AI
          </h1>
          <p className="text-xs text-slate-500">
            Sign in with your university credentials or select a demo account
          </p>
        </div>

        {/* Demo Mode Quick Sign-in Box */}
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-emerald-900 dark:text-emerald-300">
              ⚡ 1-Click Hackathon Demo Sign-In:
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleDemo('admin')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 text-left border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 font-medium"
            >
              <span className="block font-bold">🛡️ Dr. Mitchell</span>
              <span className="text-[10px] text-slate-400">Campus Admin</span>
            </button>
            <button
              type="button"
              onClick={() => handleDemo('alex')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 text-left border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 font-medium"
            >
              <span className="block font-bold">🎒 Alex Rivera</span>
              <span className="text-[10px] text-slate-400">Student (Lost)</span>
            </button>
            <button
              type="button"
              onClick={() => handleDemo('maya')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 text-left border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 font-medium"
            >
              <span className="block font-bold">🔍 Maya Chen</span>
              <span className="text-[10px] text-slate-400">Student (Found)</span>
            </button>
            <button
              type="button"
              onClick={() => handleDemo('security')}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 text-left border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 font-medium"
            >
              <span className="block font-bold">👮 Officer Davis</span>
              <span className="text-[10px] text-slate-400">Campus Safety</span>
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Regular Login Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4 text-xs"
        >
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Username
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                placeholder="e.g. alex_student or admin"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="Enter password"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-forest-800 hover:bg-forest-900 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white font-bold transition-colors shadow-sm disabled:opacity-50"
          >
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>

          <div className="pt-2 text-center text-slate-500">
            Don't have an account?{' '}
            <Link to="/register" className="font-bold text-emerald-600 dark:text-emerald-400 hover:underline">
              Create an account
            </Link>
          </div>
        </form>

      </div>
    </div>
  );
};
