import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  Clock,
  KeyRound,
  FileText,
  Users,
  Search,
  Check,
  X,
  RefreshCw,
  TrendingUp,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { analyticsApi, claimsApi, authApi, reportsApi } from '../services/api';
import { AnalyticsData, Claim } from '../types';

const COLORS = ['#10b981', '#047857', '#064e3b', '#3b82f6', '#f59e0b', '#ec4899', '#8b5cf6', '#64748b'];

export const AdminDashboardPage: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [pendingClaims, setPendingClaims] = useState<Claim[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [abuseReports, setAbuseReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Handover Verification Terminal State
  const [verifyClaimId, setVerifyClaimId] = useState('');
  const [handoverCodeInput, setHandoverCodeInput] = useState('');
  const [verifyNotes, setVerifyNotes] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState<{ success: boolean; msg: string; receipt?: string } | null>(null);

  // Reviewing a claim
  const [reviewingClaim, setReviewingClaim] = useState<Claim | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [analyticsData, claimsData, auditData, abuseData] = await Promise.all([
        analyticsApi.getAdminAnalytics(),
        claimsApi.getClaims({ status: 'PENDING' }),
        authApi.getAuditLogs(),
        reportsApi.getAbuseReportsAdmin().catch(() => ({ results: [] })),
      ]);
      setAnalytics(analyticsData);
      setPendingClaims(claimsData.results || []);
      setAuditLogs(auditData.results || auditData || []);
      setAbuseReports(abuseData.results || abuseData || []);
    } catch (err) {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleVerifyHandover = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyClaimId || !handoverCodeInput) return;
    setVerifying(true);
    setVerifyResult(null);

    try {
      const res = await claimsApi.confirmHandover(parseInt(verifyClaimId, 10), {
        handover_code: handoverCodeInput.trim(),
        notes: verifyNotes.trim(),
      });
      setVerifyResult({
        success: true,
        msg: 'Handover verified successfully! Item marked recovered.',
        receipt: res.handover?.recovery_receipt_number,
      });
      setHandoverCodeInput('');
      setVerifyClaimId('');
      setVerifyNotes('');
      fetchDashboardData();
    } catch (err: any) {
      setVerifyResult({
        success: false,
        msg: err.response?.data?.error || 'Invalid or expired handover code.',
      });
    } finally {
      setVerifying(false);
    }
  };

  const handleClaimReviewAction = async (claimId: number, status: 'APPROVED' | 'REJECTED') => {
    try {
      await claimsApi.reviewClaim(claimId, {
        status,
        review_notes: reviewNotes || (status === 'APPROVED' ? 'Verified evidence against records.' : 'Evidence insufficient.'),
      });
      setReviewingClaim(null);
      setReviewNotes('');
      fetchDashboardData();
    } catch (err) {}
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center animate-pulse">
        <div className="h-8 bg-slate-200 dark:bg-slate-700 w-1/3 mx-auto rounded mb-4"></div>
        <div className="h-64 bg-slate-200 dark:bg-slate-700 rounded-3xl w-full"></div>
      </div>
    );
  }

  const overview = analytics?.overview;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Campus Security & Administration Hub
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-800 text-white">
              Admin Access
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time computed platform metrics, pending claim reviews, and physical handover terminal
          </p>
        </div>

        <button
          onClick={fetchDashboardData}
          className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Total Reports</span>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
            {overview?.total_reports || 0}
          </div>
          <span className="text-[10px] text-slate-500">
            {overview?.lost_reports} Lost • {overview?.found_reports} Found
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Active Items</span>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">
            {overview?.active_reports || 0}
          </div>
          <span className="text-[10px] text-slate-500">Open for recovery</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
          <span className="text-[11px] font-bold text-slate-400 uppercase">AI Suggestions</span>
          <div className="text-2xl font-extrabold text-amber-500 mt-1">
            {overview?.potential_matches || 0}
          </div>
          <span className="text-[10px] text-slate-500">Cross-item matches</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Pending Claims</span>
          <div className="text-2xl font-extrabold text-rose-500 mt-1">
            {overview?.pending_claims || 0}
          </div>
          <span className="text-[10px] text-rose-600 font-semibold">Requires verification</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Recoveries</span>
          <div className="text-2xl font-extrabold text-blue-600 mt-1">
            {overview?.confirmed_recoveries || 0}
          </div>
          <span className="text-[10px] text-blue-600 font-semibold">Confirmed handovers</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Recovery Rate</span>
          <div className="text-2xl font-extrabold text-forest-800 dark:text-emerald-300 mt-1">
            {overview?.recovery_rate_percentage || 0}%
          </div>
          <span className="text-[9px] text-slate-400 block leading-tight">
            (Recovered / Total)
          </span>
        </div>
      </div>

      {/* Handover Verification Desk Terminal */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-forest-950 via-slate-900 to-forest-900 text-white shadow-2xl border border-emerald-900/60 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Physical Handover Verification Terminal</h2>
            <p className="text-xs text-slate-400">
              Enter student Claim ID and the 6-digit OTP token presented at the safety desk
            </p>
          </div>
        </div>

        {verifyResult && (
          <div
            className={`p-4 rounded-2xl border text-xs flex items-start gap-2.5 ${
              verifyResult.success
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200'
                : 'bg-rose-950/80 border-rose-500 text-rose-200'
            }`}
          >
            {verifyResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />}
            <div>
              <span className="font-bold">{verifyResult.msg}</span>
              {verifyResult.receipt && (
                <div className="mt-1 font-mono text-[11px]">
                  Official Receipt Number: <span className="underline">{verifyResult.receipt}</span>
                </div>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleVerifyHandover} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-xs font-bold text-emerald-200 mb-1">
              Claim ID # *
            </label>
            <input
              type="number"
              value={verifyClaimId}
              onChange={(e) => setVerifyClaimId(e.target.value)}
              placeholder="e.g. 1"
              required
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-950/80 text-white text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-emerald-200 mb-1">
              6-Digit Handover Code *
            </label>
            <input
              type="text"
              maxLength={8}
              value={handoverCodeInput}
              onChange={(e) => setHandoverCodeInput(e.target.value)}
              placeholder="e.g. 481902"
              required
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-950/80 text-white text-xs font-mono tracking-widest focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-emerald-200 mb-1">
              Officer Notes (ID Card #)
            </label>
            <input
              type="text"
              value={verifyNotes}
              onChange={(e) => setVerifyNotes(e.target.value)}
              placeholder="e.g. Student ID CS2026 checked"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-950/80 text-white text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <button
              type="submit"
              disabled={verifying}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-md disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{verifying ? 'Verifying...' : 'Confirm Handover'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Category Breakdown Bar Chart */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Reports by Category
              </h3>
              <p className="text-xs text-slate-500">Distribution of campus reported items</p>
            </div>
            <BarChart3 className="w-5 h-5 text-emerald-600" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics?.category_distribution || []}>
                <XAxis dataKey="category" tick={{ fontSize: 10 }} interval={0} angle={-25} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Location Hotspots */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Top Campus Location Hotspots
              </h3>
              <p className="text-xs text-slate-500">Buildings and zones with highest report volume</p>
            </div>
            <TrendingUp className="w-5 h-5 text-emerald-600" />
          </div>

          <div className="space-y-3 pt-2">
            {(analytics?.location_hotspots || []).map((loc, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="truncate pr-4">
                  <span className="font-bold text-slate-800 dark:text-slate-200 truncate block">
                    {loc.location}
                  </span>
                  <span className="text-[10px] text-slate-400">{loc.campus}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <div className="w-24 h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 rounded-full"
                      style={{ width: `${Math.min(100, (loc.count / (overview?.total_reports || 1)) * 100 * 2)}%` }}
                    ></div>
                  </div>
                  <span className="font-mono font-bold text-slate-700 dark:text-slate-300 w-6 text-right">
                    {loc.count}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Claims Pending Review Queue */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Claims Pending Administrative Verification ({pendingClaims.length})
            </h2>
            <p className="text-xs text-slate-500">
              Inspect confidential student answers against turned-in item records
            </p>
          </div>
        </div>

        {pendingClaims.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400 border border-dashed rounded-2xl">
            No claims currently waiting for review.
          </div>
        ) : (
          <div className="space-y-4">
            {pendingClaims.map((claim) => (
              <div
                key={claim.id}
                className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase">
                      Claim #{claim.id} • Claimant: @{claim.claimant_username}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Item: {claim.item_report_detail?.title || `Item #${claim.item_report}`}
                    </h4>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleClaimReviewAction(claim.id, 'APPROVED')}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center gap-1 shadow-sm"
                    >
                      <Check className="w-3.5 h-3.5" /> Approve & Issue Code
                    </button>
                    <button
                      onClick={() => handleClaimReviewAction(claim.id, 'REJECTED')}
                      className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold transition-colors flex items-center gap-1"
                    >
                      <X className="w-3.5 h-3.5" /> Reject
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-200/80 dark:border-slate-800">
                  <div className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                    <span className="font-bold text-slate-400 uppercase text-[10px] block mb-1">
                      Claimant Circumstance:
                    </span>
                    <p className="text-slate-700 dark:text-slate-300">{claim.ownership_description}</p>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40">
                    <span className="font-bold text-emerald-800 dark:text-emerald-300 uppercase text-[10px] block mb-1">
                      Confidential Evidence Provided:
                    </span>
                    <p className="font-mono text-emerald-950 dark:text-emerald-200">{claim.private_proof_details}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Audit Log Table */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-white">
          Security & Handover Audit Trail
        </h2>
        <p className="text-xs text-slate-500">
          Immutable event log of administrative approvals, logins, and recovery actions
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3 rounded-l-xl">Timestamp</th>
                <th className="p-3">User</th>
                <th className="p-3">Action</th>
                <th className="p-3">Resource</th>
                <th className="p-3 rounded-r-xl">ID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
              {auditLogs.slice(0, 8).map((log, i) => (
                <tr key={i} className="hover:bg-slate-50/50 dark:hover:bg-slate-750">
                  <td className="p-3 text-slate-500">
                    {new Date(log.created_at || log.timestamp).toLocaleString()}
                  </td>
                  <td className="p-3 font-sans font-bold text-slate-800 dark:text-slate-200">
                    @{log.username || 'System'}
                  </td>
                  <td className="p-3 font-sans font-semibold text-emerald-600 dark:text-emerald-400">
                    {log.action}
                  </td>
                  <td className="p-3 text-slate-500">{log.resource_type}</td>
                  <td className="p-3 text-slate-400">{log.resource_id || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
