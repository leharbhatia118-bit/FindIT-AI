"""
Geographical & Campus Location Proximity Engine.
Calculates Haversine distance when coordinates are valid, or falls back to
campus building taxonomy and label matching.
"""

import math
from .constants import CAMPUS_MAX_METERS

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Computes great-circle distance between two GPS coordinates in meters.
    """
    R = 6371000.0  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2))
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return R * c

def compute_location_similarity(report_lost, report_found):
    """
    Computes location proximity score between 0.0 and 1.0.
    Returns:
        (score: float, method: str, details: dict)
    """
    # Check if same campus
    if report_lost.campus_id != report_found.campus_id:
        # Different campuses: strong penalty unless near boundary
        return 0.10, "DIFFERENT_CAMPUS", {
            "lost_campus": report_lost.campus.name,
            "found_campus": report_found.campus.name
        }

    # Case 1: Both have valid GPS coordinates
    has_gps_lost = report_lost.latitude is not None and report_lost.longitude is not None
    has_gps_found = report_found.latitude is not None and report_found.longitude is not None

    if has_gps_lost and has_gps_found:
        dist_m = haversine_distance(
            report_lost.latitude, report_lost.longitude,
            report_found.latitude, report_found.longitude
        )
        # Score decaying smoothly from 1.0 down to 0.1 over CAMPUS_MAX_METERS
        if dist_m <= 25.0:
            score = 1.0
        elif dist_m <= CAMPUS_MAX_METERS:
            # Linear decay from 1.0 to 0.2
            score = 1.0 - 0.8 * (dist_m / CAMPUS_MAX_METERS)
        else:
            score = 0.15

        return round(score, 4), "GPS_HAVERSINE", {
            "distance_meters": round(dist_m, 1),
            "approximate_walk_min": round(dist_m / 80.0, 1)
        }

    # Case 2: Exact same building / CampusLocation FK
    if report_lost.location_id and report_found.location_id:
        if report_lost.location_id == report_found.location_id:
            return 0.95, "SAME_BUILDING_LOCATION", {
                "location_name": str(report_lost.location.name)
            }
        else:
            # Different buildings on same campus
            return 0.40, "DIFFERENT_BUILDINGS_SAME_CAMPUS", {
                "lost_location": str(report_lost.location.name),
                "found_location": str(report_found.location.name)
            }

    # Case 3: Fuzzy label match on location_detail / name
    detail_lost = (report_lost.location_detail or "").strip().lower()
    detail_found = (report_found.location_detail or "").strip().lower()

    if detail_lost and detail_found and (detail_lost in detail_found or detail_found in detail_lost):
        return 0.80, "LOCATION_TEXT_OVERLAP", {
            "matched_text": detail_lost
        }

    # Case 4: Same campus general area
    return 0.50, "SAME_CAMPUS_GENERAL", {
        "campus": report_lost.campus.name
    }
