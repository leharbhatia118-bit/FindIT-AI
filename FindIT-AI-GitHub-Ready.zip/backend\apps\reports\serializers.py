from rest_framework import serializers
from .models import Campus, CampusLocation, ItemReport, ItemImage, AbuseReport

class CampusLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CampusLocation
        fields = ['id', 'name', 'building_code', 'zone_or_floor', 'latitude', 'longitude', 'description']

class CampusSerializer(serializers.ModelSerializer):
    locations = CampusLocationSerializer(many=True, read_only=True)

    class Meta:
        model = Campus
        fields = ['id', 'name', 'code', 'city', 'latitude', 'longitude', 'locations']

class ItemImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemImage
        fields = ['id', 'report', 'image', 'caption', 'created_at']
        read_only_fields = ['id', 'created_at']

class ItemReportListSerializer(serializers.ModelSerializer):
    campus_name = serializers.CharField(source='campus.name', read_only=True)
    location_name = serializers.CharField(source='location.name', read_only=True)
    creator_username = serializers.CharField(source='creator.username', read_only=True)
    images = ItemImageSerializer(many=True, read_only=True)

    class Meta:
        model = ItemReport
        fields = [
            'id', 'report_type', 'title', 'description', 'category',
            'brand', 'primary_color', 'secondary_color',
            'incident_date', 'incident_time_approx',
            'campus', 'campus_name', 'location', 'location_name', 'location_detail',
            'latitude', 'longitude',
            'creator_username', 'status', 'created_at', 'images'
        ]
        # Notice: private_identifiers is STRICTLY omitted from public list views!

class ItemReportDetailSerializer(serializers.ModelSerializer):
    campus_name = serializers.CharField(source='campus.name', read_only=True)
    location_name = serializers.CharField(source='location.name', read_only=True)
    creator_username = serializers.CharField(source='creator.username', read_only=True)
    images = ItemImageSerializer(many=True, read_only=True)
    claims_count = serializers.IntegerField(source='claims.count', read_only=True)

    class Meta:
        model = ItemReport
        fields = [
            'id', 'report_type', 'title', 'description', 'category',
            'brand', 'primary_color', 'secondary_color',
            'incident_date', 'incident_time_approx',
            'campus', 'campus_name', 'location', 'location_name', 'location_detail',
            'latitude', 'longitude',
            'creator', 'creator_username', 'status', 'contact_preference',
            'private_identifiers', 'claims_count', 'created_at', 'updated_at', 'images'
        ]
        read_only_fields = ['id', 'creator', 'created_at', 'updated_at']

    def to_representation(self, instance):
        data = super().to_representation(instance)
        request = self.context.get('request')
        is_owner_or_admin = False
        if request and request.user.is_authenticated:
            if request.user.id == instance.creator_id or request.user.is_admin_or_staff():
                is_owner_or_admin = True
        
        # Privacy guard: if not creator or admin, never expose private identifying features
        if not is_owner_or_admin:
            data['private_identifiers'] = "[Protected - Visible only to item reporter and verified administrators]"
            # Hide creator ID for privacy
            data.pop('creator', None)
        return data

class ItemReportCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemReport
        fields = [
            'id', 'report_type', 'title', 'description', 'category',
            'brand', 'primary_color', 'secondary_color',
            'incident_date', 'incident_time_approx',
            'campus', 'location', 'location_detail',
            'latitude', 'longitude',
            'status', 'private_identifiers', 'contact_preference'
        ]
        read_only_fields = ['id']

    def validate_title(self, value):
        if len(value.strip()) < 3:
            raise serializers.ValidationError("Title must be at least 3 characters long.")
        return value

class AbuseReportSerializer(serializers.ModelSerializer):
    reporter_username = serializers.CharField(source='reporter.username', read_only=True)
    item_title = serializers.CharField(source='reported_item.title', read_only=True)

    class Meta:
        model = AbuseReport
        fields = ['id', 'reporter_username', 'reported_item', 'item_title', 'reason', 'details', 'status', 'created_at']
        read_only_fields = ['id', 'reporter_username', 'created_at']
