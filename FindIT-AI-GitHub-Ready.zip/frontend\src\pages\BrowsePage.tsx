import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Search,
  Filter,
  LayoutGrid,
  List,
  Sparkles,
  MapPin,
  Calendar,
  ChevronDown,
  X,
  SlidersHorizontal,
} from 'lucide-react';
import { reportsApi } from '../services/api';
import { ItemReport, Campus, CampusLocation, ItemCategory } from '../types';
import { ItemCard } from '../components/common/ItemCard';
import { CardSkeleton } from '../components/common/LoadingSkeleton';
import { EmptyState } from '../components/common/EmptyState';

const CATEGORIES: { value: ItemCategory; label: string }[] = [
  { value: 'ELECTRONICS', label: 'Electronics & Gadgets' },
  { value: 'WALLETS_BAGS', label: 'Wallets, Purses & Bags' },
  { value: 'KEYS', label: 'Keys & Keychains' },
  { value: 'CARDS_IDS', label: 'ID Cards & Badges' },
  { value: 'BOOKS_STATIONERY', label: 'Books & Stationery' },
  { value: 'CLOTHING', label: 'Clothing & Accessories' },
  { value: 'JEWELRY_WATCHES', label: 'Jewelry & Watches' },
  { value: 'OTHER', label: 'Other Items' },
];

export const BrowsePage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const [items, setItems] = useState<ItemReport[]>([]);
  const [campuses, setCampuses] = useState<Campus[]>([]);
  const [locations, setLocations] = useState<CampusLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Filters from URL or state
  const search = searchParams.get('search') || '';
  const reportType = searchParams.get('type') || '';
  const category = searchParams.get('category') || '';
  const campus = searchParams.get('campus') || '';
  const location = searchParams.get('location') || '';
  const statusFilter = searchParams.get('status') || '';

  useEffect(() => {
    reportsApi.getCampuses().then(setCampuses).catch(() => {});
    reportsApi.getLocations().then(setLocations).catch(() => {});
  }, []);

  const fetchItems = () => {
    setLoading(true);
    const params: any = {};
    if (search) params.search = search;
    if (reportType) params.report_type = reportType;
    if (category) params.category = category;
    if (campus) params.campus = campus;
    if (location) params.location = location;
    if (statusFilter) params.status = statusFilter;

    reportsApi
      .getItems(params)
      .then((data) => {
        setItems(data.results || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchItems();
  }, [searchParams]);

  const updateFilter = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value) {
      next.set(key, value);
    } else {
      next.delete(key);
    }
    setSearchParams(next);
  };

  const clearAllFilters = () => {
    setSearchParams(new URLSearchParams());
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Campus Lost & Found Directory
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Search, filter, and discover matching reports across university grounds
          </p>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-xl transition-colors ${
              viewMode === 'grid'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
            title="Grid view"
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-xl transition-colors ${
              viewMode === 'list'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
            title="List view"
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-800 p-4 sm:p-5 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-subtle space-y-4">
        
        {/* Search input + Report Type Tabs */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => updateFilter('search', e.target.value)}
              placeholder="Search keyword (title, brand, color, description)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            {search && (
              <button
                onClick={() => updateFilter('search', '')}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Type Segmented Control: All / Lost / Found */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-900 rounded-xl shrink-0">
            <button
              onClick={() => updateFilter('type', '')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                reportType === ''
                  ? 'bg-white dark:bg-slate-800 text-forest-900 dark:text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              All Types
            </button>
            <button
              onClick={() => updateFilter('type', 'LOST')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                reportType === 'LOST'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-500 hover:text-rose-600'
              }`}
            >
              Lost Only
            </button>
            <button
              onClick={() => updateFilter('type', 'FOUND')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                reportType === 'FOUND'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-500 hover:text-emerald-600'
              }`}
            >
              Found Only
            </button>
          </div>
        </div>

        {/* Dropdown Filters Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100 dark:border-slate-700/60">
          {/* Category */}
          <select
            value={category}
            onChange={(e) => updateFilter('category', e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">All Categories</option>
            {CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>

          {/* Location */}
          <select
            value={location}
            onChange={(e) => updateFilter('location', e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">All Campus Locations</option>
            {locations.map((loc) => (
              <option key={loc.id} value={loc.id}>
                {loc.name}
              </option>
            ))}
          </select>

          {/* Status */}
          <select
            value={statusFilter}
            onChange={(e) => updateFilter('status', e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">All Statuses</option>
            <option value="OPEN">Open / Active</option>
            <option value="POTENTIAL_MATCH">Potential Match Identified</option>
            <option value="CLAIM_PENDING">Claim Pending Review</option>
            <option value="RECOVERED">Successfully Recovered</option>
          </select>
        </div>

        {/* Active Filters Pills */}
        {(search || reportType || category || location || statusFilter) && (
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="text-[11px] font-bold text-slate-400">Active Filters:</span>
            {search && (
              <span className="px-2 py-0.5 rounded-full text-[11px] bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1">
                "{search}" <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('search', '')} />
              </span>
            )}
            {reportType && (
              <span className="px-2 py-0.5 rounded-full text-[11px] bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1">
                Type: {reportType} <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('type', '')} />
              </span>
            )}
            {category && (
              <span className="px-2 py-0.5 rounded-full text-[11px] bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1">
                Category: {category} <X className="w-3 h-3 cursor-pointer" onClick={() => updateFilter('category', '')} />
              </span>
            )}
            <button
              onClick={clearAllFilters}
              className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold hover:underline ml-auto"
            >
              Reset all filters
            </button>
          </div>
        )}
      </div>

      {/* Directory Results */}
      <div>
        <div className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-4">
          Showing {items.length} report{items.length === 1 ? '' : 's'}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <CardSkeleton />
            <CardSkeleton />
            <CardSkeleton />
            <CardSkeleton />
          </div>
        ) : items.length === 0 ? (
          <EmptyState
            title="No Matching Reports Found"
            description="Try adjusting your keyword search or removing filters to broaden results."
            actionText="Clear Filters"
            onAction={clearAllFilters}
          />
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {items.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-card transition-all"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        item.report_type === 'LOST'
                          ? 'bg-rose-500 text-white'
                          : 'bg-emerald-600 text-white'
                      }`}
                    >
                      {item.report_type}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      {item.title}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                    {item.description}
                  </p>
                  <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-600" />
                      {item.location_name || item.location_detail || 'Campus'}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {item.incident_date}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={`/items/${item.id}`}
                    className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-100 transition-colors"
                  >
                    View Details
                  </a>
                  {item.report_type === 'FOUND' && item.status !== 'RECOVERED' && (
                    <a
                      href={`/items/${item.id}?claim=true`}
                      className="px-4 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                    >
                      Claim
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
